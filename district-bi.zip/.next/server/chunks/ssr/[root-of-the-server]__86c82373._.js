module.exports = {

"[project]/lib/utils.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "cn": (()=>cn),
    "generateOTP": (()=>generateOTP),
    "isValidEmail": (()=>isValidEmail),
    "validatePassword": (()=>validatePassword)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-ssr] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
function generateOTP(length = 6) {
    const digits = "0123456789";
    let OTP = "";
    for(let i = 0; i < length; i++){
        OTP += digits[Math.floor(Math.random() * 10)];
    }
    return OTP;
}
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}
function validatePassword(password) {
    if (password.length < 8) {
        return {
            isValid: false,
            message: "Password must be at least 8 characters long"
        };
    }
    // Check for at least one uppercase letter
    if (!/[A-Z]/.test(password)) {
        return {
            isValid: false,
            message: "Password must contain at least one uppercase letter"
        };
    }
    // Check for at least one lowercase letter
    if (!/[a-z]/.test(password)) {
        return {
            isValid: false,
            message: "Password must contain at least one lowercase letter"
        };
    }
    // Check for at least one number
    if (!/\d/.test(password)) {
        return {
            isValid: false,
            message: "Password must contain at least one number"
        };
    }
    // Check for at least one special character
    if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
        return {
            isValid: false,
            message: "Password must contain at least one special character"
        };
    }
    return {
        isValid: true
    };
}
}}),
"[project]/components/ui/sheet.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Sheet": (()=>Sheet),
    "SheetClose": (()=>SheetClose),
    "SheetContent": (()=>SheetContent),
    "SheetDescription": (()=>SheetDescription),
    "SheetFooter": (()=>SheetFooter),
    "SheetHeader": (()=>SheetHeader),
    "SheetTitle": (()=>SheetTitle),
    "SheetTrigger": (()=>SheetTrigger)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-dialog/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__XIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-ssr] (ecmascript) <export default as XIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
function Sheet({ ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"], {
        "data-slot": "sheet",
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/sheet.tsx",
        lineNumber: 10,
        columnNumber: 10
    }, this);
}
function SheetTrigger({ ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Trigger"], {
        "data-slot": "sheet-trigger",
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/sheet.tsx",
        lineNumber: 16,
        columnNumber: 10
    }, this);
}
function SheetClose({ ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Close"], {
        "data-slot": "sheet-close",
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/sheet.tsx",
        lineNumber: 22,
        columnNumber: 10
    }, this);
}
function SheetPortal({ ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Portal"], {
        "data-slot": "sheet-portal",
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/sheet.tsx",
        lineNumber: 28,
        columnNumber: 10
    }, this);
}
function SheetOverlay({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Overlay"], {
        "data-slot": "sheet-overlay",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 fixed inset-0 z-50 bg-black/50", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/sheet.tsx",
        lineNumber: 36,
        columnNumber: 5
    }, this);
}
function SheetContent({ className, children, side = "right", ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(SheetPortal, {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(SheetOverlay, {}, void 0, false, {
                fileName: "[project]/components/ui/sheet.tsx",
                lineNumber: 57,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Content"], {
                "data-slot": "sheet-content",
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("bg-background data-[state=open]:animate-in data-[state=closed]:animate-out fixed z-50 flex flex-col gap-4 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500", side === "right" && "data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right inset-y-0 right-0 h-full w-3/4 border-l sm:max-w-sm", side === "left" && "data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left inset-y-0 left-0 h-full w-3/4 border-r sm:max-w-sm", side === "top" && "data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top inset-x-0 top-0 h-auto border-b", side === "bottom" && "data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom inset-x-0 bottom-0 h-auto border-t", className),
                ...props,
                children: [
                    children,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Close"], {
                        className: "ring-offset-background focus:ring-ring data-[state=open]:bg-secondary absolute top-4 right-4 rounded-xs opacity-70 transition-opacity hover:opacity-100 focus:ring-2 focus:ring-offset-2 focus:outline-hidden disabled:pointer-events-none",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__XIcon$3e$__["XIcon"], {
                                className: "size-4"
                            }, void 0, false, {
                                fileName: "[project]/components/ui/sheet.tsx",
                                lineNumber: 76,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "sr-only",
                                children: "Close"
                            }, void 0, false, {
                                fileName: "[project]/components/ui/sheet.tsx",
                                lineNumber: 77,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ui/sheet.tsx",
                        lineNumber: 75,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ui/sheet.tsx",
                lineNumber: 58,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/sheet.tsx",
        lineNumber: 56,
        columnNumber: 5
    }, this);
}
function SheetHeader({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "sheet-header",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("flex flex-col gap-1.5 p-4", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/sheet.tsx",
        lineNumber: 86,
        columnNumber: 5
    }, this);
}
function SheetFooter({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "sheet-footer",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("mt-auto flex flex-col gap-2 p-4", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/sheet.tsx",
        lineNumber: 96,
        columnNumber: 5
    }, this);
}
function SheetTitle({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Title"], {
        "data-slot": "sheet-title",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("text-foreground font-semibold", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/sheet.tsx",
        lineNumber: 109,
        columnNumber: 5
    }, this);
}
function SheetDescription({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Description"], {
        "data-slot": "sheet-description",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("text-muted-foreground text-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/sheet.tsx",
        lineNumber: 122,
        columnNumber: 5
    }, this);
}
;
}}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/components/ui/button.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Button": (()=>Button),
    "buttonVariants": (()=>buttonVariants)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-slot/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-ssr] (ecmascript)");
;
;
;
;
const buttonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", {
    variants: {
        variant: {
            default: "bg-primary text-primary-foreground shadow-xs hover:bg-primary/90",
            destructive: "bg-destructive text-white shadow-xs hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",
            outline: "border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50",
            secondary: "bg-secondary text-secondary-foreground shadow-xs hover:bg-secondary/80",
            ghost: "hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",
            link: "text-primary underline-offset-4 hover:underline"
        },
        size: {
            default: "h-9 px-4 py-2 has-[>svg]:px-3",
            sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
            lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
            icon: "size-9"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
function Button({ className, variant, size, asChild = false, ...props }) {
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Slot"] : "button";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        "data-slot": "button",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])(buttonVariants({
            variant,
            size,
            className
        })),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/button.tsx",
        lineNumber: 51,
        columnNumber: 5
    }, this);
}
;
}}),
"[project]/components/ui/separator.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Separator": (()=>Separator)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$separator$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-separator/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
function Separator({ className, orientation = "horizontal", decorative = true, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$separator$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"], {
        "data-slot": "separator-root",
        decorative: decorative,
        orientation: orientation,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("bg-border shrink-0 data-[orientation=horizontal]:h-px data-[orientation=horizontal]:w-full data-[orientation=vertical]:h-full data-[orientation=vertical]:w-px", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/separator.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, this);
}
;
}}),
"[project]/components/ui/badge.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Badge": (()=>Badge),
    "badgeVariants": (()=>badgeVariants)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-slot/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-ssr] (ecmascript)");
;
;
;
;
const badgeVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center justify-center rounded-md border px-2 py-0.5 text-xs font-medium w-fit whitespace-nowrap shrink-0 [&>svg]:size-3 gap-1 [&>svg]:pointer-events-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive transition-[color,box-shadow] overflow-hidden", {
    variants: {
        variant: {
            default: "border-transparent bg-primary text-primary-foreground [a&]:hover:bg-primary/90",
            secondary: "border-transparent bg-secondary text-secondary-foreground [a&]:hover:bg-secondary/90",
            destructive: "border-transparent bg-destructive text-white [a&]:hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",
            outline: "text-foreground [a&]:hover:bg-accent [a&]:hover:text-accent-foreground"
        }
    },
    defaultVariants: {
        variant: "default"
    }
});
function Badge({ className, variant, asChild = false, ...props }) {
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Slot"] : "span";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        "data-slot": "badge",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])(badgeVariants({
            variant
        }), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/badge.tsx",
        lineNumber: 38,
        columnNumber: 5
    }, this);
}
;
}}),
"[externals]/node:os [external] (node:os, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:os", () => require("node:os"));

module.exports = mod;
}}),
"[externals]/node:tty [external] (node:tty, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:tty", () => require("node:tty"));

module.exports = mod;
}}),
"[externals]/node:fs [external] (node:fs, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:fs", () => require("node:fs"));

module.exports = mod;
}}),
"[externals]/node:path [external] (node:path, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:path", () => require("node:path"));

module.exports = mod;
}}),
"[externals]/node:crypto [external] (node:crypto, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:crypto", () => require("node:crypto"));

module.exports = mod;
}}),
"[externals]/node:child_process [external] (node:child_process, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:child_process", () => require("node:child_process"));

module.exports = mod;
}}),
"[externals]/node:fs/promises [external] (node:fs/promises, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:fs/promises", () => require("node:fs/promises"));

module.exports = mod;
}}),
"[externals]/node:util [external] (node:util, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:util", () => require("node:util"));

module.exports = mod;
}}),
"[externals]/node:process [external] (node:process, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:process", () => require("node:process"));

module.exports = mod;
}}),
"[externals]/node:async_hooks [external] (node:async_hooks, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:async_hooks", () => require("node:async_hooks"));

module.exports = mod;
}}),
"[externals]/node:events [external] (node:events, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:events", () => require("node:events"));

module.exports = mod;
}}),
"[project]/app/generated/prisma/runtime/library.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
/* !!! This is code generated by Prisma. Do not edit directly. !!!
/* eslint-disable */ "use strict";
var yu = Object.create;
var qt = Object.defineProperty;
var bu = Object.getOwnPropertyDescriptor;
var Eu = Object.getOwnPropertyNames;
var wu = Object.getPrototypeOf, xu = Object.prototype.hasOwnProperty;
var Do = (e, r)=>()=>(e && (r = e(e = 0)), r);
var ne = (e, r)=>()=>(r || e((r = {
            exports: {}
        }).exports, r), r.exports), tr = (e, r)=>{
    for(var t in r)qt(e, t, {
        get: r[t],
        enumerable: !0
    });
}, _o = (e, r, t, n)=>{
    if (r && typeof r == "object" || typeof r == "function") for (let i of Eu(r))!xu.call(e, i) && i !== t && qt(e, i, {
        get: ()=>r[i],
        enumerable: !(n = bu(r, i)) || n.enumerable
    });
    return e;
};
var k = (e, r, t)=>(t = e != null ? yu(wu(e)) : {}, _o(r || !e || !e.__esModule ? qt(t, "default", {
        value: e,
        enumerable: !0
    }) : t, e)), vu = (e)=>_o(qt({}, "__esModule", {
        value: !0
    }), e);
var mi = ne((_g, ss)=>{
    "use strict";
    ss.exports = (e, r = process.argv)=>{
        let t = e.startsWith("-") ? "" : e.length === 1 ? "-" : "--", n = r.indexOf(t + e), i = r.indexOf("--");
        return n !== -1 && (i === -1 || n < i);
    };
});
var us = ne((Ng, ls)=>{
    "use strict";
    var Lc = __turbopack_context__.r("[externals]/node:os [external] (node:os, cjs)"), as = __turbopack_context__.r("[externals]/node:tty [external] (node:tty, cjs)"), de = mi(), { env: Q } = process, Ge;
    de("no-color") || de("no-colors") || de("color=false") || de("color=never") ? Ge = 0 : (de("color") || de("colors") || de("color=true") || de("color=always")) && (Ge = 1);
    "FORCE_COLOR" in Q && (Q.FORCE_COLOR === "true" ? Ge = 1 : Q.FORCE_COLOR === "false" ? Ge = 0 : Ge = Q.FORCE_COLOR.length === 0 ? 1 : Math.min(parseInt(Q.FORCE_COLOR, 10), 3));
    function fi(e) {
        return e === 0 ? !1 : {
            level: e,
            hasBasic: !0,
            has256: e >= 2,
            has16m: e >= 3
        };
    }
    function gi(e, r) {
        if (Ge === 0) return 0;
        if (de("color=16m") || de("color=full") || de("color=truecolor")) return 3;
        if (de("color=256")) return 2;
        if (e && !r && Ge === void 0) return 0;
        let t = Ge || 0;
        if (Q.TERM === "dumb") return t;
        if ("TURBOPACK compile-time truthy", 1) {
            let n = Lc.release().split(".");
            return Number(n[0]) >= 10 && Number(n[2]) >= 10586 ? Number(n[2]) >= 14931 ? 3 : 2 : 1;
        }
        "TURBOPACK unreachable";
    }
    function Mc(e) {
        let r = gi(e, e && e.isTTY);
        return fi(r);
    }
    ls.exports = {
        supportsColor: Mc,
        stdout: fi(gi(!0, as.isatty(1))),
        stderr: fi(gi(!0, as.isatty(2)))
    };
});
var ds = ne((Fg, ps)=>{
    "use strict";
    var $c = us(), br = mi();
    function cs(e) {
        if (/^\d{3,4}$/.test(e)) {
            let t = /(\d{1,2})(\d{2})/.exec(e) || [];
            return {
                major: 0,
                minor: parseInt(t[1], 10),
                patch: parseInt(t[2], 10)
            };
        }
        let r = (e || "").split(".").map((t)=>parseInt(t, 10));
        return {
            major: r[0],
            minor: r[1],
            patch: r[2]
        };
    }
    function hi(e) {
        let { CI: r, FORCE_HYPERLINK: t, NETLIFY: n, TEAMCITY_VERSION: i, TERM_PROGRAM: o, TERM_PROGRAM_VERSION: s, VTE_VERSION: a, TERM: l } = process.env;
        if (t) return !(t.length > 0 && parseInt(t, 10) === 0);
        if (br("no-hyperlink") || br("no-hyperlinks") || br("hyperlink=false") || br("hyperlink=never")) return !1;
        if (br("hyperlink=true") || br("hyperlink=always") || n) return !0;
        if (!$c.supportsColor(e) || e && !e.isTTY) return !1;
        if ("WT_SESSION" in process.env) return !0;
        if ("TURBOPACK compile-time truthy", 1) return !1;
        "TURBOPACK unreachable";
    }
    ps.exports = {
        supportsHyperlink: hi,
        stdout: hi(process.stdout),
        stderr: hi(process.stderr)
    };
});
var ms = ne((Hg, qc)=>{
    qc.exports = {
        name: "@prisma/internals",
        version: "6.7.0",
        description: "This package is intended for Prisma's internal use",
        main: "dist/index.js",
        types: "dist/index.d.ts",
        repository: {
            type: "git",
            url: "https://github.com/prisma/prisma.git",
            directory: "packages/internals"
        },
        homepage: "https://www.prisma.io",
        author: "Tim Suchanek <suchanek@prisma.io>",
        bugs: "https://github.com/prisma/prisma/issues",
        license: "Apache-2.0",
        scripts: {
            dev: "DEV=true tsx helpers/build.ts",
            build: "tsx helpers/build.ts",
            test: "dotenv -e ../../.db.env -- jest --silent",
            prepublishOnly: "pnpm run build"
        },
        files: [
            "README.md",
            "dist",
            "!**/libquery_engine*",
            "!dist/get-generators/engines/*",
            "scripts"
        ],
        devDependencies: {
            "@babel/helper-validator-identifier": "7.25.9",
            "@opentelemetry/api": "1.9.0",
            "@swc/core": "1.11.5",
            "@swc/jest": "0.2.37",
            "@types/babel__helper-validator-identifier": "7.15.2",
            "@types/jest": "29.5.14",
            "@types/node": "18.19.76",
            "@types/resolve": "1.20.6",
            archiver: "6.0.2",
            "checkpoint-client": "1.1.33",
            "cli-truncate": "4.0.0",
            dotenv: "16.4.7",
            esbuild: "0.25.1",
            "escape-string-regexp": "5.0.0",
            execa: "5.1.1",
            "fast-glob": "3.3.3",
            "find-up": "7.0.0",
            "fp-ts": "2.16.9",
            "fs-extra": "11.3.0",
            "fs-jetpack": "5.1.0",
            "global-dirs": "4.0.0",
            globby: "11.1.0",
            "identifier-regex": "1.0.0",
            "indent-string": "4.0.0",
            "is-windows": "1.0.2",
            "is-wsl": "3.1.0",
            jest: "29.7.0",
            "jest-junit": "16.0.0",
            kleur: "4.1.5",
            "mock-stdin": "1.0.0",
            "new-github-issue-url": "0.2.1",
            "node-fetch": "3.3.2",
            "npm-packlist": "5.1.3",
            open: "7.4.2",
            "p-map": "4.0.0",
            "read-package-up": "11.0.0",
            resolve: "1.22.10",
            "string-width": "7.2.0",
            "strip-ansi": "6.0.1",
            "strip-indent": "4.0.0",
            "temp-dir": "2.0.0",
            tempy: "1.0.1",
            "terminal-link": "4.0.0",
            tmp: "0.2.3",
            "ts-node": "10.9.2",
            "ts-pattern": "5.6.2",
            "ts-toolbelt": "9.6.0",
            typescript: "5.4.5",
            yarn: "1.22.22"
        },
        dependencies: {
            "@prisma/config": "workspace:*",
            "@prisma/debug": "workspace:*",
            "@prisma/dmmf": "workspace:*",
            "@prisma/driver-adapter-utils": "workspace:*",
            "@prisma/engines": "workspace:*",
            "@prisma/fetch-engine": "workspace:*",
            "@prisma/generator": "workspace:*",
            "@prisma/generator-helper": "workspace:*",
            "@prisma/get-platform": "workspace:*",
            "@prisma/prisma-schema-wasm": "6.7.0-36.3cff47a7f5d65c3ea74883f1d736e41d68ce91ed",
            "@prisma/schema-engine-wasm": "6.7.0-36.3cff47a7f5d65c3ea74883f1d736e41d68ce91ed",
            "@prisma/schema-files-loader": "workspace:*",
            arg: "5.0.2",
            prompts: "2.4.2"
        },
        peerDependencies: {
            typescript: ">=5.1.0"
        },
        peerDependenciesMeta: {
            typescript: {
                optional: !0
            }
        },
        sideEffects: !1
    };
});
var Ei = ne((zg, Uc)=>{
    Uc.exports = {
        name: "@prisma/engines-version",
        version: "6.7.0-36.3cff47a7f5d65c3ea74883f1d736e41d68ce91ed",
        main: "index.js",
        types: "index.d.ts",
        license: "Apache-2.0",
        author: "Tim Suchanek <suchanek@prisma.io>",
        prisma: {
            enginesVersion: "3cff47a7f5d65c3ea74883f1d736e41d68ce91ed"
        },
        repository: {
            type: "git",
            url: "https://github.com/prisma/engines-wrapper.git",
            directory: "packages/engines-version"
        },
        devDependencies: {
            "@types/node": "18.19.76",
            typescript: "4.9.5"
        },
        files: [
            "index.js",
            "index.d.ts"
        ],
        scripts: {
            build: "tsc -d"
        }
    };
});
var wi = ne((Xt)=>{
    "use strict";
    Object.defineProperty(Xt, "__esModule", {
        value: !0
    });
    Xt.enginesVersion = void 0;
    Xt.enginesVersion = Ei().prisma.enginesVersion;
});
var ys = ne((hh, hs)=>{
    "use strict";
    hs.exports = (e)=>{
        let r = e.match(/^[ \t]*(?=\S)/gm);
        return r ? r.reduce((t, n)=>Math.min(t, n.length), 1 / 0) : 0;
    };
});
var Ri = ne((Eh, ws)=>{
    "use strict";
    ws.exports = (e, r = 1, t)=>{
        if (t = {
            indent: " ",
            includeEmptyLines: !1,
            ...t
        }, typeof e != "string") throw new TypeError(`Expected \`input\` to be a \`string\`, got \`${typeof e}\``);
        if (typeof r != "number") throw new TypeError(`Expected \`count\` to be a \`number\`, got \`${typeof r}\``);
        if (typeof t.indent != "string") throw new TypeError(`Expected \`options.indent\` to be a \`string\`, got \`${typeof t.indent}\``);
        if (r === 0) return e;
        let n = t.includeEmptyLines ? /^/gm : /^(?!\s*$)/gm;
        return e.replace(n, t.indent.repeat(r));
    };
});
var Ts = ne((vh, Ps)=>{
    "use strict";
    Ps.exports = ({ onlyFirst: e = !1 } = {})=>{
        let r = [
            "[\\u001B\\u009B][[\\]()#;?]*(?:(?:(?:(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]+)*|[a-zA-Z\\d]+(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]*)*)?\\u0007)",
            "(?:(?:\\d{1,4}(?:;\\d{0,4})*)?[\\dA-PR-TZcf-ntqry=><~]))"
        ].join("|");
        return new RegExp(r, e ? void 0 : "g");
    };
});
var ki = ne((Ph, Ss)=>{
    "use strict";
    var Xc = Ts();
    Ss.exports = (e)=>typeof e == "string" ? e.replace(Xc(), "") : e;
});
var Rs = ne((Ch, ep)=>{
    ep.exports = {
        name: "dotenv",
        version: "16.4.7",
        description: "Loads environment variables from .env file",
        main: "lib/main.js",
        types: "lib/main.d.ts",
        exports: {
            ".": {
                types: "./lib/main.d.ts",
                require: "./lib/main.js",
                default: "./lib/main.js"
            },
            "./config": "./config.js",
            "./config.js": "./config.js",
            "./lib/env-options": "./lib/env-options.js",
            "./lib/env-options.js": "./lib/env-options.js",
            "./lib/cli-options": "./lib/cli-options.js",
            "./lib/cli-options.js": "./lib/cli-options.js",
            "./package.json": "./package.json"
        },
        scripts: {
            "dts-check": "tsc --project tests/types/tsconfig.json",
            lint: "standard",
            pretest: "npm run lint && npm run dts-check",
            test: "tap run --allow-empty-coverage --disable-coverage --timeout=60000",
            "test:coverage": "tap run --show-full-coverage --timeout=60000 --coverage-report=lcov",
            prerelease: "npm test",
            release: "standard-version"
        },
        repository: {
            type: "git",
            url: "git://github.com/motdotla/dotenv.git"
        },
        funding: "https://dotenvx.com",
        keywords: [
            "dotenv",
            "env",
            ".env",
            "environment",
            "variables",
            "config",
            "settings"
        ],
        readmeFilename: "README.md",
        license: "BSD-2-Clause",
        devDependencies: {
            "@types/node": "^18.11.3",
            decache: "^4.6.2",
            sinon: "^14.0.1",
            standard: "^17.0.0",
            "standard-version": "^9.5.0",
            tap: "^19.2.0",
            typescript: "^4.8.4"
        },
        engines: {
            node: ">=12"
        },
        browser: {
            fs: !1
        }
    };
});
var ks = ne((Ah, Ne)=>{
    "use strict";
    var Di = __turbopack_context__.r("[externals]/node:fs [external] (node:fs, cjs)"), _i = __turbopack_context__.r("[externals]/node:path [external] (node:path, cjs)"), rp = __turbopack_context__.r("[externals]/node:os [external] (node:os, cjs)"), tp = __turbopack_context__.r("[externals]/node:crypto [external] (node:crypto, cjs)"), np = Rs(), Ni = np.version, ip = /(?:^|^)\s*(?:export\s+)?([\w.-]+)(?:\s*=\s*?|:\s+?)(\s*'(?:\\'|[^'])*'|\s*"(?:\\"|[^"])*"|\s*`(?:\\`|[^`])*`|[^#\r\n]+)?\s*(?:#.*)?(?:$|$)/mg;
    function op(e) {
        let r = {}, t = e.toString();
        t = t.replace(/\r\n?/mg, `
`);
        let n;
        for(; (n = ip.exec(t)) != null;){
            let i = n[1], o = n[2] || "";
            o = o.trim();
            let s = o[0];
            o = o.replace(/^(['"`])([\s\S]*)\1$/mg, "$2"), s === '"' && (o = o.replace(/\\n/g, `
`), o = o.replace(/\\r/g, "\r")), r[i] = o;
        }
        return r;
    }
    function sp(e) {
        let r = Is(e), t = B.configDotenv({
            path: r
        });
        if (!t.parsed) {
            let s = new Error(`MISSING_DATA: Cannot parse ${r} for an unknown reason`);
            throw s.code = "MISSING_DATA", s;
        }
        let n = As(e).split(","), i = n.length, o;
        for(let s = 0; s < i; s++)try {
            let a = n[s].trim(), l = up(t, a);
            o = B.decrypt(l.ciphertext, l.key);
            break;
        } catch (a) {
            if (s + 1 >= i) throw a;
        }
        return B.parse(o);
    }
    function ap(e) {
        console.log(`[dotenv@${Ni}][INFO] ${e}`);
    }
    function lp(e) {
        console.log(`[dotenv@${Ni}][WARN] ${e}`);
    }
    function tn(e) {
        console.log(`[dotenv@${Ni}][DEBUG] ${e}`);
    }
    function As(e) {
        return e && e.DOTENV_KEY && e.DOTENV_KEY.length > 0 ? e.DOTENV_KEY : process.env.DOTENV_KEY && process.env.DOTENV_KEY.length > 0 ? process.env.DOTENV_KEY : "";
    }
    function up(e, r) {
        let t;
        try {
            t = new URL(r);
        } catch (a) {
            if (a.code === "ERR_INVALID_URL") {
                let l = new Error("INVALID_DOTENV_KEY: Wrong format. Must be in valid uri format like dotenv://:key_1234@dotenvx.com/vault/.env.vault?environment=development");
                throw l.code = "INVALID_DOTENV_KEY", l;
            }
            throw a;
        }
        let n = t.password;
        if (!n) {
            let a = new Error("INVALID_DOTENV_KEY: Missing key part");
            throw a.code = "INVALID_DOTENV_KEY", a;
        }
        let i = t.searchParams.get("environment");
        if (!i) {
            let a = new Error("INVALID_DOTENV_KEY: Missing environment part");
            throw a.code = "INVALID_DOTENV_KEY", a;
        }
        let o = `DOTENV_VAULT_${i.toUpperCase()}`, s = e.parsed[o];
        if (!s) {
            let a = new Error(`NOT_FOUND_DOTENV_ENVIRONMENT: Cannot locate environment ${o} in your .env.vault file.`);
            throw a.code = "NOT_FOUND_DOTENV_ENVIRONMENT", a;
        }
        return {
            ciphertext: s,
            key: n
        };
    }
    function Is(e) {
        let r = null;
        if (e && e.path && e.path.length > 0) if (Array.isArray(e.path)) for (let t of e.path)Di.existsSync(t) && (r = t.endsWith(".vault") ? t : `${t}.vault`);
        else r = e.path.endsWith(".vault") ? e.path : `${e.path}.vault`;
        else r = _i.resolve(process.cwd(), ".env.vault");
        return Di.existsSync(r) ? r : null;
    }
    function Cs(e) {
        return e[0] === "~" ? _i.join(rp.homedir(), e.slice(1)) : e;
    }
    function cp(e) {
        ap("Loading env from encrypted .env.vault");
        let r = B._parseVault(e), t = process.env;
        return e && e.processEnv != null && (t = e.processEnv), B.populate(t, r, e), {
            parsed: r
        };
    }
    function pp(e) {
        let r = _i.resolve(process.cwd(), ".env"), t = "utf8", n = !!(e && e.debug);
        e && e.encoding ? t = e.encoding : n && tn("No encoding is specified. UTF-8 is used by default");
        let i = [
            r
        ];
        if (e && e.path) if (!Array.isArray(e.path)) i = [
            Cs(e.path)
        ];
        else {
            i = [];
            for (let l of e.path)i.push(Cs(l));
        }
        let o, s = {};
        for (let l of i)try {
            let u = B.parse(Di.readFileSync(l, {
                encoding: t
            }));
            B.populate(s, u, e);
        } catch (u) {
            n && tn(`Failed to load ${l} ${u.message}`), o = u;
        }
        let a = process.env;
        return e && e.processEnv != null && (a = e.processEnv), B.populate(a, s, e), o ? {
            parsed: s,
            error: o
        } : {
            parsed: s
        };
    }
    function dp(e) {
        if (As(e).length === 0) return B.configDotenv(e);
        let r = Is(e);
        return r ? B._configVault(e) : (lp(`You set DOTENV_KEY but you are missing a .env.vault file at ${r}. Did you forget to build it?`), B.configDotenv(e));
    }
    function mp(e, r) {
        let t = Buffer.from(r.slice(-64), "hex"), n = Buffer.from(e, "base64"), i = n.subarray(0, 12), o = n.subarray(-16);
        n = n.subarray(12, -16);
        try {
            let s = tp.createDecipheriv("aes-256-gcm", t, i);
            return s.setAuthTag(o), `${s.update(n)}${s.final()}`;
        } catch (s) {
            let a = s instanceof RangeError, l = s.message === "Invalid key length", u = s.message === "Unsupported state or unable to authenticate data";
            if (a || l) {
                let c = new Error("INVALID_DOTENV_KEY: It must be 64 characters long (or more)");
                throw c.code = "INVALID_DOTENV_KEY", c;
            } else if (u) {
                let c = new Error("DECRYPTION_FAILED: Please check your DOTENV_KEY");
                throw c.code = "DECRYPTION_FAILED", c;
            } else throw s;
        }
    }
    function fp(e, r, t = {}) {
        let n = !!(t && t.debug), i = !!(t && t.override);
        if (typeof r != "object") {
            let o = new Error("OBJECT_REQUIRED: Please check the processEnv argument being passed to populate");
            throw o.code = "OBJECT_REQUIRED", o;
        }
        for (let o of Object.keys(r))Object.prototype.hasOwnProperty.call(e, o) ? (i === !0 && (e[o] = r[o]), n && tn(i === !0 ? `"${o}" is already defined and WAS overwritten` : `"${o}" is already defined and was NOT overwritten`)) : e[o] = r[o];
    }
    var B = {
        configDotenv: pp,
        _configVault: cp,
        _parseVault: sp,
        config: dp,
        decrypt: mp,
        parse: op,
        populate: fp
    };
    Ne.exports.configDotenv = B.configDotenv;
    Ne.exports._configVault = B._configVault;
    Ne.exports._parseVault = B._parseVault;
    Ne.exports.config = B.config;
    Ne.exports.decrypt = B.decrypt;
    Ne.exports.parse = B.parse;
    Ne.exports.populate = B.populate;
    Ne.exports = B;
});
var Ns = ne((Nh, on)=>{
    "use strict";
    on.exports = (e = {})=>{
        let r;
        if (e.repoUrl) r = e.repoUrl;
        else if (e.user && e.repo) r = `https://github.com/${e.user}/${e.repo}`;
        else throw new Error("You need to specify either the `repoUrl` option or both the `user` and `repo` options");
        let t = new URL(`${r}/issues/new`), n = [
            "body",
            "title",
            "labels",
            "template",
            "milestone",
            "assignee",
            "projects"
        ];
        for (let i of n){
            let o = e[i];
            if (o !== void 0) {
                if (i === "labels" || i === "projects") {
                    if (!Array.isArray(o)) throw new TypeError(`The \`${i}\` option should be an array`);
                    o = o.join(",");
                }
                t.searchParams.set(i, o);
            }
        }
        return t.toString();
    };
    on.exports.default = on.exports;
});
var Gi = ne((pb, na)=>{
    "use strict";
    na.exports = function() {
        function e(r, t, n, i, o) {
            return r < t || n < t ? r > n ? n + 1 : r + 1 : i === o ? t : t + 1;
        }
        return function(r, t) {
            if (r === t) return 0;
            if (r.length > t.length) {
                var n = r;
                r = t, t = n;
            }
            for(var i = r.length, o = t.length; i > 0 && r.charCodeAt(i - 1) === t.charCodeAt(o - 1);)i--, o--;
            for(var s = 0; s < i && r.charCodeAt(s) === t.charCodeAt(s);)s++;
            if (i -= s, o -= s, i === 0 || o < 3) return o;
            var a = 0, l, u, c, p, d, f, g, h, I, P, S, b, O = [];
            for(l = 0; l < i; l++)O.push(l + 1), O.push(r.charCodeAt(s + l));
            for(var me = O.length - 1; a < o - 3;)for(I = t.charCodeAt(s + (u = a)), P = t.charCodeAt(s + (c = a + 1)), S = t.charCodeAt(s + (p = a + 2)), b = t.charCodeAt(s + (d = a + 3)), f = a += 4, l = 0; l < me; l += 2)g = O[l], h = O[l + 1], u = e(g, u, c, I, h), c = e(u, c, p, P, h), p = e(c, p, d, S, h), f = e(p, d, f, b, h), O[l] = f, d = p, p = c, c = u, u = g;
            for(; a < o;)for(I = t.charCodeAt(s + (u = a)), f = ++a, l = 0; l < me; l += 2)g = O[l], O[l] = f = e(g, u, f, I, O[l + 1]), u = g;
            return f;
        };
    }();
});
var la = Do(()=>{
    "use strict";
});
var ua = Do(()=>{
    "use strict";
});
var Vf = {};
tr(Vf, {
    DMMF: ()=>lt,
    Debug: ()=>N,
    Decimal: ()=>ve,
    Extensions: ()=>ei,
    MetricsClient: ()=>Fr,
    PrismaClientInitializationError: ()=>T,
    PrismaClientKnownRequestError: ()=>z,
    PrismaClientRustPanicError: ()=>le,
    PrismaClientUnknownRequestError: ()=>j,
    PrismaClientValidationError: ()=>Z,
    Public: ()=>ri,
    Sql: ()=>oe,
    createParam: ()=>Sa,
    defineDmmfProperty: ()=>Oa,
    deserializeJsonResponse: ()=>Tr,
    deserializeRawResult: ()=>Yn,
    dmmfToRuntimeDataModel: ()=>zs,
    empty: ()=>Na,
    getPrismaClient: ()=>fu,
    getRuntime: ()=>qn,
    join: ()=>_a,
    makeStrictEnum: ()=>gu,
    makeTypedQueryFactory: ()=>Da,
    objectEnumValues: ()=>Sn,
    raw: ()=>eo,
    serializeJsonQuery: ()=>Dn,
    skip: ()=>On,
    sqltag: ()=>ro,
    warnEnvConflicts: ()=>hu,
    warnOnce: ()=>ot
});
module.exports = vu(Vf);
var ei = {};
tr(ei, {
    defineExtension: ()=>No,
    getExtensionContext: ()=>Fo
});
function No(e) {
    return typeof e == "function" ? e : (r)=>r.$extends(e);
}
function Fo(e) {
    return e;
}
var ri = {};
tr(ri, {
    validator: ()=>Lo
});
function Lo(...e) {
    return (r)=>r;
}
var jt = {};
tr(jt, {
    $: ()=>Vo,
    bgBlack: ()=>Du,
    bgBlue: ()=>Lu,
    bgCyan: ()=>$u,
    bgGreen: ()=>Nu,
    bgMagenta: ()=>Mu,
    bgRed: ()=>_u,
    bgWhite: ()=>qu,
    bgYellow: ()=>Fu,
    black: ()=>Au,
    blue: ()=>nr,
    bold: ()=>W,
    cyan: ()=>Oe,
    dim: ()=>Ie,
    gray: ()=>Hr,
    green: ()=>qe,
    grey: ()=>Ou,
    hidden: ()=>Ru,
    inverse: ()=>Su,
    italic: ()=>Tu,
    magenta: ()=>Iu,
    red: ()=>ce,
    reset: ()=>Pu,
    strikethrough: ()=>Cu,
    underline: ()=>Y,
    white: ()=>ku,
    yellow: ()=>ke
});
var ti, Mo, $o, qo, jo = !0;
typeof process < "u" && ({ FORCE_COLOR: ti, NODE_DISABLE_COLORS: Mo, NO_COLOR: $o, TERM: qo } = process.env || {}, jo = process.stdout && process.stdout.isTTY);
var Vo = {
    enabled: !Mo && $o == null && qo !== "dumb" && (ti != null && ti !== "0" || jo)
};
function L(e, r) {
    let t = new RegExp(`\\x1b\\[${r}m`, "g"), n = `\x1B[${e}m`, i = `\x1B[${r}m`;
    return function(o) {
        return !Vo.enabled || o == null ? o : n + (~("" + o).indexOf(i) ? o.replace(t, i + n) : o) + i;
    };
}
var Pu = L(0, 0), W = L(1, 22), Ie = L(2, 22), Tu = L(3, 23), Y = L(4, 24), Su = L(7, 27), Ru = L(8, 28), Cu = L(9, 29), Au = L(30, 39), ce = L(31, 39), qe = L(32, 39), ke = L(33, 39), nr = L(34, 39), Iu = L(35, 39), Oe = L(36, 39), ku = L(37, 39), Hr = L(90, 39), Ou = L(90, 39), Du = L(40, 49), _u = L(41, 49), Nu = L(42, 49), Fu = L(43, 49), Lu = L(44, 49), Mu = L(45, 49), $u = L(46, 49), qu = L(47, 49);
var ju = 100, Bo = [
    "green",
    "yellow",
    "blue",
    "magenta",
    "cyan",
    "red"
], Kr = [], Uo = Date.now(), Vu = 0, ni = typeof process < "u" ? process.env : {};
globalThis.DEBUG ??= ni.DEBUG ?? "";
globalThis.DEBUG_COLORS ??= ni.DEBUG_COLORS ? ni.DEBUG_COLORS === "true" : !0;
var Yr = {
    enable (e) {
        typeof e == "string" && (globalThis.DEBUG = e);
    },
    disable () {
        let e = globalThis.DEBUG;
        return globalThis.DEBUG = "", e;
    },
    enabled (e) {
        let r = globalThis.DEBUG.split(",").map((i)=>i.replace(/[.+?^${}()|[\]\\]/g, "\\$&")), t = r.some((i)=>i === "" || i[0] === "-" ? !1 : e.match(RegExp(i.split("*").join(".*") + "$"))), n = r.some((i)=>i === "" || i[0] !== "-" ? !1 : e.match(RegExp(i.slice(1).split("*").join(".*") + "$")));
        return t && !n;
    },
    log: (...e)=>{
        let [r, t, ...n] = e;
        (console.warn ?? console.log)(`${r} ${t}`, ...n);
    },
    formatters: {}
};
function Bu(e) {
    let r = {
        color: Bo[Vu++ % Bo.length],
        enabled: Yr.enabled(e),
        namespace: e,
        log: Yr.log,
        extend: ()=>{}
    }, t = (...n)=>{
        let { enabled: i, namespace: o, color: s, log: a } = r;
        if (n.length !== 0 && Kr.push([
            o,
            ...n
        ]), Kr.length > ju && Kr.shift(), Yr.enabled(o) || i) {
            let l = n.map((c)=>typeof c == "string" ? c : Uu(c)), u = `+${Date.now() - Uo}ms`;
            Uo = Date.now(), globalThis.DEBUG_COLORS ? a(jt[s](W(o)), ...l, jt[s](u)) : a(o, ...l, u);
        }
    };
    return new Proxy(t, {
        get: (n, i)=>r[i],
        set: (n, i, o)=>r[i] = o
    });
}
var N = new Proxy(Bu, {
    get: (e, r)=>Yr[r],
    set: (e, r, t)=>Yr[r] = t
});
function Uu(e, r = 2) {
    let t = new Set;
    return JSON.stringify(e, (n, i)=>{
        if (typeof i == "object" && i !== null) {
            if (t.has(i)) return "[Circular *]";
            t.add(i);
        } else if (typeof i == "bigint") return i.toString();
        return i;
    }, r);
}
function Qo(e = 7500) {
    let r = Kr.map(([t, ...n])=>`${t} ${n.map((i)=>typeof i == "string" ? i : JSON.stringify(i)).join(" ")}`).join(`
`);
    return r.length < e ? r : r.slice(-e);
}
function Go() {
    Kr.length = 0;
}
var gr = N;
var Wo = k(__turbopack_context__.r("[externals]/node:fs [external] (node:fs, cjs)"));
function ii() {
    let e = process.env.PRISMA_QUERY_ENGINE_LIBRARY;
    if (!(e && Wo.default.existsSync(e)) && process.arch === "ia32") {
        "TURBOPACK unreachable";
    }
}
var oi = [
    "darwin",
    "darwin-arm64",
    "debian-openssl-1.0.x",
    "debian-openssl-1.1.x",
    "debian-openssl-3.0.x",
    "rhel-openssl-1.0.x",
    "rhel-openssl-1.1.x",
    "rhel-openssl-3.0.x",
    "linux-arm64-openssl-1.1.x",
    "linux-arm64-openssl-1.0.x",
    "linux-arm64-openssl-3.0.x",
    "linux-arm-openssl-1.1.x",
    "linux-arm-openssl-1.0.x",
    "linux-arm-openssl-3.0.x",
    "linux-musl",
    "linux-musl-openssl-3.0.x",
    "linux-musl-arm64-openssl-1.1.x",
    "linux-musl-arm64-openssl-3.0.x",
    "linux-nixos",
    "linux-static-x64",
    "linux-static-arm64",
    "windows",
    "freebsd11",
    "freebsd12",
    "freebsd13",
    "freebsd14",
    "freebsd15",
    "openbsd",
    "netbsd",
    "arm"
];
var Vt = "libquery_engine";
function Bt(e, r) {
    let t = r === "url";
    return e.includes("windows") ? t ? "query_engine.dll.node" : `query_engine-${e}.dll.node` : e.includes("darwin") ? t ? `${Vt}.dylib.node` : `${Vt}-${e}.dylib.node` : t ? `${Vt}.so.node` : `${Vt}-${e}.so.node`;
}
var Yo = k(__turbopack_context__.r("[externals]/node:child_process [external] (node:child_process, cjs)")), ci = k(__turbopack_context__.r("[externals]/node:fs/promises [external] (node:fs/promises, cjs)")), Jt = k(__turbopack_context__.r("[externals]/node:os [external] (node:os, cjs)"));
var De = Symbol.for("@ts-pattern/matcher"), Qu = Symbol.for("@ts-pattern/isVariadic"), Qt = "@ts-pattern/anonymous-select-key", si = (e)=>!!(e && typeof e == "object"), Ut = (e)=>e && !!e[De], Ee = (e, r, t)=>{
    if (Ut(e)) {
        let n = e[De](), { matched: i, selections: o } = n.match(r);
        return i && o && Object.keys(o).forEach((s)=>t(s, o[s])), i;
    }
    if (si(e)) {
        if (!si(r)) return !1;
        if (Array.isArray(e)) {
            if (!Array.isArray(r)) return !1;
            let n = [], i = [], o = [];
            for (let s of e.keys()){
                let a = e[s];
                Ut(a) && a[Qu] ? o.push(a) : o.length ? i.push(a) : n.push(a);
            }
            if (o.length) {
                if (o.length > 1) throw new Error("Pattern error: Using `...P.array(...)` several times in a single pattern is not allowed.");
                if (r.length < n.length + i.length) return !1;
                let s = r.slice(0, n.length), a = i.length === 0 ? [] : r.slice(-i.length), l = r.slice(n.length, i.length === 0 ? 1 / 0 : -i.length);
                return n.every((u, c)=>Ee(u, s[c], t)) && i.every((u, c)=>Ee(u, a[c], t)) && (o.length === 0 || Ee(o[0], l, t));
            }
            return e.length === r.length && e.every((s, a)=>Ee(s, r[a], t));
        }
        return Reflect.ownKeys(e).every((n)=>{
            let i = e[n];
            return (n in r || Ut(o = i) && o[De]().matcherType === "optional") && Ee(i, r[n], t);
            "TURBOPACK unreachable";
            var o;
        });
    }
    return Object.is(r, e);
}, Qe = (e)=>{
    var r, t, n;
    return si(e) ? Ut(e) ? (r = (t = (n = e[De]()).getSelectionKeys) == null ? void 0 : t.call(n)) != null ? r : [] : Array.isArray(e) ? zr(e, Qe) : zr(Object.values(e), Qe) : [];
}, zr = (e, r)=>e.reduce((t, n)=>t.concat(r(n)), []);
function pe(e) {
    return Object.assign(e, {
        optional: ()=>Gu(e),
        and: (r)=>q(e, r),
        or: (r)=>Wu(e, r),
        select: (r)=>r === void 0 ? Jo(e) : Jo(r, e)
    });
}
function Gu(e) {
    return pe({
        [De]: ()=>({
                match: (r)=>{
                    let t = {}, n = (i, o)=>{
                        t[i] = o;
                    };
                    return r === void 0 ? (Qe(e).forEach((i)=>n(i, void 0)), {
                        matched: !0,
                        selections: t
                    }) : {
                        matched: Ee(e, r, n),
                        selections: t
                    };
                },
                getSelectionKeys: ()=>Qe(e),
                matcherType: "optional"
            })
    });
}
function q(...e) {
    return pe({
        [De]: ()=>({
                match: (r)=>{
                    let t = {}, n = (i, o)=>{
                        t[i] = o;
                    };
                    return {
                        matched: e.every((i)=>Ee(i, r, n)),
                        selections: t
                    };
                },
                getSelectionKeys: ()=>zr(e, Qe),
                matcherType: "and"
            })
    });
}
function Wu(...e) {
    return pe({
        [De]: ()=>({
                match: (r)=>{
                    let t = {}, n = (i, o)=>{
                        t[i] = o;
                    };
                    return zr(e, Qe).forEach((i)=>n(i, void 0)), {
                        matched: e.some((i)=>Ee(i, r, n)),
                        selections: t
                    };
                },
                getSelectionKeys: ()=>zr(e, Qe),
                matcherType: "or"
            })
    });
}
function C(e) {
    return {
        [De]: ()=>({
                match: (r)=>({
                        matched: !!e(r)
                    })
            })
    };
}
function Jo(...e) {
    let r = typeof e[0] == "string" ? e[0] : void 0, t = e.length === 2 ? e[1] : typeof e[0] == "string" ? void 0 : e[0];
    return pe({
        [De]: ()=>({
                match: (n)=>{
                    let i = {
                        [r ?? Qt]: n
                    };
                    return {
                        matched: t === void 0 || Ee(t, n, (o, s)=>{
                            i[o] = s;
                        }),
                        selections: i
                    };
                },
                getSelectionKeys: ()=>[
                        r ?? Qt
                    ].concat(t === void 0 ? [] : Qe(t))
            })
    });
}
function ye(e) {
    return typeof e == "number";
}
function je(e) {
    return typeof e == "string";
}
function Ve(e) {
    return typeof e == "bigint";
}
var eg = pe(C(function(e) {
    return !0;
}));
var Be = (e)=>Object.assign(pe(e), {
        startsWith: (r)=>{
            return Be(q(e, (t = r, C((n)=>je(n) && n.startsWith(t)))));
            "TURBOPACK unreachable";
            var t;
        },
        endsWith: (r)=>{
            return Be(q(e, (t = r, C((n)=>je(n) && n.endsWith(t)))));
            "TURBOPACK unreachable";
            var t;
        },
        minLength: (r)=>Be(q(e, ((t)=>C((n)=>je(n) && n.length >= t))(r))),
        length: (r)=>Be(q(e, ((t)=>C((n)=>je(n) && n.length === t))(r))),
        maxLength: (r)=>Be(q(e, ((t)=>C((n)=>je(n) && n.length <= t))(r))),
        includes: (r)=>{
            return Be(q(e, (t = r, C((n)=>je(n) && n.includes(t)))));
            "TURBOPACK unreachable";
            var t;
        },
        regex: (r)=>{
            return Be(q(e, (t = r, C((n)=>je(n) && !!n.match(t)))));
            "TURBOPACK unreachable";
            var t;
        }
    }), rg = Be(C(je)), be = (e)=>Object.assign(pe(e), {
        between: (r, t)=>be(q(e, ((n, i)=>C((o)=>ye(o) && n <= o && i >= o))(r, t))),
        lt: (r)=>be(q(e, ((t)=>C((n)=>ye(n) && n < t))(r))),
        gt: (r)=>be(q(e, ((t)=>C((n)=>ye(n) && n > t))(r))),
        lte: (r)=>be(q(e, ((t)=>C((n)=>ye(n) && n <= t))(r))),
        gte: (r)=>be(q(e, ((t)=>C((n)=>ye(n) && n >= t))(r))),
        int: ()=>be(q(e, C((r)=>ye(r) && Number.isInteger(r)))),
        finite: ()=>be(q(e, C((r)=>ye(r) && Number.isFinite(r)))),
        positive: ()=>be(q(e, C((r)=>ye(r) && r > 0))),
        negative: ()=>be(q(e, C((r)=>ye(r) && r < 0)))
    }), tg = be(C(ye)), Ue = (e)=>Object.assign(pe(e), {
        between: (r, t)=>Ue(q(e, ((n, i)=>C((o)=>Ve(o) && n <= o && i >= o))(r, t))),
        lt: (r)=>Ue(q(e, ((t)=>C((n)=>Ve(n) && n < t))(r))),
        gt: (r)=>Ue(q(e, ((t)=>C((n)=>Ve(n) && n > t))(r))),
        lte: (r)=>Ue(q(e, ((t)=>C((n)=>Ve(n) && n <= t))(r))),
        gte: (r)=>Ue(q(e, ((t)=>C((n)=>Ve(n) && n >= t))(r))),
        positive: ()=>Ue(q(e, C((r)=>Ve(r) && r > 0))),
        negative: ()=>Ue(q(e, C((r)=>Ve(r) && r < 0)))
    }), ng = Ue(C(Ve)), ig = pe(C(function(e) {
    return typeof e == "boolean";
})), og = pe(C(function(e) {
    return typeof e == "symbol";
})), sg = pe(C(function(e) {
    return e == null;
})), ag = pe(C(function(e) {
    return e != null;
}));
var ai = class extends Error {
    constructor(r){
        let t;
        try {
            t = JSON.stringify(r);
        } catch  {
            t = r;
        }
        super(`Pattern matching error: no pattern matches value ${t}`), this.input = void 0, this.input = r;
    }
}, li = {
    matched: !1,
    value: void 0
};
function hr(e) {
    return new ui(e, li);
}
var ui = class e {
    constructor(r, t){
        this.input = void 0, this.state = void 0, this.input = r, this.state = t;
    }
    with(...r) {
        if (this.state.matched) return this;
        let t = r[r.length - 1], n = [
            r[0]
        ], i;
        r.length === 3 && typeof r[1] == "function" ? i = r[1] : r.length > 2 && n.push(...r.slice(1, r.length - 1));
        let o = !1, s = {}, a = (u, c)=>{
            o = !0, s[u] = c;
        }, l = !n.some((u)=>Ee(u, this.input, a)) || i && !i(this.input) ? li : {
            matched: !0,
            value: t(o ? Qt in s ? s[Qt] : s : this.input, this.input)
        };
        return new e(this.input, l);
    }
    when(r, t) {
        if (this.state.matched) return this;
        let n = !!r(this.input);
        return new e(this.input, n ? {
            matched: !0,
            value: t(this.input, this.input)
        } : li);
    }
    otherwise(r) {
        return this.state.matched ? this.state.value : r(this.input);
    }
    exhaustive() {
        if (this.state.matched) return this.state.value;
        throw new ai(this.input);
    }
    run() {
        return this.exhaustive();
    }
    returnType() {
        return this;
    }
};
var zo = __turbopack_context__.r("[externals]/node:util [external] (node:util, cjs)");
var Ju = {
    warn: ke("prisma:warn")
}, Hu = {
    warn: ()=>!process.env.PRISMA_DISABLE_WARNINGS
};
function Gt(e, ...r) {
    Hu.warn() && console.warn(`${Ju.warn} ${e}`, ...r);
}
var Ku = (0, zo.promisify)(Yo.default.exec), ee = gr("prisma:get-platform"), Yu = [
    "1.0.x",
    "1.1.x",
    "3.0.x"
];
async function Zo() {
    let e = Jt.default.platform(), r = process.arch;
    if (e === "freebsd") {
        let s = await Ht("freebsd-version");
        if (s && s.trim().length > 0) {
            let l = /^(\d+)\.?/.exec(s);
            if (l) return {
                platform: "freebsd",
                targetDistro: `freebsd${l[1]}`,
                arch: r
            };
        }
    }
    if (e !== "linux") return {
        platform: e,
        arch: r
    };
    let t = await Zu(), n = await sc(), i = ec({
        arch: r,
        archFromUname: n,
        familyDistro: t.familyDistro
    }), { libssl: o } = await rc(i);
    return {
        platform: "linux",
        libssl: o,
        arch: r,
        archFromUname: n,
        ...t
    };
}
function zu(e) {
    let r = /^ID="?([^"\n]*)"?$/im, t = /^ID_LIKE="?([^"\n]*)"?$/im, n = r.exec(e), i = n && n[1] && n[1].toLowerCase() || "", o = t.exec(e), s = o && o[1] && o[1].toLowerCase() || "", a = hr({
        id: i,
        idLike: s
    }).with({
        id: "alpine"
    }, ({ id: l })=>({
            targetDistro: "musl",
            familyDistro: l,
            originalDistro: l
        })).with({
        id: "raspbian"
    }, ({ id: l })=>({
            targetDistro: "arm",
            familyDistro: "debian",
            originalDistro: l
        })).with({
        id: "nixos"
    }, ({ id: l })=>({
            targetDistro: "nixos",
            originalDistro: l,
            familyDistro: "nixos"
        })).with({
        id: "debian"
    }, {
        id: "ubuntu"
    }, ({ id: l })=>({
            targetDistro: "debian",
            familyDistro: "debian",
            originalDistro: l
        })).with({
        id: "rhel"
    }, {
        id: "centos"
    }, {
        id: "fedora"
    }, ({ id: l })=>({
            targetDistro: "rhel",
            familyDistro: "rhel",
            originalDistro: l
        })).when(({ idLike: l })=>l.includes("debian") || l.includes("ubuntu"), ({ id: l })=>({
            targetDistro: "debian",
            familyDistro: "debian",
            originalDistro: l
        })).when(({ idLike: l })=>i === "arch" || l.includes("arch"), ({ id: l })=>({
            targetDistro: "debian",
            familyDistro: "arch",
            originalDistro: l
        })).when(({ idLike: l })=>l.includes("centos") || l.includes("fedora") || l.includes("rhel") || l.includes("suse"), ({ id: l })=>({
            targetDistro: "rhel",
            familyDistro: "rhel",
            originalDistro: l
        })).otherwise(({ id: l })=>({
            targetDistro: void 0,
            familyDistro: void 0,
            originalDistro: l
        }));
    return ee(`Found distro info:
${JSON.stringify(a, null, 2)}`), a;
}
async function Zu() {
    let e = "/etc/os-release";
    try {
        let r = await ci.default.readFile(e, {
            encoding: "utf-8"
        });
        return zu(r);
    } catch  {
        return {
            targetDistro: void 0,
            familyDistro: void 0,
            originalDistro: void 0
        };
    }
}
function Xu(e) {
    let r = /^OpenSSL\s(\d+\.\d+)\.\d+/.exec(e);
    if (r) {
        let t = `${r[1]}.x`;
        return Xo(t);
    }
}
function Ho(e) {
    let r = /libssl\.so\.(\d)(\.\d)?/.exec(e);
    if (r) {
        let t = `${r[1]}${r[2] ?? ".0"}.x`;
        return Xo(t);
    }
}
function Xo(e) {
    let r = (()=>{
        if (rs(e)) return e;
        let t = e.split(".");
        return t[1] = "0", t.join(".");
    })();
    if (Yu.includes(r)) return r;
}
function ec(e) {
    return hr(e).with({
        familyDistro: "musl"
    }, ()=>(ee('Trying platform-specific paths for "alpine"'), [
            "/lib",
            "/usr/lib"
        ])).with({
        familyDistro: "debian"
    }, ({ archFromUname: r })=>(ee('Trying platform-specific paths for "debian" (and "ubuntu")'), [
            `/usr/lib/${r}-linux-gnu`,
            `/lib/${r}-linux-gnu`
        ])).with({
        familyDistro: "rhel"
    }, ()=>(ee('Trying platform-specific paths for "rhel"'), [
            "/lib64",
            "/usr/lib64"
        ])).otherwise(({ familyDistro: r, arch: t, archFromUname: n })=>(ee(`Don't know any platform-specific paths for "${r}" on ${t} (${n})`), []));
}
async function rc(e) {
    let r = 'grep -v "libssl.so.0"', t = await Ko(e);
    if (t) {
        ee(`Found libssl.so file using platform-specific paths: ${t}`);
        let o = Ho(t);
        if (ee(`The parsed libssl version is: ${o}`), o) return {
            libssl: o,
            strategy: "libssl-specific-path"
        };
    }
    ee('Falling back to "ldconfig" and other generic paths');
    let n = await Ht(`ldconfig -p | sed "s/.*=>s*//" | sed "s|.*/||" | grep libssl | sort | ${r}`);
    if (n || (n = await Ko([
        "/lib64",
        "/usr/lib64",
        "/lib",
        "/usr/lib"
    ])), n) {
        ee(`Found libssl.so file using "ldconfig" or other generic paths: ${n}`);
        let o = Ho(n);
        if (ee(`The parsed libssl version is: ${o}`), o) return {
            libssl: o,
            strategy: "ldconfig"
        };
    }
    let i = await Ht("openssl version -v");
    if (i) {
        ee(`Found openssl binary with version: ${i}`);
        let o = Xu(i);
        if (ee(`The parsed openssl version is: ${o}`), o) return {
            libssl: o,
            strategy: "openssl-binary"
        };
    }
    return ee("Couldn't find any version of libssl or OpenSSL in the system"), {};
}
async function Ko(e) {
    for (let r of e){
        let t = await tc(r);
        if (t) return t;
    }
}
async function tc(e) {
    try {
        return (await ci.default.readdir(e)).find((t)=>t.startsWith("libssl.so.") && !t.startsWith("libssl.so.0"));
    } catch (r) {
        if (r.code === "ENOENT") return;
        throw r;
    }
}
async function ir() {
    let { binaryTarget: e } = await es();
    return e;
}
function nc(e) {
    return e.binaryTarget !== void 0;
}
async function pi() {
    let { memoized: e, ...r } = await es();
    return r;
}
var Wt = {};
async function es() {
    if (nc(Wt)) return Promise.resolve({
        ...Wt,
        memoized: !0
    });
    let e = await Zo(), r = ic(e);
    return Wt = {
        ...e,
        binaryTarget: r
    }, {
        ...Wt,
        memoized: !1
    };
}
function ic(e) {
    let { platform: r, arch: t, archFromUname: n, libssl: i, targetDistro: o, familyDistro: s, originalDistro: a } = e;
    r === "linux" && ![
        "x64",
        "arm64"
    ].includes(t) && Gt(`Prisma only officially supports Linux on amd64 (x86_64) and arm64 (aarch64) system architectures (detected "${t}" instead). If you are using your own custom Prisma engines, you can ignore this warning, as long as you've compiled the engines for your system architecture "${n}".`);
    let l = "1.1.x";
    if (r === "linux" && i === void 0) {
        let c = hr({
            familyDistro: s
        }).with({
            familyDistro: "debian"
        }, ()=>"Please manually install OpenSSL via `apt-get update -y && apt-get install -y openssl` and try installing Prisma again. If you're running Prisma on Docker, add this command to your Dockerfile, or switch to an image that already has OpenSSL installed.").otherwise(()=>"Please manually install OpenSSL and try installing Prisma again.");
        Gt(`Prisma failed to detect the libssl/openssl version to use, and may not work as expected. Defaulting to "openssl-${l}".
${c}`);
    }
    let u = "debian";
    if (r === "linux" && o === void 0 && ee(`Distro is "${a}". Falling back to Prisma engines built for "${u}".`), r === "darwin" && t === "arm64") return "darwin-arm64";
    if (r === "darwin") return "darwin";
    if (r === "win32") return "windows";
    if (r === "freebsd") return o;
    if (r === "openbsd") return "openbsd";
    if (r === "netbsd") return "netbsd";
    if (r === "linux" && o === "nixos") return "linux-nixos";
    if (r === "linux" && t === "arm64") return `${o === "musl" ? "linux-musl-arm64" : "linux-arm64"}-openssl-${i || l}`;
    if (r === "linux" && t === "arm") return `linux-arm-openssl-${i || l}`;
    if (r === "linux" && o === "musl") {
        let c = "linux-musl";
        return !i || rs(i) ? c : `${c}-openssl-${i}`;
    }
    return r === "linux" && o && i ? `${o}-openssl-${i}` : (r !== "linux" && Gt(`Prisma detected unknown OS "${r}" and may not work as expected. Defaulting to "linux".`), i ? `${u}-openssl-${i}` : o ? `${o}-openssl-${l}` : `${u}-openssl-${l}`);
}
async function oc(e) {
    try {
        return await e();
    } catch  {
        return;
    }
}
function Ht(e) {
    return oc(async ()=>{
        let r = await Ku(e);
        return ee(`Command "${e}" successfully returned "${r.stdout}"`), r.stdout;
    });
}
async function sc() {
    return typeof Jt.default.machine == "function" ? Jt.default.machine() : (await Ht("uname -m"))?.trim();
}
function rs(e) {
    return e.startsWith("1.");
}
var zt = {};
tr(zt, {
    beep: ()=>Dc,
    clearScreen: ()=>Ac,
    clearTerminal: ()=>Ic,
    cursorBackward: ()=>mc,
    cursorDown: ()=>pc,
    cursorForward: ()=>dc,
    cursorGetPosition: ()=>hc,
    cursorHide: ()=>Ec,
    cursorLeft: ()=>is,
    cursorMove: ()=>cc,
    cursorNextLine: ()=>yc,
    cursorPrevLine: ()=>bc,
    cursorRestorePosition: ()=>gc,
    cursorSavePosition: ()=>fc,
    cursorShow: ()=>wc,
    cursorTo: ()=>uc,
    cursorUp: ()=>ns,
    enterAlternativeScreen: ()=>kc,
    eraseDown: ()=>Tc,
    eraseEndLine: ()=>vc,
    eraseLine: ()=>os,
    eraseLines: ()=>xc,
    eraseScreen: ()=>di,
    eraseStartLine: ()=>Pc,
    eraseUp: ()=>Sc,
    exitAlternativeScreen: ()=>Oc,
    iTerm: ()=>Fc,
    image: ()=>Nc,
    link: ()=>_c,
    scrollDown: ()=>Cc,
    scrollUp: ()=>Rc
});
var Yt = k(__turbopack_context__.r("[externals]/node:process [external] (node:process, cjs)"), 1);
var Kt = globalThis.window?.document !== void 0, gg = globalThis.process?.versions?.node !== void 0, hg = globalThis.process?.versions?.bun !== void 0, yg = globalThis.Deno?.version?.deno !== void 0, bg = globalThis.process?.versions?.electron !== void 0, Eg = globalThis.navigator?.userAgent?.includes("jsdom") === !0, wg = typeof WorkerGlobalScope < "u" && globalThis instanceof WorkerGlobalScope, xg = typeof DedicatedWorkerGlobalScope < "u" && globalThis instanceof DedicatedWorkerGlobalScope, vg = typeof SharedWorkerGlobalScope < "u" && globalThis instanceof SharedWorkerGlobalScope, Pg = typeof ServiceWorkerGlobalScope < "u" && globalThis instanceof ServiceWorkerGlobalScope, Zr = globalThis.navigator?.userAgentData?.platform, Tg = Zr === "macOS" || globalThis.navigator?.platform === "MacIntel" || globalThis.navigator?.userAgent?.includes(" Mac ") === !0 || globalThis.process?.platform === "darwin", Sg = Zr === "Windows" || globalThis.navigator?.platform === "Win32" || globalThis.process?.platform === "win32", Rg = Zr === "Linux" || globalThis.navigator?.platform?.startsWith("Linux") === !0 || globalThis.navigator?.userAgent?.includes(" Linux ") === !0 || globalThis.process?.platform === "linux", Cg = Zr === "iOS" || globalThis.navigator?.platform === "MacIntel" && globalThis.navigator?.maxTouchPoints > 1 || /iPad|iPhone|iPod/.test(globalThis.navigator?.platform), Ag = Zr === "Android" || globalThis.navigator?.platform === "Android" || globalThis.navigator?.userAgent?.includes(" Android ") === !0 || globalThis.process?.platform === "android";
var A = "\x1B[", et = "\x1B]", yr = "\x07", Xr = ";", ts = !Kt && Yt.default.env.TERM_PROGRAM === "Apple_Terminal", ac = !Kt && Yt.default.platform === "win32", lc = Kt ? ()=>{
    throw new Error("`process.cwd()` only works in Node.js, not the browser.");
} : Yt.default.cwd, uc = (e, r)=>{
    if (typeof e != "number") throw new TypeError("The `x` argument is required");
    return typeof r != "number" ? A + (e + 1) + "G" : A + (r + 1) + Xr + (e + 1) + "H";
}, cc = (e, r)=>{
    if (typeof e != "number") throw new TypeError("The `x` argument is required");
    let t = "";
    return e < 0 ? t += A + -e + "D" : e > 0 && (t += A + e + "C"), r < 0 ? t += A + -r + "A" : r > 0 && (t += A + r + "B"), t;
}, ns = (e = 1)=>A + e + "A", pc = (e = 1)=>A + e + "B", dc = (e = 1)=>A + e + "C", mc = (e = 1)=>A + e + "D", is = A + "G", fc = ts ? "\x1B7" : A + "s", gc = ts ? "\x1B8" : A + "u", hc = A + "6n", yc = A + "E", bc = A + "F", Ec = A + "?25l", wc = A + "?25h", xc = (e)=>{
    let r = "";
    for(let t = 0; t < e; t++)r += os + (t < e - 1 ? ns() : "");
    return e && (r += is), r;
}, vc = A + "K", Pc = A + "1K", os = A + "2K", Tc = A + "J", Sc = A + "1J", di = A + "2J", Rc = A + "S", Cc = A + "T", Ac = "\x1Bc", Ic = ac ? `${di}${A}0f` : `${di}${A}3J${A}H`, kc = A + "?1049h", Oc = A + "?1049l", Dc = yr, _c = (e, r)=>[
        et,
        "8",
        Xr,
        Xr,
        r,
        yr,
        e,
        et,
        "8",
        Xr,
        Xr,
        yr
    ].join(""), Nc = (e, r = {})=>{
    let t = `${et}1337;File=inline=1`;
    return r.width && (t += `;width=${r.width}`), r.height && (t += `;height=${r.height}`), r.preserveAspectRatio === !1 && (t += ";preserveAspectRatio=0"), t + ":" + Buffer.from(e).toString("base64") + yr;
}, Fc = {
    setCwd: (e = lc())=>`${et}50;CurrentDir=${e}${yr}`,
    annotation (e, r = {}) {
        let t = `${et}1337;`, n = r.x !== void 0, i = r.y !== void 0;
        if ((n || i) && !(n && i && r.length !== void 0)) throw new Error("`x`, `y` and `length` must be defined when `x` or `y` is defined");
        return e = e.replaceAll("|", ""), t += r.isHidden ? "AddHiddenAnnotation=" : "AddAnnotation=", r.length > 0 ? t += (n ? [
            e,
            r.length,
            r.x,
            r.y
        ] : [
            r.length,
            e
        ]).join("|") : t += e, t + yr;
    }
};
var Zt = k(ds(), 1);
function or(e, r, { target: t = "stdout", ...n } = {}) {
    return Zt.default[t] ? zt.link(e, r) : n.fallback === !1 ? e : typeof n.fallback == "function" ? n.fallback(e, r) : `${e} (\u200B${r}\u200B)`;
}
or.isSupported = Zt.default.stdout;
or.stderr = (e, r, t = {})=>or(e, r, {
        target: "stderr",
        ...t
    });
or.stderr.isSupported = Zt.default.stderr;
function yi(e) {
    return or(e, e, {
        fallback: Y
    });
}
var jc = ms(), bi = jc.version;
function Er(e) {
    let r = Vc();
    return r || (e?.config.engineType === "library" ? "library" : e?.config.engineType === "binary" ? "binary" : e?.config.engineType === "client" ? "client" : Bc(e));
}
function Vc() {
    let e = process.env.PRISMA_CLIENT_ENGINE_TYPE;
    return e === "library" ? "library" : e === "binary" ? "binary" : e === "client" ? "client" : void 0;
}
function Bc(e) {
    return e?.previewFeatures.includes("queryCompiler") ? "client" : "library";
}
var Qc = k(wi());
var M = k(__turbopack_context__.r("[externals]/node:path [external] (node:path, cjs)")), Gc = k(wi()), ah = N("prisma:engines");
function fs() {
    return M.default.join(__dirname, "../");
}
var lh = "libquery-engine";
M.default.join(__dirname, "../query-engine-darwin");
M.default.join(__dirname, "../query-engine-darwin-arm64");
M.default.join(__dirname, "../query-engine-debian-openssl-1.0.x");
M.default.join(__dirname, "../query-engine-debian-openssl-1.1.x");
M.default.join(__dirname, "../query-engine-debian-openssl-3.0.x");
M.default.join(__dirname, "../query-engine-linux-static-x64");
M.default.join(__dirname, "../query-engine-linux-static-arm64");
M.default.join(__dirname, "../query-engine-rhel-openssl-1.0.x");
M.default.join(__dirname, "../query-engine-rhel-openssl-1.1.x");
M.default.join(__dirname, "../query-engine-rhel-openssl-3.0.x");
M.default.join(__dirname, "../libquery_engine-darwin.dylib.node");
M.default.join(__dirname, "../libquery_engine-darwin-arm64.dylib.node");
M.default.join(__dirname, "../libquery_engine-debian-openssl-1.0.x.so.node");
M.default.join(__dirname, "../libquery_engine-debian-openssl-1.1.x.so.node");
M.default.join(__dirname, "../libquery_engine-debian-openssl-3.0.x.so.node");
M.default.join(__dirname, "../libquery_engine-linux-arm64-openssl-1.0.x.so.node");
M.default.join(__dirname, "../libquery_engine-linux-arm64-openssl-1.1.x.so.node");
M.default.join(__dirname, "../libquery_engine-linux-arm64-openssl-3.0.x.so.node");
M.default.join(__dirname, "../libquery_engine-linux-musl.so.node");
M.default.join(__dirname, "../libquery_engine-linux-musl-openssl-3.0.x.so.node");
M.default.join(__dirname, "../libquery_engine-rhel-openssl-1.0.x.so.node");
M.default.join(__dirname, "../libquery_engine-rhel-openssl-1.1.x.so.node");
M.default.join(__dirname, "../libquery_engine-rhel-openssl-3.0.x.so.node");
M.default.join(__dirname, "../query_engine-windows.dll.node");
var xi = k(__turbopack_context__.r("[externals]/node:fs [external] (node:fs, cjs)")), gs = gr("chmodPlusX");
function vi(e) {
    if ("TURBOPACK compile-time truthy", 1) return;
    "TURBOPACK unreachable";
    let r, t;
    let n;
}
function Pi(e) {
    let r = e.e, t = (a)=>`Prisma cannot find the required \`${a}\` system library in your system`, n = r.message.includes("cannot open shared object file"), i = `Please refer to the documentation about Prisma's system requirements: ${yi("https://pris.ly/d/system-requirements")}`, o = `Unable to require(\`${Ie(e.id)}\`).`, s = hr({
        message: r.message,
        code: r.code
    }).with({
        code: "ENOENT"
    }, ()=>"File does not exist.").when(({ message: a })=>n && a.includes("libz"), ()=>`${t("libz")}. Please install it and try again.`).when(({ message: a })=>n && a.includes("libgcc_s"), ()=>`${t("libgcc_s")}. Please install it and try again.`).when(({ message: a })=>n && a.includes("libssl"), ()=>{
        let a = e.platformInfo.libssl ? `openssl-${e.platformInfo.libssl}` : "openssl";
        return `${t("libssl")}. Please install ${a} and try again.`;
    }).when(({ message: a })=>a.includes("GLIBC"), ()=>`Prisma has detected an incompatible version of the \`glibc\` C standard library installed in your system. This probably means your system may be too old to run Prisma. ${i}`).when(({ message: a })=>e.platformInfo.platform === "linux" && a.includes("symbol not found"), ()=>`The Prisma engines are not compatible with your system ${e.platformInfo.originalDistro} on (${e.platformInfo.archFromUname}) which uses the \`${e.platformInfo.binaryTarget}\` binaryTarget by default. ${i}`).otherwise(()=>`The Prisma engines do not seem to be compatible with your system. ${i}`);
    return `${o}
${s}

Details: ${r.message}`;
}
var bs = k(ys(), 1);
function Ti(e) {
    let r = (0, bs.default)(e);
    if (r === 0) return e;
    let t = new RegExp(`^[ \\t]{${r}}`, "gm");
    return e.replace(t, "");
}
var Es = "prisma+postgres", en = `${Es}:`;
function Si(e) {
    return e?.startsWith(`${en}//`) ?? !1;
}
var xs = k(Ri());
function Ai(e) {
    return String(new Ci(e));
}
var Ci = class {
    constructor(r){
        this.config = r;
    }
    toString() {
        let { config: r } = this, t = r.provider.fromEnvVar ? `env("${r.provider.fromEnvVar}")` : r.provider.value, n = JSON.parse(JSON.stringify({
            provider: t,
            binaryTargets: Wc(r.binaryTargets)
        }));
        return `generator ${r.name} {
${(0, xs.default)(Jc(n), 2)}
}`;
    }
};
function Wc(e) {
    let r;
    if (e.length > 0) {
        let t = e.find((n)=>n.fromEnvVar !== null);
        t ? r = `env("${t.fromEnvVar}")` : r = e.map((n)=>n.native ? "native" : n.value);
    } else r = void 0;
    return r;
}
function Jc(e) {
    let r = Object.keys(e).reduce((t, n)=>Math.max(t, n.length), 0);
    return Object.entries(e).map(([t, n])=>`${t.padEnd(r)} = ${Hc(n)}`).join(`
`);
}
function Hc(e) {
    return JSON.parse(JSON.stringify(e, (r, t)=>Array.isArray(t) ? `[${t.map((n)=>JSON.stringify(n)).join(", ")}]` : JSON.stringify(t)));
}
var tt = {};
tr(tt, {
    error: ()=>zc,
    info: ()=>Yc,
    log: ()=>Kc,
    query: ()=>Zc,
    should: ()=>vs,
    tags: ()=>rt,
    warn: ()=>Ii
});
var rt = {
    error: ce("prisma:error"),
    warn: ke("prisma:warn"),
    info: Oe("prisma:info"),
    query: nr("prisma:query")
}, vs = {
    warn: ()=>!process.env.PRISMA_DISABLE_WARNINGS
};
function Kc(...e) {
    console.log(...e);
}
function Ii(e, ...r) {
    vs.warn() && console.warn(`${rt.warn} ${e}`, ...r);
}
function Yc(e, ...r) {
    console.info(`${rt.info} ${e}`, ...r);
}
function zc(e, ...r) {
    console.error(`${rt.error} ${e}`, ...r);
}
function Zc(e, ...r) {
    console.log(`${rt.query} ${e}`, ...r);
}
function rn(e, r) {
    if (!e) throw new Error(`${r}. This should never happen. If you see this error, please, open an issue at https://pris.ly/prisma-prisma-bug-report`);
}
function _e(e, r) {
    throw new Error(r);
}
var nt = k(__turbopack_context__.r("[externals]/node:path [external] (node:path, cjs)"));
function Oi(e) {
    return nt.default.sep === nt.default.posix.sep ? e : e.split(nt.default.sep).join(nt.default.posix.sep);
}
var Li = k(ks()), nn = k(__turbopack_context__.r("[externals]/node:fs [external] (node:fs, cjs)"));
var wr = k(__turbopack_context__.r("[externals]/node:path [external] (node:path, cjs)"));
function Os(e) {
    let r = e.ignoreProcessEnv ? {} : process.env, t = (n)=>n.match(/(.?\${(?:[a-zA-Z0-9_]+)?})/g)?.reduce(function(o, s) {
            let a = /(.?)\${([a-zA-Z0-9_]+)?}/g.exec(s);
            if (!a) return o;
            let l = a[1], u, c;
            if (l === "\\") c = a[0], u = c.replace("\\$", "$");
            else {
                let p = a[2];
                c = a[0].substring(l.length), u = Object.hasOwnProperty.call(r, p) ? r[p] : e.parsed[p] || "", u = t(u);
            }
            return o.replace(c, u);
        }, n) ?? n;
    for(let n in e.parsed){
        let i = Object.hasOwnProperty.call(r, n) ? r[n] : e.parsed[n];
        e.parsed[n] = t(i);
    }
    for(let n in e.parsed)r[n] = e.parsed[n];
    return e;
}
var Fi = gr("prisma:tryLoadEnv");
function it({ rootEnvPath: e, schemaEnvPath: r }, t = {
    conflictCheck: "none"
}) {
    let n = Ds(e);
    t.conflictCheck !== "none" && gp(n, r, t.conflictCheck);
    let i = null;
    return _s(n?.path, r) || (i = Ds(r)), !n && !i && Fi("No Environment variables loaded"), i?.dotenvResult.error ? console.error(ce(W("Schema Env Error: ")) + i.dotenvResult.error) : {
        message: [
            n?.message,
            i?.message
        ].filter(Boolean).join(`
`),
        parsed: {
            ...n?.dotenvResult?.parsed,
            ...i?.dotenvResult?.parsed
        }
    };
}
function gp(e, r, t) {
    let n = e?.dotenvResult.parsed, i = !_s(e?.path, r);
    if (n && r && i && nn.default.existsSync(r)) {
        let o = Li.default.parse(nn.default.readFileSync(r)), s = [];
        for(let a in o)n[a] === o[a] && s.push(a);
        if (s.length > 0) {
            let a = wr.default.relative(process.cwd(), e.path), l = wr.default.relative(process.cwd(), r);
            if (t === "error") {
                let u = `There is a conflict between env var${s.length > 1 ? "s" : ""} in ${Y(a)} and ${Y(l)}
Conflicting env vars:
${s.map((c)=>`  ${W(c)}`).join(`
`)}

We suggest to move the contents of ${Y(l)} to ${Y(a)} to consolidate your env vars.
`;
                throw new Error(u);
            } else if (t === "warn") {
                let u = `Conflict for env var${s.length > 1 ? "s" : ""} ${s.map((c)=>W(c)).join(", ")} in ${Y(a)} and ${Y(l)}
Env vars from ${Y(l)} overwrite the ones from ${Y(a)}
      `;
                console.warn(`${ke("warn(prisma)")} ${u}`);
            }
        }
    }
}
function Ds(e) {
    if (hp(e)) {
        Fi(`Environment variables loaded from ${e}`);
        let r = Li.default.config({
            path: e,
            debug: process.env.DOTENV_CONFIG_DEBUG ? !0 : void 0
        });
        return {
            dotenvResult: Os(r),
            message: Ie(`Environment variables loaded from ${wr.default.relative(process.cwd(), e)}`),
            path: e
        };
    } else Fi(`Environment variables not found at ${e}`);
    return null;
}
function _s(e, r) {
    return e && r && wr.default.resolve(e) === wr.default.resolve(r);
}
function hp(e) {
    return !!(e && nn.default.existsSync(e));
}
function Mi(e, r) {
    return Object.prototype.hasOwnProperty.call(e, r);
}
function xr(e, r) {
    let t = {};
    for (let n of Object.keys(e))t[n] = r(e[n], n);
    return t;
}
function $i(e, r) {
    if (e.length === 0) return;
    let t = e[0];
    for(let n = 1; n < e.length; n++)r(t, e[n]) < 0 && (t = e[n]);
    return t;
}
function x(e, r) {
    Object.defineProperty(e, "name", {
        value: r,
        configurable: !0
    });
}
var Fs = new Set, ot = (e, r, ...t)=>{
    Fs.has(e) || (Fs.add(e), Ii(r, ...t));
};
var T = class e extends Error {
    clientVersion;
    errorCode;
    retryable;
    constructor(r, t, n){
        super(r), this.name = "PrismaClientInitializationError", this.clientVersion = t, this.errorCode = n, Error.captureStackTrace(e);
    }
    get [Symbol.toStringTag]() {
        return "PrismaClientInitializationError";
    }
};
x(T, "PrismaClientInitializationError");
var z = class extends Error {
    code;
    meta;
    clientVersion;
    batchRequestIdx;
    constructor(r, { code: t, clientVersion: n, meta: i, batchRequestIdx: o }){
        super(r), this.name = "PrismaClientKnownRequestError", this.code = t, this.clientVersion = n, this.meta = i, Object.defineProperty(this, "batchRequestIdx", {
            value: o,
            enumerable: !1,
            writable: !0
        });
    }
    get [Symbol.toStringTag]() {
        return "PrismaClientKnownRequestError";
    }
};
x(z, "PrismaClientKnownRequestError");
var le = class extends Error {
    clientVersion;
    constructor(r, t){
        super(r), this.name = "PrismaClientRustPanicError", this.clientVersion = t;
    }
    get [Symbol.toStringTag]() {
        return "PrismaClientRustPanicError";
    }
};
x(le, "PrismaClientRustPanicError");
var j = class extends Error {
    clientVersion;
    batchRequestIdx;
    constructor(r, { clientVersion: t, batchRequestIdx: n }){
        super(r), this.name = "PrismaClientUnknownRequestError", this.clientVersion = t, Object.defineProperty(this, "batchRequestIdx", {
            value: n,
            writable: !0,
            enumerable: !1
        });
    }
    get [Symbol.toStringTag]() {
        return "PrismaClientUnknownRequestError";
    }
};
x(j, "PrismaClientUnknownRequestError");
var Z = class extends Error {
    name = "PrismaClientValidationError";
    clientVersion;
    constructor(r, { clientVersion: t }){
        super(r), this.clientVersion = t;
    }
    get [Symbol.toStringTag]() {
        return "PrismaClientValidationError";
    }
};
x(Z, "PrismaClientValidationError");
var vr = 9e15, Ke = 1e9, qi = "0123456789abcdef", un = "2.3025850929940456840179914546843642076011014886287729760333279009675726096773524802359972050895982983419677840422862486334095254650828067566662873690987816894829072083255546808437998948262331985283935053089653777326288461633662222876982198867465436674744042432743651550489343149393914796194044002221051017141748003688084012647080685567743216228355220114804663715659121373450747856947683463616792101806445070648000277502684916746550586856935673420670581136429224554405758925724208241314695689016758940256776311356919292033376587141660230105703089634572075440370847469940168269282808481184289314848524948644871927809676271275775397027668605952496716674183485704422507197965004714951050492214776567636938662976979522110718264549734772662425709429322582798502585509785265383207606726317164309505995087807523710333101197857547331541421808427543863591778117054309827482385045648019095610299291824318237525357709750539565187697510374970888692180205189339507238539205144634197265287286965110862571492198849978748873771345686209167058", cn = "3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679821480865132823066470938446095505822317253594081284811174502841027019385211055596446229489549303819644288109756659334461284756482337867831652712019091456485669234603486104543266482133936072602491412737245870066063155881748815209209628292540917153643678925903600113305305488204665213841469519415116094330572703657595919530921861173819326117931051185480744623799627495673518857527248912279381830119491298336733624406566430860213949463952247371907021798609437027705392171762931767523846748184676694051320005681271452635608277857713427577896091736371787214684409012249534301465495853710507922796892589235420199561121290219608640344181598136297747713099605187072113499999983729780499510597317328160963185950244594553469083026425223082533446850352619311881710100031378387528865875332083814206171776691473035982534904287554687311595628638823537875937519577818577805321712268066130019278766111959092164201989380952572010654858632789", ji = {
    precision: 20,
    rounding: 4,
    modulo: 1,
    toExpNeg: -7,
    toExpPos: 21,
    minE: -vr,
    maxE: vr,
    crypto: !1
}, qs, Fe, w = !0, dn = "[DecimalError] ", He = dn + "Invalid argument: ", js = dn + "Precision limit exceeded", Vs = dn + "crypto unavailable", Bs = "[object Decimal]", X = Math.floor, U = Math.pow, yp = /^0b([01]+(\.[01]*)?|\.[01]+)(p[+-]?\d+)?$/i, bp = /^0x([0-9a-f]+(\.[0-9a-f]*)?|\.[0-9a-f]+)(p[+-]?\d+)?$/i, Ep = /^0o([0-7]+(\.[0-7]*)?|\.[0-7]+)(p[+-]?\d+)?$/i, Us = /^(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?$/i, fe = 1e7, E = 7, wp = 9007199254740991, xp = un.length - 1, Vi = cn.length - 1, m = {
    toStringTag: Bs
};
m.absoluteValue = m.abs = function() {
    var e = new this.constructor(this);
    return e.s < 0 && (e.s = 1), y(e);
};
m.ceil = function() {
    return y(new this.constructor(this), this.e + 1, 2);
};
m.clampedTo = m.clamp = function(e, r) {
    var t, n = this, i = n.constructor;
    if (e = new i(e), r = new i(r), !e.s || !r.s) return new i(NaN);
    if (e.gt(r)) throw Error(He + r);
    return t = n.cmp(e), t < 0 ? e : n.cmp(r) > 0 ? r : new i(n);
};
m.comparedTo = m.cmp = function(e) {
    var r, t, n, i, o = this, s = o.d, a = (e = new o.constructor(e)).d, l = o.s, u = e.s;
    if (!s || !a) return !l || !u ? NaN : l !== u ? l : s === a ? 0 : !s ^ l < 0 ? 1 : -1;
    if (!s[0] || !a[0]) return s[0] ? l : a[0] ? -u : 0;
    if (l !== u) return l;
    if (o.e !== e.e) return o.e > e.e ^ l < 0 ? 1 : -1;
    for(n = s.length, i = a.length, r = 0, t = n < i ? n : i; r < t; ++r)if (s[r] !== a[r]) return s[r] > a[r] ^ l < 0 ? 1 : -1;
    return n === i ? 0 : n > i ^ l < 0 ? 1 : -1;
};
m.cosine = m.cos = function() {
    var e, r, t = this, n = t.constructor;
    return t.d ? t.d[0] ? (e = n.precision, r = n.rounding, n.precision = e + Math.max(t.e, t.sd()) + E, n.rounding = 1, t = vp(n, Hs(n, t)), n.precision = e, n.rounding = r, y(Fe == 2 || Fe == 3 ? t.neg() : t, e, r, !0)) : new n(1) : new n(NaN);
};
m.cubeRoot = m.cbrt = function() {
    var e, r, t, n, i, o, s, a, l, u, c = this, p = c.constructor;
    if (!c.isFinite() || c.isZero()) return new p(c);
    for(w = !1, o = c.s * U(c.s * c, 1 / 3), !o || Math.abs(o) == 1 / 0 ? (t = J(c.d), e = c.e, (o = (e - t.length + 1) % 3) && (t += o == 1 || o == -2 ? "0" : "00"), o = U(t, 1 / 3), e = X((e + 1) / 3) - (e % 3 == (e < 0 ? -1 : 2)), o == 1 / 0 ? t = "5e" + e : (t = o.toExponential(), t = t.slice(0, t.indexOf("e") + 1) + e), n = new p(t), n.s = c.s) : n = new p(o.toString()), s = (e = p.precision) + 3;;)if (a = n, l = a.times(a).times(a), u = l.plus(c), n = F(u.plus(c).times(a), u.plus(l), s + 2, 1), J(a.d).slice(0, s) === (t = J(n.d)).slice(0, s)) if (t = t.slice(s - 3, s + 1), t == "9999" || !i && t == "4999") {
        if (!i && (y(a, e + 1, 0), a.times(a).times(a).eq(c))) {
            n = a;
            break;
        }
        s += 4, i = 1;
    } else {
        (!+t || !+t.slice(1) && t.charAt(0) == "5") && (y(n, e + 1, 1), r = !n.times(n).times(n).eq(c));
        break;
    }
    return w = !0, y(n, e, p.rounding, r);
};
m.decimalPlaces = m.dp = function() {
    var e, r = this.d, t = NaN;
    if (r) {
        if (e = r.length - 1, t = (e - X(this.e / E)) * E, e = r[e], e) for(; e % 10 == 0; e /= 10)t--;
        t < 0 && (t = 0);
    }
    return t;
};
m.dividedBy = m.div = function(e) {
    return F(this, new this.constructor(e));
};
m.dividedToIntegerBy = m.divToInt = function(e) {
    var r = this, t = r.constructor;
    return y(F(r, new t(e), 0, 1, 1), t.precision, t.rounding);
};
m.equals = m.eq = function(e) {
    return this.cmp(e) === 0;
};
m.floor = function() {
    return y(new this.constructor(this), this.e + 1, 3);
};
m.greaterThan = m.gt = function(e) {
    return this.cmp(e) > 0;
};
m.greaterThanOrEqualTo = m.gte = function(e) {
    var r = this.cmp(e);
    return r == 1 || r === 0;
};
m.hyperbolicCosine = m.cosh = function() {
    var e, r, t, n, i, o = this, s = o.constructor, a = new s(1);
    if (!o.isFinite()) return new s(o.s ? 1 / 0 : NaN);
    if (o.isZero()) return a;
    t = s.precision, n = s.rounding, s.precision = t + Math.max(o.e, o.sd()) + 4, s.rounding = 1, i = o.d.length, i < 32 ? (e = Math.ceil(i / 3), r = (1 / fn(4, e)).toString()) : (e = 16, r = "2.3283064365386962890625e-10"), o = Pr(s, 1, o.times(r), new s(1), !0);
    for(var l, u = e, c = new s(8); u--;)l = o.times(o), o = a.minus(l.times(c.minus(l.times(c))));
    return y(o, s.precision = t, s.rounding = n, !0);
};
m.hyperbolicSine = m.sinh = function() {
    var e, r, t, n, i = this, o = i.constructor;
    if (!i.isFinite() || i.isZero()) return new o(i);
    if (r = o.precision, t = o.rounding, o.precision = r + Math.max(i.e, i.sd()) + 4, o.rounding = 1, n = i.d.length, n < 3) i = Pr(o, 2, i, i, !0);
    else {
        e = 1.4 * Math.sqrt(n), e = e > 16 ? 16 : e | 0, i = i.times(1 / fn(5, e)), i = Pr(o, 2, i, i, !0);
        for(var s, a = new o(5), l = new o(16), u = new o(20); e--;)s = i.times(i), i = i.times(a.plus(s.times(l.times(s).plus(u))));
    }
    return o.precision = r, o.rounding = t, y(i, r, t, !0);
};
m.hyperbolicTangent = m.tanh = function() {
    var e, r, t = this, n = t.constructor;
    return t.isFinite() ? t.isZero() ? new n(t) : (e = n.precision, r = n.rounding, n.precision = e + 7, n.rounding = 1, F(t.sinh(), t.cosh(), n.precision = e, n.rounding = r)) : new n(t.s);
};
m.inverseCosine = m.acos = function() {
    var e = this, r = e.constructor, t = e.abs().cmp(1), n = r.precision, i = r.rounding;
    return t !== -1 ? t === 0 ? e.isNeg() ? we(r, n, i) : new r(0) : new r(NaN) : e.isZero() ? we(r, n + 4, i).times(.5) : (r.precision = n + 6, r.rounding = 1, e = new r(1).minus(e).div(e.plus(1)).sqrt().atan(), r.precision = n, r.rounding = i, e.times(2));
};
m.inverseHyperbolicCosine = m.acosh = function() {
    var e, r, t = this, n = t.constructor;
    return t.lte(1) ? new n(t.eq(1) ? 0 : NaN) : t.isFinite() ? (e = n.precision, r = n.rounding, n.precision = e + Math.max(Math.abs(t.e), t.sd()) + 4, n.rounding = 1, w = !1, t = t.times(t).minus(1).sqrt().plus(t), w = !0, n.precision = e, n.rounding = r, t.ln()) : new n(t);
};
m.inverseHyperbolicSine = m.asinh = function() {
    var e, r, t = this, n = t.constructor;
    return !t.isFinite() || t.isZero() ? new n(t) : (e = n.precision, r = n.rounding, n.precision = e + 2 * Math.max(Math.abs(t.e), t.sd()) + 6, n.rounding = 1, w = !1, t = t.times(t).plus(1).sqrt().plus(t), w = !0, n.precision = e, n.rounding = r, t.ln());
};
m.inverseHyperbolicTangent = m.atanh = function() {
    var e, r, t, n, i = this, o = i.constructor;
    return i.isFinite() ? i.e >= 0 ? new o(i.abs().eq(1) ? i.s / 0 : i.isZero() ? i : NaN) : (e = o.precision, r = o.rounding, n = i.sd(), Math.max(n, e) < 2 * -i.e - 1 ? y(new o(i), e, r, !0) : (o.precision = t = n - i.e, i = F(i.plus(1), new o(1).minus(i), t + e, 1), o.precision = e + 4, o.rounding = 1, i = i.ln(), o.precision = e, o.rounding = r, i.times(.5))) : new o(NaN);
};
m.inverseSine = m.asin = function() {
    var e, r, t, n, i = this, o = i.constructor;
    return i.isZero() ? new o(i) : (r = i.abs().cmp(1), t = o.precision, n = o.rounding, r !== -1 ? r === 0 ? (e = we(o, t + 4, n).times(.5), e.s = i.s, e) : new o(NaN) : (o.precision = t + 6, o.rounding = 1, i = i.div(new o(1).minus(i.times(i)).sqrt().plus(1)).atan(), o.precision = t, o.rounding = n, i.times(2)));
};
m.inverseTangent = m.atan = function() {
    var e, r, t, n, i, o, s, a, l, u = this, c = u.constructor, p = c.precision, d = c.rounding;
    if (u.isFinite()) {
        if (u.isZero()) return new c(u);
        if (u.abs().eq(1) && p + 4 <= Vi) return s = we(c, p + 4, d).times(.25), s.s = u.s, s;
    } else {
        if (!u.s) return new c(NaN);
        if (p + 4 <= Vi) return s = we(c, p + 4, d).times(.5), s.s = u.s, s;
    }
    for(c.precision = a = p + 10, c.rounding = 1, t = Math.min(28, a / E + 2 | 0), e = t; e; --e)u = u.div(u.times(u).plus(1).sqrt().plus(1));
    for(w = !1, r = Math.ceil(a / E), n = 1, l = u.times(u), s = new c(u), i = u; e !== -1;)if (i = i.times(l), o = s.minus(i.div(n += 2)), i = i.times(l), s = o.plus(i.div(n += 2)), s.d[r] !== void 0) for(e = r; s.d[e] === o.d[e] && e--;);
    return t && (s = s.times(2 << t - 1)), w = !0, y(s, c.precision = p, c.rounding = d, !0);
};
m.isFinite = function() {
    return !!this.d;
};
m.isInteger = m.isInt = function() {
    return !!this.d && X(this.e / E) > this.d.length - 2;
};
m.isNaN = function() {
    return !this.s;
};
m.isNegative = m.isNeg = function() {
    return this.s < 0;
};
m.isPositive = m.isPos = function() {
    return this.s > 0;
};
m.isZero = function() {
    return !!this.d && this.d[0] === 0;
};
m.lessThan = m.lt = function(e) {
    return this.cmp(e) < 0;
};
m.lessThanOrEqualTo = m.lte = function(e) {
    return this.cmp(e) < 1;
};
m.logarithm = m.log = function(e) {
    var r, t, n, i, o, s, a, l, u = this, c = u.constructor, p = c.precision, d = c.rounding, f = 5;
    if (e == null) e = new c(10), r = !0;
    else {
        if (e = new c(e), t = e.d, e.s < 0 || !t || !t[0] || e.eq(1)) return new c(NaN);
        r = e.eq(10);
    }
    if (t = u.d, u.s < 0 || !t || !t[0] || u.eq(1)) return new c(t && !t[0] ? -1 / 0 : u.s != 1 ? NaN : t ? 0 : 1 / 0);
    if (r) if (t.length > 1) o = !0;
    else {
        for(i = t[0]; i % 10 === 0;)i /= 10;
        o = i !== 1;
    }
    if (w = !1, a = p + f, s = Je(u, a), n = r ? pn(c, a + 10) : Je(e, a), l = F(s, n, a, 1), st(l.d, i = p, d)) do if (a += 10, s = Je(u, a), n = r ? pn(c, a + 10) : Je(e, a), l = F(s, n, a, 1), !o) {
        +J(l.d).slice(i + 1, i + 15) + 1 == 1e14 && (l = y(l, p + 1, 0));
        break;
    }
    while (st(l.d, i += 10, d))
    return w = !0, y(l, p, d);
};
m.minus = m.sub = function(e) {
    var r, t, n, i, o, s, a, l, u, c, p, d, f = this, g = f.constructor;
    if (e = new g(e), !f.d || !e.d) return !f.s || !e.s ? e = new g(NaN) : f.d ? e.s = -e.s : e = new g(e.d || f.s !== e.s ? f : NaN), e;
    if (f.s != e.s) return e.s = -e.s, f.plus(e);
    if (u = f.d, d = e.d, a = g.precision, l = g.rounding, !u[0] || !d[0]) {
        if (d[0]) e.s = -e.s;
        else if (u[0]) e = new g(f);
        else return new g(l === 3 ? -0 : 0);
        return w ? y(e, a, l) : e;
    }
    if (t = X(e.e / E), c = X(f.e / E), u = u.slice(), o = c - t, o) {
        for(p = o < 0, p ? (r = u, o = -o, s = d.length) : (r = d, t = c, s = u.length), n = Math.max(Math.ceil(a / E), s) + 2, o > n && (o = n, r.length = 1), r.reverse(), n = o; n--;)r.push(0);
        r.reverse();
    } else {
        for(n = u.length, s = d.length, p = n < s, p && (s = n), n = 0; n < s; n++)if (u[n] != d[n]) {
            p = u[n] < d[n];
            break;
        }
        o = 0;
    }
    for(p && (r = u, u = d, d = r, e.s = -e.s), s = u.length, n = d.length - s; n > 0; --n)u[s++] = 0;
    for(n = d.length; n > o;){
        if (u[--n] < d[n]) {
            for(i = n; i && u[--i] === 0;)u[i] = fe - 1;
            --u[i], u[n] += fe;
        }
        u[n] -= d[n];
    }
    for(; u[--s] === 0;)u.pop();
    for(; u[0] === 0; u.shift())--t;
    return u[0] ? (e.d = u, e.e = mn(u, t), w ? y(e, a, l) : e) : new g(l === 3 ? -0 : 0);
};
m.modulo = m.mod = function(e) {
    var r, t = this, n = t.constructor;
    return e = new n(e), !t.d || !e.s || e.d && !e.d[0] ? new n(NaN) : !e.d || t.d && !t.d[0] ? y(new n(t), n.precision, n.rounding) : (w = !1, n.modulo == 9 ? (r = F(t, e.abs(), 0, 3, 1), r.s *= e.s) : r = F(t, e, 0, n.modulo, 1), r = r.times(e), w = !0, t.minus(r));
};
m.naturalExponential = m.exp = function() {
    return Bi(this);
};
m.naturalLogarithm = m.ln = function() {
    return Je(this);
};
m.negated = m.neg = function() {
    var e = new this.constructor(this);
    return e.s = -e.s, y(e);
};
m.plus = m.add = function(e) {
    var r, t, n, i, o, s, a, l, u, c, p = this, d = p.constructor;
    if (e = new d(e), !p.d || !e.d) return !p.s || !e.s ? e = new d(NaN) : p.d || (e = new d(e.d || p.s === e.s ? p : NaN)), e;
    if (p.s != e.s) return e.s = -e.s, p.minus(e);
    if (u = p.d, c = e.d, a = d.precision, l = d.rounding, !u[0] || !c[0]) return c[0] || (e = new d(p)), w ? y(e, a, l) : e;
    if (o = X(p.e / E), n = X(e.e / E), u = u.slice(), i = o - n, i) {
        for(i < 0 ? (t = u, i = -i, s = c.length) : (t = c, n = o, s = u.length), o = Math.ceil(a / E), s = o > s ? o + 1 : s + 1, i > s && (i = s, t.length = 1), t.reverse(); i--;)t.push(0);
        t.reverse();
    }
    for(s = u.length, i = c.length, s - i < 0 && (i = s, t = c, c = u, u = t), r = 0; i;)r = (u[--i] = u[i] + c[i] + r) / fe | 0, u[i] %= fe;
    for(r && (u.unshift(r), ++n), s = u.length; u[--s] == 0;)u.pop();
    return e.d = u, e.e = mn(u, n), w ? y(e, a, l) : e;
};
m.precision = m.sd = function(e) {
    var r, t = this;
    if (e !== void 0 && e !== !!e && e !== 1 && e !== 0) throw Error(He + e);
    return t.d ? (r = Qs(t.d), e && t.e + 1 > r && (r = t.e + 1)) : r = NaN, r;
};
m.round = function() {
    var e = this, r = e.constructor;
    return y(new r(e), e.e + 1, r.rounding);
};
m.sine = m.sin = function() {
    var e, r, t = this, n = t.constructor;
    return t.isFinite() ? t.isZero() ? new n(t) : (e = n.precision, r = n.rounding, n.precision = e + Math.max(t.e, t.sd()) + E, n.rounding = 1, t = Tp(n, Hs(n, t)), n.precision = e, n.rounding = r, y(Fe > 2 ? t.neg() : t, e, r, !0)) : new n(NaN);
};
m.squareRoot = m.sqrt = function() {
    var e, r, t, n, i, o, s = this, a = s.d, l = s.e, u = s.s, c = s.constructor;
    if (u !== 1 || !a || !a[0]) return new c(!u || u < 0 && (!a || a[0]) ? NaN : a ? s : 1 / 0);
    for(w = !1, u = Math.sqrt(+s), u == 0 || u == 1 / 0 ? (r = J(a), (r.length + l) % 2 == 0 && (r += "0"), u = Math.sqrt(r), l = X((l + 1) / 2) - (l < 0 || l % 2), u == 1 / 0 ? r = "5e" + l : (r = u.toExponential(), r = r.slice(0, r.indexOf("e") + 1) + l), n = new c(r)) : n = new c(u.toString()), t = (l = c.precision) + 3;;)if (o = n, n = o.plus(F(s, o, t + 2, 1)).times(.5), J(o.d).slice(0, t) === (r = J(n.d)).slice(0, t)) if (r = r.slice(t - 3, t + 1), r == "9999" || !i && r == "4999") {
        if (!i && (y(o, l + 1, 0), o.times(o).eq(s))) {
            n = o;
            break;
        }
        t += 4, i = 1;
    } else {
        (!+r || !+r.slice(1) && r.charAt(0) == "5") && (y(n, l + 1, 1), e = !n.times(n).eq(s));
        break;
    }
    return w = !0, y(n, l, c.rounding, e);
};
m.tangent = m.tan = function() {
    var e, r, t = this, n = t.constructor;
    return t.isFinite() ? t.isZero() ? new n(t) : (e = n.precision, r = n.rounding, n.precision = e + 10, n.rounding = 1, t = t.sin(), t.s = 1, t = F(t, new n(1).minus(t.times(t)).sqrt(), e + 10, 0), n.precision = e, n.rounding = r, y(Fe == 2 || Fe == 4 ? t.neg() : t, e, r, !0)) : new n(NaN);
};
m.times = m.mul = function(e) {
    var r, t, n, i, o, s, a, l, u, c = this, p = c.constructor, d = c.d, f = (e = new p(e)).d;
    if (e.s *= c.s, !d || !d[0] || !f || !f[0]) return new p(!e.s || d && !d[0] && !f || f && !f[0] && !d ? NaN : !d || !f ? e.s / 0 : e.s * 0);
    for(t = X(c.e / E) + X(e.e / E), l = d.length, u = f.length, l < u && (o = d, d = f, f = o, s = l, l = u, u = s), o = [], s = l + u, n = s; n--;)o.push(0);
    for(n = u; --n >= 0;){
        for(r = 0, i = l + n; i > n;)a = o[i] + f[n] * d[i - n - 1] + r, o[i--] = a % fe | 0, r = a / fe | 0;
        o[i] = (o[i] + r) % fe | 0;
    }
    for(; !o[--s];)o.pop();
    return r ? ++t : o.shift(), e.d = o, e.e = mn(o, t), w ? y(e, p.precision, p.rounding) : e;
};
m.toBinary = function(e, r) {
    return Ui(this, 2, e, r);
};
m.toDecimalPlaces = m.toDP = function(e, r) {
    var t = this, n = t.constructor;
    return t = new n(t), e === void 0 ? t : (ie(e, 0, Ke), r === void 0 ? r = n.rounding : ie(r, 0, 8), y(t, e + t.e + 1, r));
};
m.toExponential = function(e, r) {
    var t, n = this, i = n.constructor;
    return e === void 0 ? t = xe(n, !0) : (ie(e, 0, Ke), r === void 0 ? r = i.rounding : ie(r, 0, 8), n = y(new i(n), e + 1, r), t = xe(n, !0, e + 1)), n.isNeg() && !n.isZero() ? "-" + t : t;
};
m.toFixed = function(e, r) {
    var t, n, i = this, o = i.constructor;
    return e === void 0 ? t = xe(i) : (ie(e, 0, Ke), r === void 0 ? r = o.rounding : ie(r, 0, 8), n = y(new o(i), e + i.e + 1, r), t = xe(n, !1, e + n.e + 1)), i.isNeg() && !i.isZero() ? "-" + t : t;
};
m.toFraction = function(e) {
    var r, t, n, i, o, s, a, l, u, c, p, d, f = this, g = f.d, h = f.constructor;
    if (!g) return new h(f);
    if (u = t = new h(1), n = l = new h(0), r = new h(n), o = r.e = Qs(g) - f.e - 1, s = o % E, r.d[0] = U(10, s < 0 ? E + s : s), e == null) e = o > 0 ? r : u;
    else {
        if (a = new h(e), !a.isInt() || a.lt(u)) throw Error(He + a);
        e = a.gt(r) ? o > 0 ? r : u : a;
    }
    for(w = !1, a = new h(J(g)), c = h.precision, h.precision = o = g.length * E * 2; p = F(a, r, 0, 1, 1), i = t.plus(p.times(n)), i.cmp(e) != 1;)t = n, n = i, i = u, u = l.plus(p.times(i)), l = i, i = r, r = a.minus(p.times(i)), a = i;
    return i = F(e.minus(t), n, 0, 1, 1), l = l.plus(i.times(u)), t = t.plus(i.times(n)), l.s = u.s = f.s, d = F(u, n, o, 1).minus(f).abs().cmp(F(l, t, o, 1).minus(f).abs()) < 1 ? [
        u,
        n
    ] : [
        l,
        t
    ], h.precision = c, w = !0, d;
};
m.toHexadecimal = m.toHex = function(e, r) {
    return Ui(this, 16, e, r);
};
m.toNearest = function(e, r) {
    var t = this, n = t.constructor;
    if (t = new n(t), e == null) {
        if (!t.d) return t;
        e = new n(1), r = n.rounding;
    } else {
        if (e = new n(e), r === void 0 ? r = n.rounding : ie(r, 0, 8), !t.d) return e.s ? t : e;
        if (!e.d) return e.s && (e.s = t.s), e;
    }
    return e.d[0] ? (w = !1, t = F(t, e, 0, r, 1).times(e), w = !0, y(t)) : (e.s = t.s, t = e), t;
};
m.toNumber = function() {
    return +this;
};
m.toOctal = function(e, r) {
    return Ui(this, 8, e, r);
};
m.toPower = m.pow = function(e) {
    var r, t, n, i, o, s, a = this, l = a.constructor, u = +(e = new l(e));
    if (!a.d || !e.d || !a.d[0] || !e.d[0]) return new l(U(+a, u));
    if (a = new l(a), a.eq(1)) return a;
    if (n = l.precision, o = l.rounding, e.eq(1)) return y(a, n, o);
    if (r = X(e.e / E), r >= e.d.length - 1 && (t = u < 0 ? -u : u) <= wp) return i = Gs(l, a, t, n), e.s < 0 ? new l(1).div(i) : y(i, n, o);
    if (s = a.s, s < 0) {
        if (r < e.d.length - 1) return new l(NaN);
        if ((e.d[r] & 1) == 0 && (s = 1), a.e == 0 && a.d[0] == 1 && a.d.length == 1) return a.s = s, a;
    }
    return t = U(+a, u), r = t == 0 || !isFinite(t) ? X(u * (Math.log("0." + J(a.d)) / Math.LN10 + a.e + 1)) : new l(t + "").e, r > l.maxE + 1 || r < l.minE - 1 ? new l(r > 0 ? s / 0 : 0) : (w = !1, l.rounding = a.s = 1, t = Math.min(12, (r + "").length), i = Bi(e.times(Je(a, n + t)), n), i.d && (i = y(i, n + 5, 1), st(i.d, n, o) && (r = n + 10, i = y(Bi(e.times(Je(a, r + t)), r), r + 5, 1), +J(i.d).slice(n + 1, n + 15) + 1 == 1e14 && (i = y(i, n + 1, 0)))), i.s = s, w = !0, l.rounding = o, y(i, n, o));
};
m.toPrecision = function(e, r) {
    var t, n = this, i = n.constructor;
    return e === void 0 ? t = xe(n, n.e <= i.toExpNeg || n.e >= i.toExpPos) : (ie(e, 1, Ke), r === void 0 ? r = i.rounding : ie(r, 0, 8), n = y(new i(n), e, r), t = xe(n, e <= n.e || n.e <= i.toExpNeg, e)), n.isNeg() && !n.isZero() ? "-" + t : t;
};
m.toSignificantDigits = m.toSD = function(e, r) {
    var t = this, n = t.constructor;
    return e === void 0 ? (e = n.precision, r = n.rounding) : (ie(e, 1, Ke), r === void 0 ? r = n.rounding : ie(r, 0, 8)), y(new n(t), e, r);
};
m.toString = function() {
    var e = this, r = e.constructor, t = xe(e, e.e <= r.toExpNeg || e.e >= r.toExpPos);
    return e.isNeg() && !e.isZero() ? "-" + t : t;
};
m.truncated = m.trunc = function() {
    return y(new this.constructor(this), this.e + 1, 1);
};
m.valueOf = m.toJSON = function() {
    var e = this, r = e.constructor, t = xe(e, e.e <= r.toExpNeg || e.e >= r.toExpPos);
    return e.isNeg() ? "-" + t : t;
};
function J(e) {
    var r, t, n, i = e.length - 1, o = "", s = e[0];
    if (i > 0) {
        for(o += s, r = 1; r < i; r++)n = e[r] + "", t = E - n.length, t && (o += We(t)), o += n;
        s = e[r], n = s + "", t = E - n.length, t && (o += We(t));
    } else if (s === 0) return "0";
    for(; s % 10 === 0;)s /= 10;
    return o + s;
}
function ie(e, r, t) {
    if (e !== ~~e || e < r || e > t) throw Error(He + e);
}
function st(e, r, t, n) {
    var i, o, s, a;
    for(o = e[0]; o >= 10; o /= 10)--r;
    return --r < 0 ? (r += E, i = 0) : (i = Math.ceil((r + 1) / E), r %= E), o = U(10, E - r), a = e[i] % o | 0, n == null ? r < 3 ? (r == 0 ? a = a / 100 | 0 : r == 1 && (a = a / 10 | 0), s = t < 4 && a == 99999 || t > 3 && a == 49999 || a == 5e4 || a == 0) : s = (t < 4 && a + 1 == o || t > 3 && a + 1 == o / 2) && (e[i + 1] / o / 100 | 0) == U(10, r - 2) - 1 || (a == o / 2 || a == 0) && (e[i + 1] / o / 100 | 0) == 0 : r < 4 ? (r == 0 ? a = a / 1e3 | 0 : r == 1 ? a = a / 100 | 0 : r == 2 && (a = a / 10 | 0), s = (n || t < 4) && a == 9999 || !n && t > 3 && a == 4999) : s = ((n || t < 4) && a + 1 == o || !n && t > 3 && a + 1 == o / 2) && (e[i + 1] / o / 1e3 | 0) == U(10, r - 3) - 1, s;
}
function an(e, r, t) {
    for(var n, i = [
        0
    ], o, s = 0, a = e.length; s < a;){
        for(o = i.length; o--;)i[o] *= r;
        for(i[0] += qi.indexOf(e.charAt(s++)), n = 0; n < i.length; n++)i[n] > t - 1 && (i[n + 1] === void 0 && (i[n + 1] = 0), i[n + 1] += i[n] / t | 0, i[n] %= t);
    }
    return i.reverse();
}
function vp(e, r) {
    var t, n, i;
    if (r.isZero()) return r;
    n = r.d.length, n < 32 ? (t = Math.ceil(n / 3), i = (1 / fn(4, t)).toString()) : (t = 16, i = "2.3283064365386962890625e-10"), e.precision += t, r = Pr(e, 1, r.times(i), new e(1));
    for(var o = t; o--;){
        var s = r.times(r);
        r = s.times(s).minus(s).times(8).plus(1);
    }
    return e.precision -= t, r;
}
var F = function() {
    function e(n, i, o) {
        var s, a = 0, l = n.length;
        for(n = n.slice(); l--;)s = n[l] * i + a, n[l] = s % o | 0, a = s / o | 0;
        return a && n.unshift(a), n;
    }
    function r(n, i, o, s) {
        var a, l;
        if (o != s) l = o > s ? 1 : -1;
        else for(a = l = 0; a < o; a++)if (n[a] != i[a]) {
            l = n[a] > i[a] ? 1 : -1;
            break;
        }
        return l;
    }
    function t(n, i, o, s) {
        for(var a = 0; o--;)n[o] -= a, a = n[o] < i[o] ? 1 : 0, n[o] = a * s + n[o] - i[o];
        for(; !n[0] && n.length > 1;)n.shift();
    }
    return function(n, i, o, s, a, l) {
        var u, c, p, d, f, g, h, I, P, S, b, O, me, ae, Jr, V, te, Ae, H, fr, $t = n.constructor, Xn = n.s == i.s ? 1 : -1, K = n.d, _ = i.d;
        if (!K || !K[0] || !_ || !_[0]) return new $t(!n.s || !i.s || (K ? _ && K[0] == _[0] : !_) ? NaN : K && K[0] == 0 || !_ ? Xn * 0 : Xn / 0);
        for(l ? (f = 1, c = n.e - i.e) : (l = fe, f = E, c = X(n.e / f) - X(i.e / f)), H = _.length, te = K.length, P = new $t(Xn), S = P.d = [], p = 0; _[p] == (K[p] || 0); p++);
        if (_[p] > (K[p] || 0) && c--, o == null ? (ae = o = $t.precision, s = $t.rounding) : a ? ae = o + (n.e - i.e) + 1 : ae = o, ae < 0) S.push(1), g = !0;
        else {
            if (ae = ae / f + 2 | 0, p = 0, H == 1) {
                for(d = 0, _ = _[0], ae++; (p < te || d) && ae--; p++)Jr = d * l + (K[p] || 0), S[p] = Jr / _ | 0, d = Jr % _ | 0;
                g = d || p < te;
            } else {
                for(d = l / (_[0] + 1) | 0, d > 1 && (_ = e(_, d, l), K = e(K, d, l), H = _.length, te = K.length), V = H, b = K.slice(0, H), O = b.length; O < H;)b[O++] = 0;
                fr = _.slice(), fr.unshift(0), Ae = _[0], _[1] >= l / 2 && ++Ae;
                do d = 0, u = r(_, b, H, O), u < 0 ? (me = b[0], H != O && (me = me * l + (b[1] || 0)), d = me / Ae | 0, d > 1 ? (d >= l && (d = l - 1), h = e(_, d, l), I = h.length, O = b.length, u = r(h, b, I, O), u == 1 && (d--, t(h, H < I ? fr : _, I, l))) : (d == 0 && (u = d = 1), h = _.slice()), I = h.length, I < O && h.unshift(0), t(b, h, O, l), u == -1 && (O = b.length, u = r(_, b, H, O), u < 1 && (d++, t(b, H < O ? fr : _, O, l))), O = b.length) : u === 0 && (d++, b = [
                    0
                ]), S[p++] = d, u && b[0] ? b[O++] = K[V] || 0 : (b = [
                    K[V]
                ], O = 1);
                while ((V++ < te || b[0] !== void 0) && ae--)
                g = b[0] !== void 0;
            }
            S[0] || S.shift();
        }
        if (f == 1) P.e = c, qs = g;
        else {
            for(p = 1, d = S[0]; d >= 10; d /= 10)p++;
            P.e = p + c * f - 1, y(P, a ? o + P.e + 1 : o, s, g);
        }
        return P;
    };
}();
function y(e, r, t, n) {
    var i, o, s, a, l, u, c, p, d, f = e.constructor;
    e: if (r != null) {
        if (p = e.d, !p) return e;
        for(i = 1, a = p[0]; a >= 10; a /= 10)i++;
        if (o = r - i, o < 0) o += E, s = r, c = p[d = 0], l = c / U(10, i - s - 1) % 10 | 0;
        else if (d = Math.ceil((o + 1) / E), a = p.length, d >= a) if (n) {
            for(; a++ <= d;)p.push(0);
            c = l = 0, i = 1, o %= E, s = o - E + 1;
        } else break e;
        else {
            for(c = a = p[d], i = 1; a >= 10; a /= 10)i++;
            o %= E, s = o - E + i, l = s < 0 ? 0 : c / U(10, i - s - 1) % 10 | 0;
        }
        if (n = n || r < 0 || p[d + 1] !== void 0 || (s < 0 ? c : c % U(10, i - s - 1)), u = t < 4 ? (l || n) && (t == 0 || t == (e.s < 0 ? 3 : 2)) : l > 5 || l == 5 && (t == 4 || n || t == 6 && (o > 0 ? s > 0 ? c / U(10, i - s) : 0 : p[d - 1]) % 10 & 1 || t == (e.s < 0 ? 8 : 7)), r < 1 || !p[0]) return p.length = 0, u ? (r -= e.e + 1, p[0] = U(10, (E - r % E) % E), e.e = -r || 0) : p[0] = e.e = 0, e;
        if (o == 0 ? (p.length = d, a = 1, d--) : (p.length = d + 1, a = U(10, E - o), p[d] = s > 0 ? (c / U(10, i - s) % U(10, s) | 0) * a : 0), u) for(;;)if (d == 0) {
            for(o = 1, s = p[0]; s >= 10; s /= 10)o++;
            for(s = p[0] += a, a = 1; s >= 10; s /= 10)a++;
            o != a && (e.e++, p[0] == fe && (p[0] = 1));
            break;
        } else {
            if (p[d] += a, p[d] != fe) break;
            p[d--] = 0, a = 1;
        }
        for(o = p.length; p[--o] === 0;)p.pop();
    }
    return w && (e.e > f.maxE ? (e.d = null, e.e = NaN) : e.e < f.minE && (e.e = 0, e.d = [
        0
    ])), e;
}
function xe(e, r, t) {
    if (!e.isFinite()) return Js(e);
    var n, i = e.e, o = J(e.d), s = o.length;
    return r ? (t && (n = t - s) > 0 ? o = o.charAt(0) + "." + o.slice(1) + We(n) : s > 1 && (o = o.charAt(0) + "." + o.slice(1)), o = o + (e.e < 0 ? "e" : "e+") + e.e) : i < 0 ? (o = "0." + We(-i - 1) + o, t && (n = t - s) > 0 && (o += We(n))) : i >= s ? (o += We(i + 1 - s), t && (n = t - i - 1) > 0 && (o = o + "." + We(n))) : ((n = i + 1) < s && (o = o.slice(0, n) + "." + o.slice(n)), t && (n = t - s) > 0 && (i + 1 === s && (o += "."), o += We(n))), o;
}
function mn(e, r) {
    var t = e[0];
    for(r *= E; t >= 10; t /= 10)r++;
    return r;
}
function pn(e, r, t) {
    if (r > xp) throw w = !0, t && (e.precision = t), Error(js);
    return y(new e(un), r, 1, !0);
}
function we(e, r, t) {
    if (r > Vi) throw Error(js);
    return y(new e(cn), r, t, !0);
}
function Qs(e) {
    var r = e.length - 1, t = r * E + 1;
    if (r = e[r], r) {
        for(; r % 10 == 0; r /= 10)t--;
        for(r = e[0]; r >= 10; r /= 10)t++;
    }
    return t;
}
function We(e) {
    for(var r = ""; e--;)r += "0";
    return r;
}
function Gs(e, r, t, n) {
    var i, o = new e(1), s = Math.ceil(n / E + 4);
    for(w = !1;;){
        if (t % 2 && (o = o.times(r), Ms(o.d, s) && (i = !0)), t = X(t / 2), t === 0) {
            t = o.d.length - 1, i && o.d[t] === 0 && ++o.d[t];
            break;
        }
        r = r.times(r), Ms(r.d, s);
    }
    return w = !0, o;
}
function Ls(e) {
    return e.d[e.d.length - 1] & 1;
}
function Ws(e, r, t) {
    for(var n, i, o = new e(r[0]), s = 0; ++s < r.length;){
        if (i = new e(r[s]), !i.s) {
            o = i;
            break;
        }
        n = o.cmp(i), (n === t || n === 0 && o.s === t) && (o = i);
    }
    return o;
}
function Bi(e, r) {
    var t, n, i, o, s, a, l, u = 0, c = 0, p = 0, d = e.constructor, f = d.rounding, g = d.precision;
    if (!e.d || !e.d[0] || e.e > 17) return new d(e.d ? e.d[0] ? e.s < 0 ? 0 : 1 / 0 : 1 : e.s ? e.s < 0 ? 0 : e : NaN);
    for(r == null ? (w = !1, l = g) : l = r, a = new d(.03125); e.e > -2;)e = e.times(a), p += 5;
    for(n = Math.log(U(2, p)) / Math.LN10 * 2 + 5 | 0, l += n, t = o = s = new d(1), d.precision = l;;){
        if (o = y(o.times(e), l, 1), t = t.times(++c), a = s.plus(F(o, t, l, 1)), J(a.d).slice(0, l) === J(s.d).slice(0, l)) {
            for(i = p; i--;)s = y(s.times(s), l, 1);
            if (r == null) if (u < 3 && st(s.d, l - n, f, u)) d.precision = l += 10, t = o = a = new d(1), c = 0, u++;
            else return y(s, d.precision = g, f, w = !0);
            else return d.precision = g, s;
        }
        s = a;
    }
}
function Je(e, r) {
    var t, n, i, o, s, a, l, u, c, p, d, f = 1, g = 10, h = e, I = h.d, P = h.constructor, S = P.rounding, b = P.precision;
    if (h.s < 0 || !I || !I[0] || !h.e && I[0] == 1 && I.length == 1) return new P(I && !I[0] ? -1 / 0 : h.s != 1 ? NaN : I ? 0 : h);
    if (r == null ? (w = !1, c = b) : c = r, P.precision = c += g, t = J(I), n = t.charAt(0), Math.abs(o = h.e) < 15e14) {
        for(; n < 7 && n != 1 || n == 1 && t.charAt(1) > 3;)h = h.times(e), t = J(h.d), n = t.charAt(0), f++;
        o = h.e, n > 1 ? (h = new P("0." + t), o++) : h = new P(n + "." + t.slice(1));
    } else return u = pn(P, c + 2, b).times(o + ""), h = Je(new P(n + "." + t.slice(1)), c - g).plus(u), P.precision = b, r == null ? y(h, b, S, w = !0) : h;
    for(p = h, l = s = h = F(h.minus(1), h.plus(1), c, 1), d = y(h.times(h), c, 1), i = 3;;){
        if (s = y(s.times(d), c, 1), u = l.plus(F(s, new P(i), c, 1)), J(u.d).slice(0, c) === J(l.d).slice(0, c)) if (l = l.times(2), o !== 0 && (l = l.plus(pn(P, c + 2, b).times(o + ""))), l = F(l, new P(f), c, 1), r == null) if (st(l.d, c - g, S, a)) P.precision = c += g, u = s = h = F(p.minus(1), p.plus(1), c, 1), d = y(h.times(h), c, 1), i = a = 1;
        else return y(l, P.precision = b, S, w = !0);
        else return P.precision = b, l;
        l = u, i += 2;
    }
}
function Js(e) {
    return String(e.s * e.s / 0);
}
function ln(e, r) {
    var t, n, i;
    for((t = r.indexOf(".")) > -1 && (r = r.replace(".", "")), (n = r.search(/e/i)) > 0 ? (t < 0 && (t = n), t += +r.slice(n + 1), r = r.substring(0, n)) : t < 0 && (t = r.length), n = 0; r.charCodeAt(n) === 48; n++);
    for(i = r.length; r.charCodeAt(i - 1) === 48; --i);
    if (r = r.slice(n, i), r) {
        if (i -= n, e.e = t = t - n - 1, e.d = [], n = (t + 1) % E, t < 0 && (n += E), n < i) {
            for(n && e.d.push(+r.slice(0, n)), i -= E; n < i;)e.d.push(+r.slice(n, n += E));
            r = r.slice(n), n = E - r.length;
        } else n -= i;
        for(; n--;)r += "0";
        e.d.push(+r), w && (e.e > e.constructor.maxE ? (e.d = null, e.e = NaN) : e.e < e.constructor.minE && (e.e = 0, e.d = [
            0
        ]));
    } else e.e = 0, e.d = [
        0
    ];
    return e;
}
function Pp(e, r) {
    var t, n, i, o, s, a, l, u, c;
    if (r.indexOf("_") > -1) {
        if (r = r.replace(/(\d)_(?=\d)/g, "$1"), Us.test(r)) return ln(e, r);
    } else if (r === "Infinity" || r === "NaN") return +r || (e.s = NaN), e.e = NaN, e.d = null, e;
    if (bp.test(r)) t = 16, r = r.toLowerCase();
    else if (yp.test(r)) t = 2;
    else if (Ep.test(r)) t = 8;
    else throw Error(He + r);
    for(o = r.search(/p/i), o > 0 ? (l = +r.slice(o + 1), r = r.substring(2, o)) : r = r.slice(2), o = r.indexOf("."), s = o >= 0, n = e.constructor, s && (r = r.replace(".", ""), a = r.length, o = a - o, i = Gs(n, new n(t), o, o * 2)), u = an(r, t, fe), c = u.length - 1, o = c; u[o] === 0; --o)u.pop();
    return o < 0 ? new n(e.s * 0) : (e.e = mn(u, c), e.d = u, w = !1, s && (e = F(e, i, a * 4)), l && (e = e.times(Math.abs(l) < 54 ? U(2, l) : sr.pow(2, l))), w = !0, e);
}
function Tp(e, r) {
    var t, n = r.d.length;
    if (n < 3) return r.isZero() ? r : Pr(e, 2, r, r);
    t = 1.4 * Math.sqrt(n), t = t > 16 ? 16 : t | 0, r = r.times(1 / fn(5, t)), r = Pr(e, 2, r, r);
    for(var i, o = new e(5), s = new e(16), a = new e(20); t--;)i = r.times(r), r = r.times(o.plus(i.times(s.times(i).minus(a))));
    return r;
}
function Pr(e, r, t, n, i) {
    var o, s, a, l, u = 1, c = e.precision, p = Math.ceil(c / E);
    for(w = !1, l = t.times(t), a = new e(n);;){
        if (s = F(a.times(l), new e(r++ * r++), c, 1), a = i ? n.plus(s) : n.minus(s), n = F(s.times(l), new e(r++ * r++), c, 1), s = a.plus(n), s.d[p] !== void 0) {
            for(o = p; s.d[o] === a.d[o] && o--;);
            if (o == -1) break;
        }
        o = a, a = n, n = s, s = o, u++;
    }
    return w = !0, s.d.length = p + 1, s;
}
function fn(e, r) {
    for(var t = e; --r;)t *= e;
    return t;
}
function Hs(e, r) {
    var t, n = r.s < 0, i = we(e, e.precision, 1), o = i.times(.5);
    if (r = r.abs(), r.lte(o)) return Fe = n ? 4 : 1, r;
    if (t = r.divToInt(i), t.isZero()) Fe = n ? 3 : 2;
    else {
        if (r = r.minus(t.times(i)), r.lte(o)) return Fe = Ls(t) ? n ? 2 : 3 : n ? 4 : 1, r;
        Fe = Ls(t) ? n ? 1 : 4 : n ? 3 : 2;
    }
    return r.minus(i).abs();
}
function Ui(e, r, t, n) {
    var i, o, s, a, l, u, c, p, d, f = e.constructor, g = t !== void 0;
    if (g ? (ie(t, 1, Ke), n === void 0 ? n = f.rounding : ie(n, 0, 8)) : (t = f.precision, n = f.rounding), !e.isFinite()) c = Js(e);
    else {
        for(c = xe(e), s = c.indexOf("."), g ? (i = 2, r == 16 ? t = t * 4 - 3 : r == 8 && (t = t * 3 - 2)) : i = r, s >= 0 && (c = c.replace(".", ""), d = new f(1), d.e = c.length - s, d.d = an(xe(d), 10, i), d.e = d.d.length), p = an(c, 10, i), o = l = p.length; p[--l] == 0;)p.pop();
        if (!p[0]) c = g ? "0p+0" : "0";
        else {
            if (s < 0 ? o-- : (e = new f(e), e.d = p, e.e = o, e = F(e, d, t, n, 0, i), p = e.d, o = e.e, u = qs), s = p[t], a = i / 2, u = u || p[t + 1] !== void 0, u = n < 4 ? (s !== void 0 || u) && (n === 0 || n === (e.s < 0 ? 3 : 2)) : s > a || s === a && (n === 4 || u || n === 6 && p[t - 1] & 1 || n === (e.s < 0 ? 8 : 7)), p.length = t, u) for(; ++p[--t] > i - 1;)p[t] = 0, t || (++o, p.unshift(1));
            for(l = p.length; !p[l - 1]; --l);
            for(s = 0, c = ""; s < l; s++)c += qi.charAt(p[s]);
            if (g) {
                if (l > 1) if (r == 16 || r == 8) {
                    for(s = r == 16 ? 4 : 3, --l; l % s; l++)c += "0";
                    for(p = an(c, i, r), l = p.length; !p[l - 1]; --l);
                    for(s = 1, c = "1."; s < l; s++)c += qi.charAt(p[s]);
                } else c = c.charAt(0) + "." + c.slice(1);
                c = c + (o < 0 ? "p" : "p+") + o;
            } else if (o < 0) {
                for(; ++o;)c = "0" + c;
                c = "0." + c;
            } else if (++o > l) for(o -= l; o--;)c += "0";
            else o < l && (c = c.slice(0, o) + "." + c.slice(o));
        }
        c = (r == 16 ? "0x" : r == 2 ? "0b" : r == 8 ? "0o" : "") + c;
    }
    return e.s < 0 ? "-" + c : c;
}
function Ms(e, r) {
    if (e.length > r) return e.length = r, !0;
}
function Sp(e) {
    return new this(e).abs();
}
function Rp(e) {
    return new this(e).acos();
}
function Cp(e) {
    return new this(e).acosh();
}
function Ap(e, r) {
    return new this(e).plus(r);
}
function Ip(e) {
    return new this(e).asin();
}
function kp(e) {
    return new this(e).asinh();
}
function Op(e) {
    return new this(e).atan();
}
function Dp(e) {
    return new this(e).atanh();
}
function _p(e, r) {
    e = new this(e), r = new this(r);
    var t, n = this.precision, i = this.rounding, o = n + 4;
    return !e.s || !r.s ? t = new this(NaN) : !e.d && !r.d ? (t = we(this, o, 1).times(r.s > 0 ? .25 : .75), t.s = e.s) : !r.d || e.isZero() ? (t = r.s < 0 ? we(this, n, i) : new this(0), t.s = e.s) : !e.d || r.isZero() ? (t = we(this, o, 1).times(.5), t.s = e.s) : r.s < 0 ? (this.precision = o, this.rounding = 1, t = this.atan(F(e, r, o, 1)), r = we(this, o, 1), this.precision = n, this.rounding = i, t = e.s < 0 ? t.minus(r) : t.plus(r)) : t = this.atan(F(e, r, o, 1)), t;
}
function Np(e) {
    return new this(e).cbrt();
}
function Fp(e) {
    return y(e = new this(e), e.e + 1, 2);
}
function Lp(e, r, t) {
    return new this(e).clamp(r, t);
}
function Mp(e) {
    if (!e || typeof e != "object") throw Error(dn + "Object expected");
    var r, t, n, i = e.defaults === !0, o = [
        "precision",
        1,
        Ke,
        "rounding",
        0,
        8,
        "toExpNeg",
        -vr,
        0,
        "toExpPos",
        0,
        vr,
        "maxE",
        0,
        vr,
        "minE",
        -vr,
        0,
        "modulo",
        0,
        9
    ];
    for(r = 0; r < o.length; r += 3)if (t = o[r], i && (this[t] = ji[t]), (n = e[t]) !== void 0) if (X(n) === n && n >= o[r + 1] && n <= o[r + 2]) this[t] = n;
    else throw Error(He + t + ": " + n);
    if (t = "crypto", i && (this[t] = ji[t]), (n = e[t]) !== void 0) if (n === !0 || n === !1 || n === 0 || n === 1) if (n) if (typeof crypto < "u" && crypto && (crypto.getRandomValues || crypto.randomBytes)) this[t] = !0;
    else throw Error(Vs);
    else this[t] = !1;
    else throw Error(He + t + ": " + n);
    return this;
}
function $p(e) {
    return new this(e).cos();
}
function qp(e) {
    return new this(e).cosh();
}
function Ks(e) {
    var r, t, n;
    function i(o) {
        var s, a, l, u = this;
        if (!(u instanceof i)) return new i(o);
        if (u.constructor = i, $s(o)) {
            u.s = o.s, w ? !o.d || o.e > i.maxE ? (u.e = NaN, u.d = null) : o.e < i.minE ? (u.e = 0, u.d = [
                0
            ]) : (u.e = o.e, u.d = o.d.slice()) : (u.e = o.e, u.d = o.d ? o.d.slice() : o.d);
            return;
        }
        if (l = typeof o, l === "number") {
            if (o === 0) {
                u.s = 1 / o < 0 ? -1 : 1, u.e = 0, u.d = [
                    0
                ];
                return;
            }
            if (o < 0 ? (o = -o, u.s = -1) : u.s = 1, o === ~~o && o < 1e7) {
                for(s = 0, a = o; a >= 10; a /= 10)s++;
                w ? s > i.maxE ? (u.e = NaN, u.d = null) : s < i.minE ? (u.e = 0, u.d = [
                    0
                ]) : (u.e = s, u.d = [
                    o
                ]) : (u.e = s, u.d = [
                    o
                ]);
                return;
            }
            if (o * 0 !== 0) {
                o || (u.s = NaN), u.e = NaN, u.d = null;
                return;
            }
            return ln(u, o.toString());
        }
        if (l === "string") return (a = o.charCodeAt(0)) === 45 ? (o = o.slice(1), u.s = -1) : (a === 43 && (o = o.slice(1)), u.s = 1), Us.test(o) ? ln(u, o) : Pp(u, o);
        if (l === "bigint") return o < 0 ? (o = -o, u.s = -1) : u.s = 1, ln(u, o.toString());
        throw Error(He + o);
    }
    if (i.prototype = m, i.ROUND_UP = 0, i.ROUND_DOWN = 1, i.ROUND_CEIL = 2, i.ROUND_FLOOR = 3, i.ROUND_HALF_UP = 4, i.ROUND_HALF_DOWN = 5, i.ROUND_HALF_EVEN = 6, i.ROUND_HALF_CEIL = 7, i.ROUND_HALF_FLOOR = 8, i.EUCLID = 9, i.config = i.set = Mp, i.clone = Ks, i.isDecimal = $s, i.abs = Sp, i.acos = Rp, i.acosh = Cp, i.add = Ap, i.asin = Ip, i.asinh = kp, i.atan = Op, i.atanh = Dp, i.atan2 = _p, i.cbrt = Np, i.ceil = Fp, i.clamp = Lp, i.cos = $p, i.cosh = qp, i.div = jp, i.exp = Vp, i.floor = Bp, i.hypot = Up, i.ln = Qp, i.log = Gp, i.log10 = Jp, i.log2 = Wp, i.max = Hp, i.min = Kp, i.mod = Yp, i.mul = zp, i.pow = Zp, i.random = Xp, i.round = ed, i.sign = rd, i.sin = td, i.sinh = nd, i.sqrt = id, i.sub = od, i.sum = sd, i.tan = ad, i.tanh = ld, i.trunc = ud, e === void 0 && (e = {}), e && e.defaults !== !0) for(n = [
        "precision",
        "rounding",
        "toExpNeg",
        "toExpPos",
        "maxE",
        "minE",
        "modulo",
        "crypto"
    ], r = 0; r < n.length;)e.hasOwnProperty(t = n[r++]) || (e[t] = this[t]);
    return i.config(e), i;
}
function jp(e, r) {
    return new this(e).div(r);
}
function Vp(e) {
    return new this(e).exp();
}
function Bp(e) {
    return y(e = new this(e), e.e + 1, 3);
}
function Up() {
    var e, r, t = new this(0);
    for(w = !1, e = 0; e < arguments.length;)if (r = new this(arguments[e++]), r.d) t.d && (t = t.plus(r.times(r)));
    else {
        if (r.s) return w = !0, new this(1 / 0);
        t = r;
    }
    return w = !0, t.sqrt();
}
function $s(e) {
    return e instanceof sr || e && e.toStringTag === Bs || !1;
}
function Qp(e) {
    return new this(e).ln();
}
function Gp(e, r) {
    return new this(e).log(r);
}
function Wp(e) {
    return new this(e).log(2);
}
function Jp(e) {
    return new this(e).log(10);
}
function Hp() {
    return Ws(this, arguments, -1);
}
function Kp() {
    return Ws(this, arguments, 1);
}
function Yp(e, r) {
    return new this(e).mod(r);
}
function zp(e, r) {
    return new this(e).mul(r);
}
function Zp(e, r) {
    return new this(e).pow(r);
}
function Xp(e) {
    var r, t, n, i, o = 0, s = new this(1), a = [];
    if (e === void 0 ? e = this.precision : ie(e, 1, Ke), n = Math.ceil(e / E), this.crypto) if (crypto.getRandomValues) for(r = crypto.getRandomValues(new Uint32Array(n)); o < n;)i = r[o], i >= 429e7 ? r[o] = crypto.getRandomValues(new Uint32Array(1))[0] : a[o++] = i % 1e7;
    else if (crypto.randomBytes) {
        for(r = crypto.randomBytes(n *= 4); o < n;)i = r[o] + (r[o + 1] << 8) + (r[o + 2] << 16) + ((r[o + 3] & 127) << 24), i >= 214e7 ? crypto.randomBytes(4).copy(r, o) : (a.push(i % 1e7), o += 4);
        o = n / 4;
    } else throw Error(Vs);
    else for(; o < n;)a[o++] = Math.random() * 1e7 | 0;
    for(n = a[--o], e %= E, n && e && (i = U(10, E - e), a[o] = (n / i | 0) * i); a[o] === 0; o--)a.pop();
    if (o < 0) t = 0, a = [
        0
    ];
    else {
        for(t = -1; a[0] === 0; t -= E)a.shift();
        for(n = 1, i = a[0]; i >= 10; i /= 10)n++;
        n < E && (t -= E - n);
    }
    return s.e = t, s.d = a, s;
}
function ed(e) {
    return y(e = new this(e), e.e + 1, this.rounding);
}
function rd(e) {
    return e = new this(e), e.d ? e.d[0] ? e.s : 0 * e.s : e.s || NaN;
}
function td(e) {
    return new this(e).sin();
}
function nd(e) {
    return new this(e).sinh();
}
function id(e) {
    return new this(e).sqrt();
}
function od(e, r) {
    return new this(e).sub(r);
}
function sd() {
    var e = 0, r = arguments, t = new this(r[e]);
    for(w = !1; t.s && ++e < r.length;)t = t.plus(r[e]);
    return w = !0, y(t, this.precision, this.rounding);
}
function ad(e) {
    return new this(e).tan();
}
function ld(e) {
    return new this(e).tanh();
}
function ud(e) {
    return y(e = new this(e), e.e + 1, 1);
}
m[Symbol.for("nodejs.util.inspect.custom")] = m.toString;
m[Symbol.toStringTag] = "Decimal";
var sr = m.constructor = Ks(ji);
un = new sr(un);
cn = new sr(cn);
var ve = sr;
function Tr(e) {
    return e === null ? e : Array.isArray(e) ? e.map(Tr) : typeof e == "object" ? cd(e) ? pd(e) : xr(e, Tr) : e;
}
function cd(e) {
    return e !== null && typeof e == "object" && typeof e.$type == "string";
}
function pd({ $type: e, value: r }) {
    switch(e){
        case "BigInt":
            return BigInt(r);
        case "Bytes":
            {
                let { buffer: t, byteOffset: n, byteLength: i } = Buffer.from(r, "base64");
                return new Uint8Array(t, n, i);
            }
        case "DateTime":
            return new Date(r);
        case "Decimal":
            return new ve(r);
        case "Json":
            return JSON.parse(r);
        default:
            _e(r, "Unknown tagged value");
    }
}
var Pe = class {
    _map = new Map;
    get(r) {
        return this._map.get(r)?.value;
    }
    set(r, t) {
        this._map.set(r, {
            value: t
        });
    }
    getOrCreate(r, t) {
        let n = this._map.get(r);
        if (n) return n.value;
        let i = t();
        return this.set(r, i), i;
    }
};
function Ye(e) {
    return e.substring(0, 1).toLowerCase() + e.substring(1);
}
function Ys(e, r) {
    let t = {};
    for (let n of e){
        let i = n[r];
        t[i] = n;
    }
    return t;
}
function at(e) {
    let r;
    return {
        get () {
            return r || (r = {
                value: e()
            }), r.value;
        }
    };
}
function zs(e) {
    return {
        models: Qi(e.models),
        enums: Qi(e.enums),
        types: Qi(e.types)
    };
}
function Qi(e) {
    let r = {};
    for (let { name: t, ...n } of e)r[t] = n;
    return r;
}
function Sr(e) {
    return e instanceof Date || Object.prototype.toString.call(e) === "[object Date]";
}
function gn(e) {
    return e.toString() !== "Invalid Date";
}
function Rr(e) {
    return sr.isDecimal(e) ? !0 : e !== null && typeof e == "object" && typeof e.s == "number" && typeof e.e == "number" && typeof e.toFixed == "function" && Array.isArray(e.d);
}
var lt = {};
tr(lt, {
    ModelAction: ()=>Cr,
    datamodelEnumToSchemaEnum: ()=>dd
});
function dd(e) {
    return {
        name: e.name,
        values: e.values.map((r)=>r.name)
    };
}
var Cr = ((b)=>(b.findUnique = "findUnique", b.findUniqueOrThrow = "findUniqueOrThrow", b.findFirst = "findFirst", b.findFirstOrThrow = "findFirstOrThrow", b.findMany = "findMany", b.create = "create", b.createMany = "createMany", b.createManyAndReturn = "createManyAndReturn", b.update = "update", b.updateMany = "updateMany", b.updateManyAndReturn = "updateManyAndReturn", b.upsert = "upsert", b.delete = "delete", b.deleteMany = "deleteMany", b.groupBy = "groupBy", b.count = "count", b.aggregate = "aggregate", b.findRaw = "findRaw", b.aggregateRaw = "aggregateRaw", b))(Cr || {});
var ta = k(Ri());
var ra = k(__turbopack_context__.r("[externals]/node:fs [external] (node:fs, cjs)"));
var Zs = {
    keyword: Oe,
    entity: Oe,
    value: (e)=>W(nr(e)),
    punctuation: nr,
    directive: Oe,
    function: Oe,
    variable: (e)=>W(nr(e)),
    string: (e)=>W(qe(e)),
    boolean: ke,
    number: Oe,
    comment: Hr
};
var md = (e)=>e, hn = {}, fd = 0, v = {
    manual: hn.Prism && hn.Prism.manual,
    disableWorkerMessageHandler: hn.Prism && hn.Prism.disableWorkerMessageHandler,
    util: {
        encode: function(e) {
            if (e instanceof ge) {
                let r = e;
                return new ge(r.type, v.util.encode(r.content), r.alias);
            } else return Array.isArray(e) ? e.map(v.util.encode) : e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        type: function(e) {
            return Object.prototype.toString.call(e).slice(8, -1);
        },
        objId: function(e) {
            return e.__id || Object.defineProperty(e, "__id", {
                value: ++fd
            }), e.__id;
        },
        clone: function e(r, t) {
            let n, i, o = v.util.type(r);
            switch(t = t || {}, o){
                case "Object":
                    if (i = v.util.objId(r), t[i]) return t[i];
                    n = {}, t[i] = n;
                    for(let s in r)r.hasOwnProperty(s) && (n[s] = e(r[s], t));
                    return n;
                case "Array":
                    return i = v.util.objId(r), t[i] ? t[i] : (n = [], t[i] = n, r.forEach(function(s, a) {
                        n[a] = e(s, t);
                    }), n);
                default:
                    return r;
            }
        }
    },
    languages: {
        extend: function(e, r) {
            let t = v.util.clone(v.languages[e]);
            for(let n in r)t[n] = r[n];
            return t;
        },
        insertBefore: function(e, r, t, n) {
            n = n || v.languages;
            let i = n[e], o = {};
            for(let a in i)if (i.hasOwnProperty(a)) {
                if (a == r) for(let l in t)t.hasOwnProperty(l) && (o[l] = t[l]);
                t.hasOwnProperty(a) || (o[a] = i[a]);
            }
            let s = n[e];
            return n[e] = o, v.languages.DFS(v.languages, function(a, l) {
                l === s && a != e && (this[a] = o);
            }), o;
        },
        DFS: function e(r, t, n, i) {
            i = i || {};
            let o = v.util.objId;
            for(let s in r)if (r.hasOwnProperty(s)) {
                t.call(r, s, r[s], n || s);
                let a = r[s], l = v.util.type(a);
                l === "Object" && !i[o(a)] ? (i[o(a)] = !0, e(a, t, null, i)) : l === "Array" && !i[o(a)] && (i[o(a)] = !0, e(a, t, s, i));
            }
        }
    },
    plugins: {},
    highlight: function(e, r, t) {
        let n = {
            code: e,
            grammar: r,
            language: t
        };
        return v.hooks.run("before-tokenize", n), n.tokens = v.tokenize(n.code, n.grammar), v.hooks.run("after-tokenize", n), ge.stringify(v.util.encode(n.tokens), n.language);
    },
    matchGrammar: function(e, r, t, n, i, o, s) {
        for(let h in t){
            if (!t.hasOwnProperty(h) || !t[h]) continue;
            if (h == s) return;
            let I = t[h];
            I = v.util.type(I) === "Array" ? I : [
                I
            ];
            for(let P = 0; P < I.length; ++P){
                let S = I[P], b = S.inside, O = !!S.lookbehind, me = !!S.greedy, ae = 0, Jr = S.alias;
                if (me && !S.pattern.global) {
                    let V = S.pattern.toString().match(/[imuy]*$/)[0];
                    S.pattern = RegExp(S.pattern.source, V + "g");
                }
                S = S.pattern || S;
                for(let V = n, te = i; V < r.length; te += r[V].length, ++V){
                    let Ae = r[V];
                    if (r.length > e.length) return;
                    if (Ae instanceof ge) continue;
                    if (me && V != r.length - 1) {
                        S.lastIndex = te;
                        var p = S.exec(e);
                        if (!p) break;
                        var c = p.index + (O ? p[1].length : 0), d = p.index + p[0].length, a = V, l = te;
                        for(let _ = r.length; a < _ && (l < d || !r[a].type && !r[a - 1].greedy); ++a)l += r[a].length, c >= l && (++V, te = l);
                        if (r[V] instanceof ge) continue;
                        u = a - V, Ae = e.slice(te, l), p.index -= te;
                    } else {
                        S.lastIndex = 0;
                        var p = S.exec(Ae), u = 1;
                    }
                    if (!p) {
                        if (o) break;
                        continue;
                    }
                    O && (ae = p[1] ? p[1].length : 0);
                    var c = p.index + ae, p = p[0].slice(ae), d = c + p.length, f = Ae.slice(0, c), g = Ae.slice(d);
                    let H = [
                        V,
                        u
                    ];
                    f && (++V, te += f.length, H.push(f));
                    let fr = new ge(h, b ? v.tokenize(p, b) : p, Jr, p, me);
                    if (H.push(fr), g && H.push(g), Array.prototype.splice.apply(r, H), u != 1 && v.matchGrammar(e, r, t, V, te, !0, h), o) break;
                }
            }
        }
    },
    tokenize: function(e, r) {
        let t = [
            e
        ], n = r.rest;
        if (n) {
            for(let i in n)r[i] = n[i];
            delete r.rest;
        }
        return v.matchGrammar(e, t, r, 0, 0, !1), t;
    },
    hooks: {
        all: {},
        add: function(e, r) {
            let t = v.hooks.all;
            t[e] = t[e] || [], t[e].push(r);
        },
        run: function(e, r) {
            let t = v.hooks.all[e];
            if (!(!t || !t.length)) for(var n = 0, i; i = t[n++];)i(r);
        }
    },
    Token: ge
};
v.languages.clike = {
    comment: [
        {
            pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
            lookbehind: !0
        },
        {
            pattern: /(^|[^\\:])\/\/.*/,
            lookbehind: !0,
            greedy: !0
        }
    ],
    string: {
        pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
        greedy: !0
    },
    "class-name": {
        pattern: /((?:\b(?:class|interface|extends|implements|trait|instanceof|new)\s+)|(?:catch\s+\())[\w.\\]+/i,
        lookbehind: !0,
        inside: {
            punctuation: /[.\\]/
        }
    },
    keyword: /\b(?:if|else|while|do|for|return|in|instanceof|function|new|try|throw|catch|finally|null|break|continue)\b/,
    boolean: /\b(?:true|false)\b/,
    function: /\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+\.?\d*|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /--?|\+\+?|!=?=?|<=?|>=?|==?=?|&&?|\|\|?|\?|\*|\/|~|\^|%/,
    punctuation: /[{}[\];(),.:]/
};
v.languages.javascript = v.languages.extend("clike", {
    "class-name": [
        v.languages.clike["class-name"],
        {
            pattern: /(^|[^$\w\xA0-\uFFFF])[_$A-Z\xA0-\uFFFF][$\w\xA0-\uFFFF]*(?=\.(?:prototype|constructor))/,
            lookbehind: !0
        }
    ],
    keyword: [
        {
            pattern: /((?:^|})\s*)(?:catch|finally)\b/,
            lookbehind: !0
        },
        {
            pattern: /(^|[^.])\b(?:as|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
            lookbehind: !0
        }
    ],
    number: /\b(?:(?:0[xX](?:[\dA-Fa-f](?:_[\dA-Fa-f])?)+|0[bB](?:[01](?:_[01])?)+|0[oO](?:[0-7](?:_[0-7])?)+)n?|(?:\d(?:_\d)?)+n|NaN|Infinity)\b|(?:\b(?:\d(?:_\d)?)+\.?(?:\d(?:_\d)?)*|\B\.(?:\d(?:_\d)?)+)(?:[Ee][+-]?(?:\d(?:_\d)?)+)?/,
    function: /[_$a-zA-Z\xA0-\uFFFF][$\w\xA0-\uFFFF]*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    operator: /-[-=]?|\+[+=]?|!=?=?|<<?=?|>>?>?=?|=(?:==?|>)?|&[&=]?|\|[|=]?|\*\*?=?|\/=?|~|\^=?|%=?|\?|\.{3}/
});
v.languages.javascript["class-name"][0].pattern = /(\b(?:class|interface|extends|implements|instanceof|new)\s+)[\w.\\]+/;
v.languages.insertBefore("javascript", "keyword", {
    regex: {
        pattern: /((?:^|[^$\w\xA0-\uFFFF."'\])\s])\s*)\/(\[(?:[^\]\\\r\n]|\\.)*]|\\.|[^/\\\[\r\n])+\/[gimyus]{0,6}(?=\s*($|[\r\n,.;})\]]))/,
        lookbehind: !0,
        greedy: !0
    },
    "function-variable": {
        pattern: /[_$a-zA-Z\xA0-\uFFFF][$\w\xA0-\uFFFF]*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|[_$a-zA-Z\xA0-\uFFFF][$\w\xA0-\uFFFF]*)\s*=>))/,
        alias: "function"
    },
    parameter: [
        {
            pattern: /(function(?:\s+[_$A-Za-z\xA0-\uFFFF][$\w\xA0-\uFFFF]*)?\s*\(\s*)(?!\s)(?:[^()]|\([^()]*\))+?(?=\s*\))/,
            lookbehind: !0,
            inside: v.languages.javascript
        },
        {
            pattern: /[_$a-z\xA0-\uFFFF][$\w\xA0-\uFFFF]*(?=\s*=>)/i,
            inside: v.languages.javascript
        },
        {
            pattern: /(\(\s*)(?!\s)(?:[^()]|\([^()]*\))+?(?=\s*\)\s*=>)/,
            lookbehind: !0,
            inside: v.languages.javascript
        },
        {
            pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:[_$A-Za-z\xA0-\uFFFF][$\w\xA0-\uFFFF]*\s*)\(\s*)(?!\s)(?:[^()]|\([^()]*\))+?(?=\s*\)\s*\{)/,
            lookbehind: !0,
            inside: v.languages.javascript
        }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
});
v.languages.markup && v.languages.markup.tag.addInlined("script", "javascript");
v.languages.js = v.languages.javascript;
v.languages.typescript = v.languages.extend("javascript", {
    keyword: /\b(?:abstract|as|async|await|break|case|catch|class|const|constructor|continue|debugger|declare|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|is|keyof|let|module|namespace|new|null|of|package|private|protected|public|readonly|return|require|set|static|super|switch|this|throw|try|type|typeof|var|void|while|with|yield)\b/,
    builtin: /\b(?:string|Function|any|number|boolean|Array|symbol|console|Promise|unknown|never)\b/
});
v.languages.ts = v.languages.typescript;
function ge(e, r, t, n, i) {
    this.type = e, this.content = r, this.alias = t, this.length = (n || "").length | 0, this.greedy = !!i;
}
ge.stringify = function(e, r) {
    return typeof e == "string" ? e : Array.isArray(e) ? e.map(function(t) {
        return ge.stringify(t, r);
    }).join("") : gd(e.type)(e.content);
};
function gd(e) {
    return Zs[e] || md;
}
function Xs(e) {
    return hd(e, v.languages.javascript);
}
function hd(e, r) {
    return v.tokenize(e, r).map((n)=>ge.stringify(n)).join("");
}
function ea(e) {
    return Ti(e);
}
var yn = class e {
    firstLineNumber;
    lines;
    static read(r) {
        let t;
        try {
            t = ra.default.readFileSync(r, "utf-8");
        } catch  {
            return null;
        }
        return e.fromContent(t);
    }
    static fromContent(r) {
        let t = r.split(/\r?\n/);
        return new e(1, t);
    }
    constructor(r, t){
        this.firstLineNumber = r, this.lines = t;
    }
    get lastLineNumber() {
        return this.firstLineNumber + this.lines.length - 1;
    }
    mapLineAt(r, t) {
        if (r < this.firstLineNumber || r > this.lines.length + this.firstLineNumber) return this;
        let n = r - this.firstLineNumber, i = [
            ...this.lines
        ];
        return i[n] = t(i[n]), new e(this.firstLineNumber, i);
    }
    mapLines(r) {
        return new e(this.firstLineNumber, this.lines.map((t, n)=>r(t, this.firstLineNumber + n)));
    }
    lineAt(r) {
        return this.lines[r - this.firstLineNumber];
    }
    prependSymbolAt(r, t) {
        return this.mapLines((n, i)=>i === r ? `${t} ${n}` : `  ${n}`);
    }
    slice(r, t) {
        let n = this.lines.slice(r - 1, t).join(`
`);
        return new e(r, ea(n).split(`
`));
    }
    highlight() {
        let r = Xs(this.toString());
        return new e(this.firstLineNumber, r.split(`
`));
    }
    toString() {
        return this.lines.join(`
`);
    }
};
var yd = {
    red: ce,
    gray: Hr,
    dim: Ie,
    bold: W,
    underline: Y,
    highlightSource: (e)=>e.highlight()
}, bd = {
    red: (e)=>e,
    gray: (e)=>e,
    dim: (e)=>e,
    bold: (e)=>e,
    underline: (e)=>e,
    highlightSource: (e)=>e
};
function Ed({ message: e, originalMethod: r, isPanic: t, callArguments: n }) {
    return {
        functionName: `prisma.${r}()`,
        message: e,
        isPanic: t ?? !1,
        callArguments: n
    };
}
function wd({ callsite: e, message: r, originalMethod: t, isPanic: n, callArguments: i }, o) {
    let s = Ed({
        message: r,
        originalMethod: t,
        isPanic: n,
        callArguments: i
    });
    if (!e || "undefined" < "u" || ("TURBOPACK compile-time value", "development") === "production") return s;
    let a = e.getLocation();
    if (!a || !a.lineNumber || !a.columnNumber) return s;
    let l = Math.max(1, a.lineNumber - 3), u = yn.read(a.fileName)?.slice(l, a.lineNumber), c = u?.lineAt(a.lineNumber);
    if (u && c) {
        let p = vd(c), d = xd(c);
        if (!d) return s;
        s.functionName = `${d.code})`, s.location = a, n || (u = u.mapLineAt(a.lineNumber, (g)=>g.slice(0, d.openingBraceIndex))), u = o.highlightSource(u);
        let f = String(u.lastLineNumber).length;
        if (s.contextLines = u.mapLines((g, h)=>o.gray(String(h).padStart(f)) + " " + g).mapLines((g)=>o.dim(g)).prependSymbolAt(a.lineNumber, o.bold(o.red("\u2192"))), i) {
            let g = p + f + 1;
            g += 2, s.callArguments = (0, ta.default)(i, g).slice(g);
        }
    }
    return s;
}
function xd(e) {
    let r = Object.keys(Cr).join("|"), n = new RegExp(String.raw`\.(${r})\(`).exec(e);
    if (n) {
        let i = n.index + n[0].length, o = e.lastIndexOf(" ", n.index) + 1;
        return {
            code: e.slice(o, i),
            openingBraceIndex: i
        };
    }
    return null;
}
function vd(e) {
    let r = 0;
    for(let t = 0; t < e.length; t++){
        if (e.charAt(t) !== " ") return r;
        r++;
    }
    return r;
}
function Pd({ functionName: e, location: r, message: t, isPanic: n, contextLines: i, callArguments: o }, s) {
    let a = [
        ""
    ], l = r ? " in" : ":";
    if (n ? (a.push(s.red(`Oops, an unknown error occurred! This is ${s.bold("on us")}, you did nothing wrong.`)), a.push(s.red(`It occurred in the ${s.bold(`\`${e}\``)} invocation${l}`))) : a.push(s.red(`Invalid ${s.bold(`\`${e}\``)} invocation${l}`)), r && a.push(s.underline(Td(r))), i) {
        a.push("");
        let u = [
            i.toString()
        ];
        o && (u.push(o), u.push(s.dim(")"))), a.push(u.join("")), o && a.push("");
    } else a.push(""), o && a.push(o), a.push("");
    return a.push(t), a.join(`
`);
}
function Td(e) {
    let r = [
        e.fileName
    ];
    return e.lineNumber && r.push(String(e.lineNumber)), e.columnNumber && r.push(String(e.columnNumber)), r.join(":");
}
function bn(e) {
    let r = e.showColors ? yd : bd, t;
    return t = wd(e, r), Pd(t, r);
}
var pa = k(Gi());
function sa(e, r, t) {
    let n = aa(e), i = Sd(n), o = Cd(i);
    o ? En(o, r, t) : r.addErrorMessage(()=>"Unknown error");
}
function aa(e) {
    return e.errors.flatMap((r)=>r.kind === "Union" ? aa(r) : [
            r
        ]);
}
function Sd(e) {
    let r = new Map, t = [];
    for (let n of e){
        if (n.kind !== "InvalidArgumentType") {
            t.push(n);
            continue;
        }
        let i = `${n.selectionPath.join(".")}:${n.argumentPath.join(".")}`, o = r.get(i);
        o ? r.set(i, {
            ...n,
            argument: {
                ...n.argument,
                typeNames: Rd(o.argument.typeNames, n.argument.typeNames)
            }
        }) : r.set(i, n);
    }
    return t.push(...r.values()), t;
}
function Rd(e, r) {
    return [
        ...new Set(e.concat(r))
    ];
}
function Cd(e) {
    return $i(e, (r, t)=>{
        let n = ia(r), i = ia(t);
        return n !== i ? n - i : oa(r) - oa(t);
    });
}
function ia(e) {
    let r = 0;
    return Array.isArray(e.selectionPath) && (r += e.selectionPath.length), Array.isArray(e.argumentPath) && (r += e.argumentPath.length), r;
}
function oa(e) {
    switch(e.kind){
        case "InvalidArgumentValue":
        case "ValueTooLarge":
            return 20;
        case "InvalidArgumentType":
            return 10;
        case "RequiredArgumentMissing":
            return -10;
        default:
            return 0;
    }
}
var ue = class {
    constructor(r, t){
        this.name = r;
        this.value = t;
    }
    isRequired = !1;
    makeRequired() {
        return this.isRequired = !0, this;
    }
    write(r) {
        let { colors: { green: t } } = r.context;
        r.addMarginSymbol(t(this.isRequired ? "+" : "?")), r.write(t(this.name)), this.isRequired || r.write(t("?")), r.write(t(": ")), typeof this.value == "string" ? r.write(t(this.value)) : r.write(this.value);
    }
};
ua();
var Ar = class {
    constructor(r = 0, t){
        this.context = t;
        this.currentIndent = r;
    }
    lines = [];
    currentLine = "";
    currentIndent = 0;
    marginSymbol;
    afterNextNewLineCallback;
    write(r) {
        return typeof r == "string" ? this.currentLine += r : r.write(this), this;
    }
    writeJoined(r, t, n = (i, o)=>o.write(i)) {
        let i = t.length - 1;
        for(let o = 0; o < t.length; o++)n(t[o], this), o !== i && this.write(r);
        return this;
    }
    writeLine(r) {
        return this.write(r).newLine();
    }
    newLine() {
        this.lines.push(this.indentedCurrentLine()), this.currentLine = "", this.marginSymbol = void 0;
        let r = this.afterNextNewLineCallback;
        return this.afterNextNewLineCallback = void 0, r?.(), this;
    }
    withIndent(r) {
        return this.indent(), r(this), this.unindent(), this;
    }
    afterNextNewline(r) {
        return this.afterNextNewLineCallback = r, this;
    }
    indent() {
        return this.currentIndent++, this;
    }
    unindent() {
        return this.currentIndent > 0 && this.currentIndent--, this;
    }
    addMarginSymbol(r) {
        return this.marginSymbol = r, this;
    }
    toString() {
        return this.lines.concat(this.indentedCurrentLine()).join(`
`);
    }
    getCurrentLineLength() {
        return this.currentLine.length;
    }
    indentedCurrentLine() {
        let r = this.currentLine.padStart(this.currentLine.length + 2 * this.currentIndent);
        return this.marginSymbol ? this.marginSymbol + r.slice(1) : r;
    }
};
la();
var wn = class {
    constructor(r){
        this.value = r;
    }
    write(r) {
        r.write(this.value);
    }
    markAsError() {
        this.value.markAsError();
    }
};
var xn = (e)=>e, vn = {
    bold: xn,
    red: xn,
    green: xn,
    dim: xn,
    enabled: !1
}, ca = {
    bold: W,
    red: ce,
    green: qe,
    dim: Ie,
    enabled: !0
}, Ir = {
    write (e) {
        e.writeLine(",");
    }
};
var Te = class {
    constructor(r){
        this.contents = r;
    }
    isUnderlined = !1;
    color = (r)=>r;
    underline() {
        return this.isUnderlined = !0, this;
    }
    setColor(r) {
        return this.color = r, this;
    }
    write(r) {
        let t = r.getCurrentLineLength();
        r.write(this.color(this.contents)), this.isUnderlined && r.afterNextNewline(()=>{
            r.write(" ".repeat(t)).writeLine(this.color("~".repeat(this.contents.length)));
        });
    }
};
var ze = class {
    hasError = !1;
    markAsError() {
        return this.hasError = !0, this;
    }
};
var kr = class extends ze {
    items = [];
    addItem(r) {
        return this.items.push(new wn(r)), this;
    }
    getField(r) {
        return this.items[r];
    }
    getPrintWidth() {
        return this.items.length === 0 ? 2 : Math.max(...this.items.map((t)=>t.value.getPrintWidth())) + 2;
    }
    write(r) {
        if (this.items.length === 0) {
            this.writeEmpty(r);
            return;
        }
        this.writeWithItems(r);
    }
    writeEmpty(r) {
        let t = new Te("[]");
        this.hasError && t.setColor(r.context.colors.red).underline(), r.write(t);
    }
    writeWithItems(r) {
        let { colors: t } = r.context;
        r.writeLine("[").withIndent(()=>r.writeJoined(Ir, this.items).newLine()).write("]"), this.hasError && r.afterNextNewline(()=>{
            r.writeLine(t.red("~".repeat(this.getPrintWidth())));
        });
    }
    asObject() {}
};
var Or = class e extends ze {
    fields = {};
    suggestions = [];
    addField(r) {
        this.fields[r.name] = r;
    }
    addSuggestion(r) {
        this.suggestions.push(r);
    }
    getField(r) {
        return this.fields[r];
    }
    getDeepField(r) {
        let [t, ...n] = r, i = this.getField(t);
        if (!i) return;
        let o = i;
        for (let s of n){
            let a;
            if (o.value instanceof e ? a = o.value.getField(s) : o.value instanceof kr && (a = o.value.getField(Number(s))), !a) return;
            o = a;
        }
        return o;
    }
    getDeepFieldValue(r) {
        return r.length === 0 ? this : this.getDeepField(r)?.value;
    }
    hasField(r) {
        return !!this.getField(r);
    }
    removeAllFields() {
        this.fields = {};
    }
    removeField(r) {
        delete this.fields[r];
    }
    getFields() {
        return this.fields;
    }
    isEmpty() {
        return Object.keys(this.fields).length === 0;
    }
    getFieldValue(r) {
        return this.getField(r)?.value;
    }
    getDeepSubSelectionValue(r) {
        let t = this;
        for (let n of r){
            if (!(t instanceof e)) return;
            let i = t.getSubSelectionValue(n);
            if (!i) return;
            t = i;
        }
        return t;
    }
    getDeepSelectionParent(r) {
        let t = this.getSelectionParent();
        if (!t) return;
        let n = t;
        for (let i of r){
            let o = n.value.getFieldValue(i);
            if (!o || !(o instanceof e)) return;
            let s = o.getSelectionParent();
            if (!s) return;
            n = s;
        }
        return n;
    }
    getSelectionParent() {
        let r = this.getField("select")?.value.asObject();
        if (r) return {
            kind: "select",
            value: r
        };
        let t = this.getField("include")?.value.asObject();
        if (t) return {
            kind: "include",
            value: t
        };
    }
    getSubSelectionValue(r) {
        return this.getSelectionParent()?.value.fields[r].value;
    }
    getPrintWidth() {
        let r = Object.values(this.fields);
        return r.length == 0 ? 2 : Math.max(...r.map((n)=>n.getPrintWidth())) + 2;
    }
    write(r) {
        let t = Object.values(this.fields);
        if (t.length === 0 && this.suggestions.length === 0) {
            this.writeEmpty(r);
            return;
        }
        this.writeWithContents(r, t);
    }
    asObject() {
        return this;
    }
    writeEmpty(r) {
        let t = new Te("{}");
        this.hasError && t.setColor(r.context.colors.red).underline(), r.write(t);
    }
    writeWithContents(r, t) {
        r.writeLine("{").withIndent(()=>{
            r.writeJoined(Ir, [
                ...t,
                ...this.suggestions
            ]).newLine();
        }), r.write("}"), this.hasError && r.afterNextNewline(()=>{
            r.writeLine(r.context.colors.red("~".repeat(this.getPrintWidth())));
        });
    }
};
var G = class extends ze {
    constructor(t){
        super();
        this.text = t;
    }
    getPrintWidth() {
        return this.text.length;
    }
    write(t) {
        let n = new Te(this.text);
        this.hasError && n.underline().setColor(t.context.colors.red), t.write(n);
    }
    asObject() {}
};
var ut = class {
    fields = [];
    addField(r, t) {
        return this.fields.push({
            write (n) {
                let { green: i, dim: o } = n.context.colors;
                n.write(i(o(`${r}: ${t}`))).addMarginSymbol(i(o("+")));
            }
        }), this;
    }
    write(r) {
        let { colors: { green: t } } = r.context;
        r.writeLine(t("{")).withIndent(()=>{
            r.writeJoined(Ir, this.fields).newLine();
        }).write(t("}")).addMarginSymbol(t("+"));
    }
};
function En(e, r, t) {
    switch(e.kind){
        case "MutuallyExclusiveFields":
            Ad(e, r);
            break;
        case "IncludeOnScalar":
            Id(e, r);
            break;
        case "EmptySelection":
            kd(e, r, t);
            break;
        case "UnknownSelectionField":
            Nd(e, r);
            break;
        case "InvalidSelectionValue":
            Fd(e, r);
            break;
        case "UnknownArgument":
            Ld(e, r);
            break;
        case "UnknownInputField":
            Md(e, r);
            break;
        case "RequiredArgumentMissing":
            $d(e, r);
            break;
        case "InvalidArgumentType":
            qd(e, r);
            break;
        case "InvalidArgumentValue":
            jd(e, r);
            break;
        case "ValueTooLarge":
            Vd(e, r);
            break;
        case "SomeFieldsMissing":
            Bd(e, r);
            break;
        case "TooManyFieldsGiven":
            Ud(e, r);
            break;
        case "Union":
            sa(e, r, t);
            break;
        default:
            throw new Error("not implemented: " + e.kind);
    }
}
function Ad(e, r) {
    let t = r.arguments.getDeepSubSelectionValue(e.selectionPath)?.asObject();
    t && (t.getField(e.firstField)?.markAsError(), t.getField(e.secondField)?.markAsError()), r.addErrorMessage((n)=>`Please ${n.bold("either")} use ${n.green(`\`${e.firstField}\``)} or ${n.green(`\`${e.secondField}\``)}, but ${n.red("not both")} at the same time.`);
}
function Id(e, r) {
    let [t, n] = ct(e.selectionPath), i = e.outputType, o = r.arguments.getDeepSelectionParent(t)?.value;
    if (o && (o.getField(n)?.markAsError(), i)) for (let s of i.fields)s.isRelation && o.addSuggestion(new ue(s.name, "true"));
    r.addErrorMessage((s)=>{
        let a = `Invalid scalar field ${s.red(`\`${n}\``)} for ${s.bold("include")} statement`;
        return i ? a += ` on model ${s.bold(i.name)}. ${pt(s)}` : a += ".", a += `
Note that ${s.bold("include")} statements only accept relation fields.`, a;
    });
}
function kd(e, r, t) {
    let n = r.arguments.getDeepSubSelectionValue(e.selectionPath)?.asObject();
    if (n) {
        let i = n.getField("omit")?.value.asObject();
        if (i) {
            Od(e, r, i);
            return;
        }
        if (n.hasField("select")) {
            Dd(e, r);
            return;
        }
    }
    if (t?.[Ye(e.outputType.name)]) {
        _d(e, r);
        return;
    }
    r.addErrorMessage(()=>`Unknown field at "${e.selectionPath.join(".")} selection"`);
}
function Od(e, r, t) {
    t.removeAllFields();
    for (let n of e.outputType.fields)t.addSuggestion(new ue(n.name, "false"));
    r.addErrorMessage((n)=>`The ${n.red("omit")} statement includes every field of the model ${n.bold(e.outputType.name)}. At least one field must be included in the result`);
}
function Dd(e, r) {
    let t = e.outputType, n = r.arguments.getDeepSelectionParent(e.selectionPath)?.value, i = n?.isEmpty() ?? !1;
    n && (n.removeAllFields(), fa(n, t)), r.addErrorMessage((o)=>i ? `The ${o.red("`select`")} statement for type ${o.bold(t.name)} must not be empty. ${pt(o)}` : `The ${o.red("`select`")} statement for type ${o.bold(t.name)} needs ${o.bold("at least one truthy value")}.`);
}
function _d(e, r) {
    let t = new ut;
    for (let i of e.outputType.fields)i.isRelation || t.addField(i.name, "false");
    let n = new ue("omit", t).makeRequired();
    if (e.selectionPath.length === 0) r.arguments.addSuggestion(n);
    else {
        let [i, o] = ct(e.selectionPath), a = r.arguments.getDeepSelectionParent(i)?.value.asObject()?.getField(o);
        if (a) {
            let l = a?.value.asObject() ?? new Or;
            l.addSuggestion(n), a.value = l;
        }
    }
    r.addErrorMessage((i)=>`The global ${i.red("omit")} configuration excludes every field of the model ${i.bold(e.outputType.name)}. At least one field must be included in the result`);
}
function Nd(e, r) {
    let t = ga(e.selectionPath, r);
    if (t.parentKind !== "unknown") {
        t.field.markAsError();
        let n = t.parent;
        switch(t.parentKind){
            case "select":
                fa(n, e.outputType);
                break;
            case "include":
                Qd(n, e.outputType);
                break;
            case "omit":
                Gd(n, e.outputType);
                break;
        }
    }
    r.addErrorMessage((n)=>{
        let i = [
            `Unknown field ${n.red(`\`${t.fieldName}\``)}`
        ];
        return t.parentKind !== "unknown" && i.push(`for ${n.bold(t.parentKind)} statement`), i.push(`on model ${n.bold(`\`${e.outputType.name}\``)}.`), i.push(pt(n)), i.join(" ");
    });
}
function Fd(e, r) {
    let t = ga(e.selectionPath, r);
    t.parentKind !== "unknown" && t.field.value.markAsError(), r.addErrorMessage((n)=>`Invalid value for selection field \`${n.red(t.fieldName)}\`: ${e.underlyingError}`);
}
function Ld(e, r) {
    let t = e.argumentPath[0], n = r.arguments.getDeepSubSelectionValue(e.selectionPath)?.asObject();
    n && (n.getField(t)?.markAsError(), Wd(n, e.arguments)), r.addErrorMessage((i)=>da(i, t, e.arguments.map((o)=>o.name)));
}
function Md(e, r) {
    let [t, n] = ct(e.argumentPath), i = r.arguments.getDeepSubSelectionValue(e.selectionPath)?.asObject();
    if (i) {
        i.getDeepField(e.argumentPath)?.markAsError();
        let o = i.getDeepFieldValue(t)?.asObject();
        o && ha(o, e.inputType);
    }
    r.addErrorMessage((o)=>da(o, n, e.inputType.fields.map((s)=>s.name)));
}
function da(e, r, t) {
    let n = [
        `Unknown argument \`${e.red(r)}\`.`
    ], i = Hd(r, t);
    return i && n.push(`Did you mean \`${e.green(i)}\`?`), t.length > 0 && n.push(pt(e)), n.join(" ");
}
function $d(e, r) {
    let t;
    r.addErrorMessage((l)=>t?.value instanceof G && t.value.text === "null" ? `Argument \`${l.green(o)}\` must not be ${l.red("null")}.` : `Argument \`${l.green(o)}\` is missing.`);
    let n = r.arguments.getDeepSubSelectionValue(e.selectionPath)?.asObject();
    if (!n) return;
    let [i, o] = ct(e.argumentPath), s = new ut, a = n.getDeepFieldValue(i)?.asObject();
    if (a) if (t = a.getField(o), t && a.removeField(o), e.inputTypes.length === 1 && e.inputTypes[0].kind === "object") {
        for (let l of e.inputTypes[0].fields)s.addField(l.name, l.typeNames.join(" | "));
        a.addSuggestion(new ue(o, s).makeRequired());
    } else {
        let l = e.inputTypes.map(ma).join(" | ");
        a.addSuggestion(new ue(o, l).makeRequired());
    }
}
function ma(e) {
    return e.kind === "list" ? `${ma(e.elementType)}[]` : e.name;
}
function qd(e, r) {
    let t = e.argument.name, n = r.arguments.getDeepSubSelectionValue(e.selectionPath)?.asObject();
    n && n.getDeepFieldValue(e.argumentPath)?.markAsError(), r.addErrorMessage((i)=>{
        let o = Pn("or", e.argument.typeNames.map((s)=>i.green(s)));
        return `Argument \`${i.bold(t)}\`: Invalid value provided. Expected ${o}, provided ${i.red(e.inferredType)}.`;
    });
}
function jd(e, r) {
    let t = e.argument.name, n = r.arguments.getDeepSubSelectionValue(e.selectionPath)?.asObject();
    n && n.getDeepFieldValue(e.argumentPath)?.markAsError(), r.addErrorMessage((i)=>{
        let o = [
            `Invalid value for argument \`${i.bold(t)}\``
        ];
        if (e.underlyingError && o.push(`: ${e.underlyingError}`), o.push("."), e.argument.typeNames.length > 0) {
            let s = Pn("or", e.argument.typeNames.map((a)=>i.green(a)));
            o.push(` Expected ${s}.`);
        }
        return o.join("");
    });
}
function Vd(e, r) {
    let t = e.argument.name, n = r.arguments.getDeepSubSelectionValue(e.selectionPath)?.asObject(), i;
    if (n) {
        let s = n.getDeepField(e.argumentPath)?.value;
        s?.markAsError(), s instanceof G && (i = s.text);
    }
    r.addErrorMessage((o)=>{
        let s = [
            "Unable to fit value"
        ];
        return i && s.push(o.red(i)), s.push(`into a 64-bit signed integer for field \`${o.bold(t)}\``), s.join(" ");
    });
}
function Bd(e, r) {
    let t = e.argumentPath[e.argumentPath.length - 1], n = r.arguments.getDeepSubSelectionValue(e.selectionPath)?.asObject();
    if (n) {
        let i = n.getDeepFieldValue(e.argumentPath)?.asObject();
        i && ha(i, e.inputType);
    }
    r.addErrorMessage((i)=>{
        let o = [
            `Argument \`${i.bold(t)}\` of type ${i.bold(e.inputType.name)} needs`
        ];
        return e.constraints.minFieldCount === 1 ? e.constraints.requiredFields ? o.push(`${i.green("at least one of")} ${Pn("or", e.constraints.requiredFields.map((s)=>`\`${i.bold(s)}\``))} arguments.`) : o.push(`${i.green("at least one")} argument.`) : o.push(`${i.green(`at least ${e.constraints.minFieldCount}`)} arguments.`), o.push(pt(i)), o.join(" ");
    });
}
function Ud(e, r) {
    let t = e.argumentPath[e.argumentPath.length - 1], n = r.arguments.getDeepSubSelectionValue(e.selectionPath)?.asObject(), i = [];
    if (n) {
        let o = n.getDeepFieldValue(e.argumentPath)?.asObject();
        o && (o.markAsError(), i = Object.keys(o.getFields()));
    }
    r.addErrorMessage((o)=>{
        let s = [
            `Argument \`${o.bold(t)}\` of type ${o.bold(e.inputType.name)} needs`
        ];
        return e.constraints.minFieldCount === 1 && e.constraints.maxFieldCount == 1 ? s.push(`${o.green("exactly one")} argument,`) : e.constraints.maxFieldCount == 1 ? s.push(`${o.green("at most one")} argument,`) : s.push(`${o.green(`at most ${e.constraints.maxFieldCount}`)} arguments,`), s.push(`but you provided ${Pn("and", i.map((a)=>o.red(a)))}. Please choose`), e.constraints.maxFieldCount === 1 ? s.push("one.") : s.push(`${e.constraints.maxFieldCount}.`), s.join(" ");
    });
}
function fa(e, r) {
    for (let t of r.fields)e.hasField(t.name) || e.addSuggestion(new ue(t.name, "true"));
}
function Qd(e, r) {
    for (let t of r.fields)t.isRelation && !e.hasField(t.name) && e.addSuggestion(new ue(t.name, "true"));
}
function Gd(e, r) {
    for (let t of r.fields)!e.hasField(t.name) && !t.isRelation && e.addSuggestion(new ue(t.name, "true"));
}
function Wd(e, r) {
    for (let t of r)e.hasField(t.name) || e.addSuggestion(new ue(t.name, t.typeNames.join(" | ")));
}
function ga(e, r) {
    let [t, n] = ct(e), i = r.arguments.getDeepSubSelectionValue(t)?.asObject();
    if (!i) return {
        parentKind: "unknown",
        fieldName: n
    };
    let o = i.getFieldValue("select")?.asObject(), s = i.getFieldValue("include")?.asObject(), a = i.getFieldValue("omit")?.asObject(), l = o?.getField(n);
    return o && l ? {
        parentKind: "select",
        parent: o,
        field: l,
        fieldName: n
    } : (l = s?.getField(n), s && l ? {
        parentKind: "include",
        field: l,
        parent: s,
        fieldName: n
    } : (l = a?.getField(n), a && l ? {
        parentKind: "omit",
        field: l,
        parent: a,
        fieldName: n
    } : {
        parentKind: "unknown",
        fieldName: n
    }));
}
function ha(e, r) {
    if (r.kind === "object") for (let t of r.fields)e.hasField(t.name) || e.addSuggestion(new ue(t.name, t.typeNames.join(" | ")));
}
function ct(e) {
    let r = [
        ...e
    ], t = r.pop();
    if (!t) throw new Error("unexpected empty path");
    return [
        r,
        t
    ];
}
function pt({ green: e, enabled: r }) {
    return "Available options are " + (r ? `listed in ${e("green")}` : "marked with ?") + ".";
}
function Pn(e, r) {
    if (r.length === 1) return r[0];
    let t = [
        ...r
    ], n = t.pop();
    return `${t.join(", ")} ${e} ${n}`;
}
var Jd = 3;
function Hd(e, r) {
    let t = 1 / 0, n;
    for (let i of r){
        let o = (0, pa.default)(e, i);
        o > Jd || o < t && (t = o, n = i);
    }
    return n;
}
var dt = class {
    modelName;
    name;
    typeName;
    isList;
    isEnum;
    constructor(r, t, n, i, o){
        this.modelName = r, this.name = t, this.typeName = n, this.isList = i, this.isEnum = o;
    }
    _toGraphQLInputType() {
        let r = this.isList ? "List" : "", t = this.isEnum ? "Enum" : "";
        return `${r}${t}${this.typeName}FieldRefInput<${this.modelName}>`;
    }
};
function Dr(e) {
    return e instanceof dt;
}
var Tn = Symbol(), Ji = new WeakMap, Le = class {
    constructor(r){
        r === Tn ? Ji.set(this, `Prisma.${this._getName()}`) : Ji.set(this, `new Prisma.${this._getNamespace()}.${this._getName()}()`);
    }
    _getName() {
        return this.constructor.name;
    }
    toString() {
        return Ji.get(this);
    }
}, mt = class extends Le {
    _getNamespace() {
        return "NullTypes";
    }
}, ft = class extends mt {
    #e;
};
Hi(ft, "DbNull");
var gt = class extends mt {
    #e;
};
Hi(gt, "JsonNull");
var ht = class extends mt {
    #e;
};
Hi(ht, "AnyNull");
var Sn = {
    classes: {
        DbNull: ft,
        JsonNull: gt,
        AnyNull: ht
    },
    instances: {
        DbNull: new ft(Tn),
        JsonNull: new gt(Tn),
        AnyNull: new ht(Tn)
    }
};
function Hi(e, r) {
    Object.defineProperty(e, "name", {
        value: r,
        configurable: !0
    });
}
var ya = ": ", Rn = class {
    constructor(r, t){
        this.name = r;
        this.value = t;
    }
    hasError = !1;
    markAsError() {
        this.hasError = !0;
    }
    getPrintWidth() {
        return this.name.length + this.value.getPrintWidth() + ya.length;
    }
    write(r) {
        let t = new Te(this.name);
        this.hasError && t.underline().setColor(r.context.colors.red), r.write(t).write(ya).write(this.value);
    }
};
var Ki = class {
    arguments;
    errorMessages = [];
    constructor(r){
        this.arguments = r;
    }
    write(r) {
        r.write(this.arguments);
    }
    addErrorMessage(r) {
        this.errorMessages.push(r);
    }
    renderAllMessages(r) {
        return this.errorMessages.map((t)=>t(r)).join(`
`);
    }
};
function _r(e) {
    return new Ki(ba(e));
}
function ba(e) {
    let r = new Or;
    for (let [t, n] of Object.entries(e)){
        let i = new Rn(t, Ea(n));
        r.addField(i);
    }
    return r;
}
function Ea(e) {
    if (typeof e == "string") return new G(JSON.stringify(e));
    if (typeof e == "number" || typeof e == "boolean") return new G(String(e));
    if (typeof e == "bigint") return new G(`${e}n`);
    if (e === null) return new G("null");
    if (e === void 0) return new G("undefined");
    if (Rr(e)) return new G(`new Prisma.Decimal("${e.toFixed()}")`);
    if (e instanceof Uint8Array) return Buffer.isBuffer(e) ? new G(`Buffer.alloc(${e.byteLength})`) : new G(`new Uint8Array(${e.byteLength})`);
    if (e instanceof Date) {
        let r = gn(e) ? e.toISOString() : "Invalid Date";
        return new G(`new Date("${r}")`);
    }
    return e instanceof Le ? new G(`Prisma.${e._getName()}`) : Dr(e) ? new G(`prisma.${Ye(e.modelName)}.$fields.${e.name}`) : Array.isArray(e) ? Kd(e) : typeof e == "object" ? ba(e) : new G(Object.prototype.toString.call(e));
}
function Kd(e) {
    let r = new kr;
    for (let t of e)r.addItem(Ea(t));
    return r;
}
function Cn(e, r) {
    let t = r === "pretty" ? ca : vn, n = e.renderAllMessages(t), i = new Ar(0, {
        colors: t
    }).write(e).toString();
    return {
        message: n,
        args: i
    };
}
function An({ args: e, errors: r, errorFormat: t, callsite: n, originalMethod: i, clientVersion: o, globalOmit: s }) {
    let a = _r(e);
    for (let p of r)En(p, a, s);
    let { message: l, args: u } = Cn(a, t), c = bn({
        message: l,
        callsite: n,
        originalMethod: i,
        showColors: t === "pretty",
        callArguments: u
    });
    throw new Z(c, {
        clientVersion: o
    });
}
function Se(e) {
    return e.replace(/^./, (r)=>r.toLowerCase());
}
function xa(e, r, t) {
    let n = Se(t);
    return !r.result || !(r.result.$allModels || r.result[n]) ? e : Yd({
        ...e,
        ...wa(r.name, e, r.result.$allModels),
        ...wa(r.name, e, r.result[n])
    });
}
function Yd(e) {
    let r = new Pe, t = (n, i)=>r.getOrCreate(n, ()=>i.has(n) ? [
                n
            ] : (i.add(n), e[n] ? e[n].needs.flatMap((o)=>t(o, i)) : [
                n
            ]));
    return xr(e, (n)=>({
            ...n,
            needs: t(n.name, new Set)
        }));
}
function wa(e, r, t) {
    return t ? xr(t, ({ needs: n, compute: i }, o)=>({
            name: o,
            needs: n ? Object.keys(n).filter((s)=>n[s]) : [],
            compute: zd(r, o, i)
        })) : {};
}
function zd(e, r, t) {
    let n = e?.[r]?.compute;
    return n ? (i)=>t({
            ...i,
            [r]: n(i)
        }) : t;
}
function va(e, r) {
    if (!r) return e;
    let t = {
        ...e
    };
    for (let n of Object.values(r))if (e[n.name]) for (let i of n.needs)t[i] = !0;
    return t;
}
function Pa(e, r) {
    if (!r) return e;
    let t = {
        ...e
    };
    for (let n of Object.values(r))if (!e[n.name]) for (let i of n.needs)delete t[i];
    return t;
}
var In = class {
    constructor(r, t){
        this.extension = r;
        this.previous = t;
    }
    computedFieldsCache = new Pe;
    modelExtensionsCache = new Pe;
    queryCallbacksCache = new Pe;
    clientExtensions = at(()=>this.extension.client ? {
            ...this.previous?.getAllClientExtensions(),
            ...this.extension.client
        } : this.previous?.getAllClientExtensions());
    batchCallbacks = at(()=>{
        let r = this.previous?.getAllBatchQueryCallbacks() ?? [], t = this.extension.query?.$__internalBatch;
        return t ? r.concat(t) : r;
    });
    getAllComputedFields(r) {
        return this.computedFieldsCache.getOrCreate(r, ()=>xa(this.previous?.getAllComputedFields(r), this.extension, r));
    }
    getAllClientExtensions() {
        return this.clientExtensions.get();
    }
    getAllModelExtensions(r) {
        return this.modelExtensionsCache.getOrCreate(r, ()=>{
            let t = Se(r);
            return !this.extension.model || !(this.extension.model[t] || this.extension.model.$allModels) ? this.previous?.getAllModelExtensions(r) : {
                ...this.previous?.getAllModelExtensions(r),
                ...this.extension.model.$allModels,
                ...this.extension.model[t]
            };
        });
    }
    getAllQueryCallbacks(r, t) {
        return this.queryCallbacksCache.getOrCreate(`${r}:${t}`, ()=>{
            let n = this.previous?.getAllQueryCallbacks(r, t) ?? [], i = [], o = this.extension.query;
            return !o || !(o[r] || o.$allModels || o[t] || o.$allOperations) ? n : (o[r] !== void 0 && (o[r][t] !== void 0 && i.push(o[r][t]), o[r].$allOperations !== void 0 && i.push(o[r].$allOperations)), r !== "$none" && o.$allModels !== void 0 && (o.$allModels[t] !== void 0 && i.push(o.$allModels[t]), o.$allModels.$allOperations !== void 0 && i.push(o.$allModels.$allOperations)), o[t] !== void 0 && i.push(o[t]), o.$allOperations !== void 0 && i.push(o.$allOperations), n.concat(i));
        });
    }
    getAllBatchQueryCallbacks() {
        return this.batchCallbacks.get();
    }
}, Nr = class e {
    constructor(r){
        this.head = r;
    }
    static empty() {
        return new e;
    }
    static single(r) {
        return new e(new In(r));
    }
    isEmpty() {
        return this.head === void 0;
    }
    append(r) {
        return new e(new In(r, this.head));
    }
    getAllComputedFields(r) {
        return this.head?.getAllComputedFields(r);
    }
    getAllClientExtensions() {
        return this.head?.getAllClientExtensions();
    }
    getAllModelExtensions(r) {
        return this.head?.getAllModelExtensions(r);
    }
    getAllQueryCallbacks(r, t) {
        return this.head?.getAllQueryCallbacks(r, t) ?? [];
    }
    getAllBatchQueryCallbacks() {
        return this.head?.getAllBatchQueryCallbacks() ?? [];
    }
};
var kn = class {
    constructor(r){
        this.name = r;
    }
};
function Ta(e) {
    return e instanceof kn;
}
function Sa(e) {
    return new kn(e);
}
var Ra = Symbol(), yt = class {
    constructor(r){
        if (r !== Ra) throw new Error("Skip instance can not be constructed directly");
    }
    ifUndefined(r) {
        return r === void 0 ? On : r;
    }
}, On = new yt(Ra);
function Re(e) {
    return e instanceof yt;
}
var Zd = {
    findUnique: "findUnique",
    findUniqueOrThrow: "findUniqueOrThrow",
    findFirst: "findFirst",
    findFirstOrThrow: "findFirstOrThrow",
    findMany: "findMany",
    count: "aggregate",
    create: "createOne",
    createMany: "createMany",
    createManyAndReturn: "createManyAndReturn",
    update: "updateOne",
    updateMany: "updateMany",
    updateManyAndReturn: "updateManyAndReturn",
    upsert: "upsertOne",
    delete: "deleteOne",
    deleteMany: "deleteMany",
    executeRaw: "executeRaw",
    queryRaw: "queryRaw",
    aggregate: "aggregate",
    groupBy: "groupBy",
    runCommandRaw: "runCommandRaw",
    findRaw: "findRaw",
    aggregateRaw: "aggregateRaw"
}, Ca = "explicitly `undefined` values are not allowed";
function Dn({ modelName: e, action: r, args: t, runtimeDataModel: n, extensions: i = Nr.empty(), callsite: o, clientMethod: s, errorFormat: a, clientVersion: l, previewFeatures: u, globalOmit: c }) {
    let p = new Yi({
        runtimeDataModel: n,
        modelName: e,
        action: r,
        rootArgs: t,
        callsite: o,
        extensions: i,
        selectionPath: [],
        argumentPath: [],
        originalMethod: s,
        errorFormat: a,
        clientVersion: l,
        previewFeatures: u,
        globalOmit: c
    });
    return {
        modelName: e,
        action: Zd[r],
        query: bt(t, p)
    };
}
function bt({ select: e, include: r, ...t } = {}, n) {
    let i = t.omit;
    return delete t.omit, {
        arguments: Ia(t, n),
        selection: Xd(e, r, i, n)
    };
}
function Xd(e, r, t, n) {
    return e ? (r ? n.throwValidationError({
        kind: "MutuallyExclusiveFields",
        firstField: "include",
        secondField: "select",
        selectionPath: n.getSelectionPath()
    }) : t && n.throwValidationError({
        kind: "MutuallyExclusiveFields",
        firstField: "omit",
        secondField: "select",
        selectionPath: n.getSelectionPath()
    }), nm(e, n)) : em(n, r, t);
}
function em(e, r, t) {
    let n = {};
    return e.modelOrType && !e.isRawAction() && (n.$composites = !0, n.$scalars = !0), r && rm(n, r, e), tm(n, t, e), n;
}
function rm(e, r, t) {
    for (let [n, i] of Object.entries(r)){
        if (Re(i)) continue;
        let o = t.nestSelection(n);
        if (zi(i, o), i === !1 || i === void 0) {
            e[n] = !1;
            continue;
        }
        let s = t.findField(n);
        if (s && s.kind !== "object" && t.throwValidationError({
            kind: "IncludeOnScalar",
            selectionPath: t.getSelectionPath().concat(n),
            outputType: t.getOutputTypeDescription()
        }), s) {
            e[n] = bt(i === !0 ? {} : i, o);
            continue;
        }
        if (i === !0) {
            e[n] = !0;
            continue;
        }
        e[n] = bt(i, o);
    }
}
function tm(e, r, t) {
    let n = t.getComputedFields(), i = {
        ...t.getGlobalOmit(),
        ...r
    }, o = Pa(i, n);
    for (let [s, a] of Object.entries(o)){
        if (Re(a)) continue;
        zi(a, t.nestSelection(s));
        let l = t.findField(s);
        n?.[s] && !l || (e[s] = !a);
    }
}
function nm(e, r) {
    let t = {}, n = r.getComputedFields(), i = va(e, n);
    for (let [o, s] of Object.entries(i)){
        if (Re(s)) continue;
        let a = r.nestSelection(o);
        zi(s, a);
        let l = r.findField(o);
        if (!(n?.[o] && !l)) {
            if (s === !1 || s === void 0 || Re(s)) {
                t[o] = !1;
                continue;
            }
            if (s === !0) {
                l?.kind === "object" ? t[o] = bt({}, a) : t[o] = !0;
                continue;
            }
            t[o] = bt(s, a);
        }
    }
    return t;
}
function Aa(e, r) {
    if (e === null) return null;
    if (typeof e == "string" || typeof e == "number" || typeof e == "boolean") return e;
    if (typeof e == "bigint") return {
        $type: "BigInt",
        value: String(e)
    };
    if (Sr(e)) {
        if (gn(e)) return {
            $type: "DateTime",
            value: e.toISOString()
        };
        r.throwValidationError({
            kind: "InvalidArgumentValue",
            selectionPath: r.getSelectionPath(),
            argumentPath: r.getArgumentPath(),
            argument: {
                name: r.getArgumentName(),
                typeNames: [
                    "Date"
                ]
            },
            underlyingError: "Provided Date object is invalid"
        });
    }
    if (Ta(e)) return {
        $type: "Param",
        value: e.name
    };
    if (Dr(e)) return {
        $type: "FieldRef",
        value: {
            _ref: e.name,
            _container: e.modelName
        }
    };
    if (Array.isArray(e)) return im(e, r);
    if (ArrayBuffer.isView(e)) {
        let { buffer: t, byteOffset: n, byteLength: i } = e;
        return {
            $type: "Bytes",
            value: Buffer.from(t, n, i).toString("base64")
        };
    }
    if (om(e)) return e.values;
    if (Rr(e)) return {
        $type: "Decimal",
        value: e.toFixed()
    };
    if (e instanceof Le) {
        if (e !== Sn.instances[e._getName()]) throw new Error("Invalid ObjectEnumValue");
        return {
            $type: "Enum",
            value: e._getName()
        };
    }
    if (sm(e)) return e.toJSON();
    if (typeof e == "object") return Ia(e, r);
    r.throwValidationError({
        kind: "InvalidArgumentValue",
        selectionPath: r.getSelectionPath(),
        argumentPath: r.getArgumentPath(),
        argument: {
            name: r.getArgumentName(),
            typeNames: []
        },
        underlyingError: `We could not serialize ${Object.prototype.toString.call(e)} value. Serialize the object to JSON or implement a ".toJSON()" method on it`
    });
}
function Ia(e, r) {
    if (e.$type) return {
        $type: "Raw",
        value: e
    };
    let t = {};
    for(let n in e){
        let i = e[n], o = r.nestArgument(n);
        Re(i) || (i !== void 0 ? t[n] = Aa(i, o) : r.isPreviewFeatureOn("strictUndefinedChecks") && r.throwValidationError({
            kind: "InvalidArgumentValue",
            argumentPath: o.getArgumentPath(),
            selectionPath: r.getSelectionPath(),
            argument: {
                name: r.getArgumentName(),
                typeNames: []
            },
            underlyingError: Ca
        }));
    }
    return t;
}
function im(e, r) {
    let t = [];
    for(let n = 0; n < e.length; n++){
        let i = r.nestArgument(String(n)), o = e[n];
        if (o === void 0 || Re(o)) {
            let s = o === void 0 ? "undefined" : "Prisma.skip";
            r.throwValidationError({
                kind: "InvalidArgumentValue",
                selectionPath: i.getSelectionPath(),
                argumentPath: i.getArgumentPath(),
                argument: {
                    name: `${r.getArgumentName()}[${n}]`,
                    typeNames: []
                },
                underlyingError: `Can not use \`${s}\` value within array. Use \`null\` or filter out \`${s}\` values`
            });
        }
        t.push(Aa(o, i));
    }
    return t;
}
function om(e) {
    return typeof e == "object" && e !== null && e.__prismaRawParameters__ === !0;
}
function sm(e) {
    return typeof e == "object" && e !== null && typeof e.toJSON == "function";
}
function zi(e, r) {
    e === void 0 && r.isPreviewFeatureOn("strictUndefinedChecks") && r.throwValidationError({
        kind: "InvalidSelectionValue",
        selectionPath: r.getSelectionPath(),
        underlyingError: Ca
    });
}
var Yi = class e {
    constructor(r){
        this.params = r;
        this.params.modelName && (this.modelOrType = this.params.runtimeDataModel.models[this.params.modelName] ?? this.params.runtimeDataModel.types[this.params.modelName]);
    }
    modelOrType;
    throwValidationError(r) {
        An({
            errors: [
                r
            ],
            originalMethod: this.params.originalMethod,
            args: this.params.rootArgs ?? {},
            callsite: this.params.callsite,
            errorFormat: this.params.errorFormat,
            clientVersion: this.params.clientVersion,
            globalOmit: this.params.globalOmit
        });
    }
    getSelectionPath() {
        return this.params.selectionPath;
    }
    getArgumentPath() {
        return this.params.argumentPath;
    }
    getArgumentName() {
        return this.params.argumentPath[this.params.argumentPath.length - 1];
    }
    getOutputTypeDescription() {
        if (!(!this.params.modelName || !this.modelOrType)) return {
            name: this.params.modelName,
            fields: this.modelOrType.fields.map((r)=>({
                    name: r.name,
                    typeName: "boolean",
                    isRelation: r.kind === "object"
                }))
        };
    }
    isRawAction() {
        return [
            "executeRaw",
            "queryRaw",
            "runCommandRaw",
            "findRaw",
            "aggregateRaw"
        ].includes(this.params.action);
    }
    isPreviewFeatureOn(r) {
        return this.params.previewFeatures.includes(r);
    }
    getComputedFields() {
        if (this.params.modelName) return this.params.extensions.getAllComputedFields(this.params.modelName);
    }
    findField(r) {
        return this.modelOrType?.fields.find((t)=>t.name === r);
    }
    nestSelection(r) {
        let t = this.findField(r), n = t?.kind === "object" ? t.type : void 0;
        return new e({
            ...this.params,
            modelName: n,
            selectionPath: this.params.selectionPath.concat(r)
        });
    }
    getGlobalOmit() {
        return this.params.modelName && this.shouldApplyGlobalOmit() ? this.params.globalOmit?.[Ye(this.params.modelName)] ?? {} : {};
    }
    shouldApplyGlobalOmit() {
        switch(this.params.action){
            case "findFirst":
            case "findFirstOrThrow":
            case "findUniqueOrThrow":
            case "findMany":
            case "upsert":
            case "findUnique":
            case "createManyAndReturn":
            case "create":
            case "update":
            case "updateManyAndReturn":
            case "delete":
                return !0;
            case "executeRaw":
            case "aggregateRaw":
            case "runCommandRaw":
            case "findRaw":
            case "createMany":
            case "deleteMany":
            case "groupBy":
            case "updateMany":
            case "count":
            case "aggregate":
            case "queryRaw":
                return !1;
            default:
                _e(this.params.action, "Unknown action");
        }
    }
    nestArgument(r) {
        return new e({
            ...this.params,
            argumentPath: this.params.argumentPath.concat(r)
        });
    }
};
function ka(e) {
    if (!e._hasPreviewFlag("metrics")) throw new Z("`metrics` preview feature must be enabled in order to access metrics API", {
        clientVersion: e._clientVersion
    });
}
var Fr = class {
    _client;
    constructor(r){
        this._client = r;
    }
    prometheus(r) {
        return ka(this._client), this._client._engine.metrics({
            format: "prometheus",
            ...r
        });
    }
    json(r) {
        return ka(this._client), this._client._engine.metrics({
            format: "json",
            ...r
        });
    }
};
function Oa(e, r) {
    let t = at(()=>am(r));
    Object.defineProperty(e, "dmmf", {
        get: ()=>t.get()
    });
}
function am(e) {
    return {
        datamodel: {
            models: Zi(e.models),
            enums: Zi(e.enums),
            types: Zi(e.types)
        }
    };
}
function Zi(e) {
    return Object.entries(e).map(([r, t])=>({
            name: r,
            ...t
        }));
}
var Xi = new WeakMap, _n = "$$PrismaTypedSql", Et = class {
    constructor(r, t){
        Xi.set(this, {
            sql: r,
            values: t
        }), Object.defineProperty(this, _n, {
            value: _n
        });
    }
    get sql() {
        return Xi.get(this).sql;
    }
    get values() {
        return Xi.get(this).values;
    }
};
function Da(e) {
    return (...r)=>new Et(e, r);
}
function Nn(e) {
    return e != null && e[_n] === _n;
}
var cu = k(Ei());
var pu = __turbopack_context__.r("[externals]/node:async_hooks [external] (node:async_hooks, cjs)"), du = __turbopack_context__.r("[externals]/node:events [external] (node:events, cjs)"), mu = k(__turbopack_context__.r("[externals]/node:fs [external] (node:fs, cjs)")), Zn = k(__turbopack_context__.r("[externals]/node:path [external] (node:path, cjs)"));
var oe = class e {
    constructor(r, t){
        if (r.length - 1 !== t.length) throw r.length === 0 ? new TypeError("Expected at least 1 string") : new TypeError(`Expected ${r.length} strings to have ${r.length - 1} values`);
        let n = t.reduce((s, a)=>s + (a instanceof e ? a.values.length : 1), 0);
        this.values = new Array(n), this.strings = new Array(n + 1), this.strings[0] = r[0];
        let i = 0, o = 0;
        for(; i < t.length;){
            let s = t[i++], a = r[i];
            if (s instanceof e) {
                this.strings[o] += s.strings[0];
                let l = 0;
                for(; l < s.values.length;)this.values[o++] = s.values[l++], this.strings[o] = s.strings[l];
                this.strings[o] += a;
            } else this.values[o++] = s, this.strings[o] = a;
        }
    }
    get sql() {
        let r = this.strings.length, t = 1, n = this.strings[0];
        for(; t < r;)n += `?${this.strings[t++]}`;
        return n;
    }
    get statement() {
        let r = this.strings.length, t = 1, n = this.strings[0];
        for(; t < r;)n += `:${t}${this.strings[t++]}`;
        return n;
    }
    get text() {
        let r = this.strings.length, t = 1, n = this.strings[0];
        for(; t < r;)n += `$${t}${this.strings[t++]}`;
        return n;
    }
    inspect() {
        return {
            sql: this.sql,
            statement: this.statement,
            text: this.text,
            values: this.values
        };
    }
};
function _a(e, r = ",", t = "", n = "") {
    if (e.length === 0) throw new TypeError("Expected `join([])` to be called with an array of multiple elements, but got an empty array");
    return new oe([
        t,
        ...Array(e.length - 1).fill(r),
        n
    ], e);
}
function eo(e) {
    return new oe([
        e
    ], []);
}
var Na = eo("");
function ro(e, ...r) {
    return new oe(e, r);
}
function wt(e) {
    return {
        getKeys () {
            return Object.keys(e);
        },
        getPropertyValue (r) {
            return e[r];
        }
    };
}
function re(e, r) {
    return {
        getKeys () {
            return [
                e
            ];
        },
        getPropertyValue () {
            return r();
        }
    };
}
function ar(e) {
    let r = new Pe;
    return {
        getKeys () {
            return e.getKeys();
        },
        getPropertyValue (t) {
            return r.getOrCreate(t, ()=>e.getPropertyValue(t));
        },
        getPropertyDescriptor (t) {
            return e.getPropertyDescriptor?.(t);
        }
    };
}
var Fn = {
    enumerable: !0,
    configurable: !0,
    writable: !0
};
function Ln(e) {
    let r = new Set(e);
    return {
        getPrototypeOf: ()=>Object.prototype,
        getOwnPropertyDescriptor: ()=>Fn,
        has: (t, n)=>r.has(n),
        set: (t, n, i)=>r.add(n) && Reflect.set(t, n, i),
        ownKeys: ()=>[
                ...r
            ]
    };
}
var Fa = Symbol.for("nodejs.util.inspect.custom");
function he(e, r) {
    let t = lm(r), n = new Set, i = new Proxy(e, {
        get (o, s) {
            if (n.has(s)) return o[s];
            let a = t.get(s);
            return a ? a.getPropertyValue(s) : o[s];
        },
        has (o, s) {
            if (n.has(s)) return !0;
            let a = t.get(s);
            return a ? a.has?.(s) ?? !0 : Reflect.has(o, s);
        },
        ownKeys (o) {
            let s = La(Reflect.ownKeys(o), t), a = La(Array.from(t.keys()), t);
            return [
                ...new Set([
                    ...s,
                    ...a,
                    ...n
                ])
            ];
        },
        set (o, s, a) {
            return t.get(s)?.getPropertyDescriptor?.(s)?.writable === !1 ? !1 : (n.add(s), Reflect.set(o, s, a));
        },
        getOwnPropertyDescriptor (o, s) {
            let a = Reflect.getOwnPropertyDescriptor(o, s);
            if (a && !a.configurable) return a;
            let l = t.get(s);
            return l ? l.getPropertyDescriptor ? {
                ...Fn,
                ...l?.getPropertyDescriptor(s)
            } : Fn : a;
        },
        defineProperty (o, s, a) {
            return n.add(s), Reflect.defineProperty(o, s, a);
        },
        getPrototypeOf: ()=>Object.prototype
    });
    return i[Fa] = function() {
        let o = {
            ...this
        };
        return delete o[Fa], o;
    }, i;
}
function lm(e) {
    let r = new Map;
    for (let t of e){
        let n = t.getKeys();
        for (let i of n)r.set(i, t);
    }
    return r;
}
function La(e, r) {
    return e.filter((t)=>r.get(t)?.has?.(t) ?? !0);
}
function Lr(e) {
    return {
        getKeys () {
            return e;
        },
        has () {
            return !1;
        },
        getPropertyValue () {}
    };
}
function Mr(e, r) {
    return {
        batch: e,
        transaction: r?.kind === "batch" ? {
            isolationLevel: r.options.isolationLevel
        } : void 0
    };
}
function Ma(e) {
    if (e === void 0) return "";
    let r = _r(e);
    return new Ar(0, {
        colors: vn
    }).write(r).toString();
}
var um = "P2037";
function $r({ error: e, user_facing_error: r }, t, n) {
    return r.error_code ? new z(cm(r, n), {
        code: r.error_code,
        clientVersion: t,
        meta: r.meta,
        batchRequestIdx: r.batch_request_idx
    }) : new j(e, {
        clientVersion: t,
        batchRequestIdx: r.batch_request_idx
    });
}
function cm(e, r) {
    let t = e.message;
    return (r === "postgresql" || r === "postgres" || r === "mysql") && e.error_code === um && (t += `
Prisma Accelerate has built-in connection pooling to prevent such errors: https://pris.ly/client/error-accelerate`), t;
}
var xt = "<unknown>";
function $a(e) {
    var r = e.split(`
`);
    return r.reduce(function(t, n) {
        var i = mm(n) || gm(n) || bm(n) || vm(n) || wm(n);
        return i && t.push(i), t;
    }, []);
}
var pm = /^\s*at (.*?) ?\(((?:file|https?|blob|chrome-extension|native|eval|webpack|rsc|<anonymous>|\/|[a-z]:\\|\\\\).*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i, dm = /\((\S*)(?::(\d+))(?::(\d+))\)/;
function mm(e) {
    var r = pm.exec(e);
    if (!r) return null;
    var t = r[2] && r[2].indexOf("native") === 0, n = r[2] && r[2].indexOf("eval") === 0, i = dm.exec(r[2]);
    return n && i != null && (r[2] = i[1], r[3] = i[2], r[4] = i[3]), {
        file: t ? null : r[2],
        methodName: r[1] || xt,
        arguments: t ? [
            r[2]
        ] : [],
        lineNumber: r[3] ? +r[3] : null,
        column: r[4] ? +r[4] : null
    };
}
var fm = /^\s*at (?:((?:\[object object\])?.+) )?\(?((?:file|ms-appx|https?|webpack|rsc|blob):.*?):(\d+)(?::(\d+))?\)?\s*$/i;
function gm(e) {
    var r = fm.exec(e);
    return r ? {
        file: r[2],
        methodName: r[1] || xt,
        arguments: [],
        lineNumber: +r[3],
        column: r[4] ? +r[4] : null
    } : null;
}
var hm = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)((?:file|https?|blob|chrome|webpack|rsc|resource|\[native).*?|[^@]*bundle)(?::(\d+))?(?::(\d+))?\s*$/i, ym = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i;
function bm(e) {
    var r = hm.exec(e);
    if (!r) return null;
    var t = r[3] && r[3].indexOf(" > eval") > -1, n = ym.exec(r[3]);
    return t && n != null && (r[3] = n[1], r[4] = n[2], r[5] = null), {
        file: r[3],
        methodName: r[1] || xt,
        arguments: r[2] ? r[2].split(",") : [],
        lineNumber: r[4] ? +r[4] : null,
        column: r[5] ? +r[5] : null
    };
}
var Em = /^\s*(?:([^@]*)(?:\((.*?)\))?@)?(\S.*?):(\d+)(?::(\d+))?\s*$/i;
function wm(e) {
    var r = Em.exec(e);
    return r ? {
        file: r[3],
        methodName: r[1] || xt,
        arguments: [],
        lineNumber: +r[4],
        column: r[5] ? +r[5] : null
    } : null;
}
var xm = /^\s*at (?:((?:\[object object\])?[^\\/]+(?: \[as \S+\])?) )?\(?(.*?):(\d+)(?::(\d+))?\)?\s*$/i;
function vm(e) {
    var r = xm.exec(e);
    return r ? {
        file: r[2],
        methodName: r[1] || xt,
        arguments: [],
        lineNumber: +r[3],
        column: r[4] ? +r[4] : null
    } : null;
}
var to = class {
    getLocation() {
        return null;
    }
}, no = class {
    _error;
    constructor(){
        this._error = new Error;
    }
    getLocation() {
        let r = this._error.stack;
        if (!r) return null;
        let n = $a(r).find((i)=>{
            if (!i.file) return !1;
            let o = Oi(i.file);
            return o !== "<anonymous>" && !o.includes("@prisma") && !o.includes("/packages/client/src/runtime/") && !o.endsWith("/runtime/binary.js") && !o.endsWith("/runtime/library.js") && !o.endsWith("/runtime/edge.js") && !o.endsWith("/runtime/edge-esm.js") && !o.startsWith("internal/") && !i.methodName.includes("new ") && !i.methodName.includes("getCallSite") && !i.methodName.includes("Proxy.") && i.methodName.split(".").length < 4;
        });
        return !n || !n.file ? null : {
            fileName: n.file,
            lineNumber: n.lineNumber,
            columnNumber: n.column
        };
    }
};
function Ze(e) {
    return e === "minimal" ? typeof $EnabledCallSite == "function" && e !== "minimal" ? new $EnabledCallSite : new to : new no;
}
var qa = {
    _avg: !0,
    _count: !0,
    _sum: !0,
    _min: !0,
    _max: !0
};
function qr(e = {}) {
    let r = Tm(e);
    return Object.entries(r).reduce((n, [i, o])=>(qa[i] !== void 0 ? n.select[i] = {
            select: o
        } : n[i] = o, n), {
        select: {}
    });
}
function Tm(e = {}) {
    return typeof e._count == "boolean" ? {
        ...e,
        _count: {
            _all: e._count
        }
    } : e;
}
function Mn(e = {}) {
    return (r)=>(typeof e._count == "boolean" && (r._count = r._count._all), r);
}
function ja(e, r) {
    let t = Mn(e);
    return r({
        action: "aggregate",
        unpacker: t,
        argsMapper: qr
    })(e);
}
function Sm(e = {}) {
    let { select: r, ...t } = e;
    return typeof r == "object" ? qr({
        ...t,
        _count: r
    }) : qr({
        ...t,
        _count: {
            _all: !0
        }
    });
}
function Rm(e = {}) {
    return typeof e.select == "object" ? (r)=>Mn(e)(r)._count : (r)=>Mn(e)(r)._count._all;
}
function Va(e, r) {
    return r({
        action: "count",
        unpacker: Rm(e),
        argsMapper: Sm
    })(e);
}
function Cm(e = {}) {
    let r = qr(e);
    if (Array.isArray(r.by)) for (let t of r.by)typeof t == "string" && (r.select[t] = !0);
    else typeof r.by == "string" && (r.select[r.by] = !0);
    return r;
}
function Am(e = {}) {
    return (r)=>(typeof e?._count == "boolean" && r.forEach((t)=>{
            t._count = t._count._all;
        }), r);
}
function Ba(e, r) {
    return r({
        action: "groupBy",
        unpacker: Am(e),
        argsMapper: Cm
    })(e);
}
function Ua(e, r, t) {
    if (r === "aggregate") return (n)=>ja(n, t);
    if (r === "count") return (n)=>Va(n, t);
    if (r === "groupBy") return (n)=>Ba(n, t);
}
function Qa(e, r) {
    let t = r.fields.filter((i)=>!i.relationName), n = Ys(t, "name");
    return new Proxy({}, {
        get (i, o) {
            if (o in i || typeof o == "symbol") return i[o];
            let s = n[o];
            if (s) return new dt(e, o, s.type, s.isList, s.kind === "enum");
        },
        ...Ln(Object.keys(n))
    });
}
var Ga = (e)=>Array.isArray(e) ? e : e.split("."), io = (e, r)=>Ga(r).reduce((t, n)=>t && t[n], e), Wa = (e, r, t)=>Ga(r).reduceRight((n, i, o, s)=>Object.assign({}, io(e, s.slice(0, o)), {
            [i]: n
        }), t);
function Im(e, r) {
    return e === void 0 || r === void 0 ? [] : [
        ...r,
        "select",
        e
    ];
}
function km(e, r, t) {
    return r === void 0 ? e ?? {} : Wa(r, t, e || !0);
}
function oo(e, r, t, n, i, o) {
    let a = e._runtimeDataModel.models[r].fields.reduce((l, u)=>({
            ...l,
            [u.name]: u
        }), {});
    return (l)=>{
        let u = Ze(e._errorFormat), c = Im(n, i), p = km(l, o, c), d = t({
            dataPath: c,
            callsite: u
        })(p), f = Om(e, r);
        return new Proxy(d, {
            get (g, h) {
                if (!f.includes(h)) return g[h];
                let P = [
                    a[h].type,
                    t,
                    h
                ], S = [
                    c,
                    p
                ];
                return oo(e, ...P, ...S);
            },
            ...Ln([
                ...f,
                ...Object.getOwnPropertyNames(d)
            ])
        });
    };
}
function Om(e, r) {
    return e._runtimeDataModel.models[r].fields.filter((t)=>t.kind === "object").map((t)=>t.name);
}
var Dm = [
    "findUnique",
    "findUniqueOrThrow",
    "findFirst",
    "findFirstOrThrow",
    "create",
    "update",
    "upsert",
    "delete"
], _m = [
    "aggregate",
    "count",
    "groupBy"
];
function so(e, r) {
    let t = e._extensions.getAllModelExtensions(r) ?? {}, n = [
        Nm(e, r),
        Lm(e, r),
        wt(t),
        re("name", ()=>r),
        re("$name", ()=>r),
        re("$parent", ()=>e._appliedParent)
    ];
    return he({}, n);
}
function Nm(e, r) {
    let t = Se(r), n = Object.keys(Cr).concat("count");
    return {
        getKeys () {
            return n;
        },
        getPropertyValue (i) {
            let o = i, s = (a)=>(l)=>{
                    let u = Ze(e._errorFormat);
                    return e._createPrismaPromise((c)=>{
                        let p = {
                            args: l,
                            dataPath: [],
                            action: o,
                            model: r,
                            clientMethod: `${t}.${i}`,
                            jsModelName: t,
                            transaction: c,
                            callsite: u
                        };
                        return e._request({
                            ...p,
                            ...a
                        });
                    }, {
                        action: o,
                        args: l,
                        model: r
                    });
                };
            return Dm.includes(o) ? oo(e, r, s) : Fm(i) ? Ua(e, i, s) : s({});
        }
    };
}
function Fm(e) {
    return _m.includes(e);
}
function Lm(e, r) {
    return ar(re("fields", ()=>{
        let t = e._runtimeDataModel.models[r];
        return Qa(r, t);
    }));
}
function Ja(e) {
    return e.replace(/^./, (r)=>r.toUpperCase());
}
var ao = Symbol();
function vt(e) {
    let r = [
        Mm(e),
        $m(e),
        re(ao, ()=>e),
        re("$parent", ()=>e._appliedParent)
    ], t = e._extensions.getAllClientExtensions();
    return t && r.push(wt(t)), he(e, r);
}
function Mm(e) {
    let r = Object.getPrototypeOf(e._originalClient), t = [
        ...new Set(Object.getOwnPropertyNames(r))
    ];
    return {
        getKeys () {
            return t;
        },
        getPropertyValue (n) {
            return e[n];
        }
    };
}
function $m(e) {
    let r = Object.keys(e._runtimeDataModel.models), t = r.map(Se), n = [
        ...new Set(r.concat(t))
    ];
    return ar({
        getKeys () {
            return n;
        },
        getPropertyValue (i) {
            let o = Ja(i);
            if (e._runtimeDataModel.models[o] !== void 0) return so(e, o);
            if (e._runtimeDataModel.models[i] !== void 0) return so(e, i);
        },
        getPropertyDescriptor (i) {
            if (!t.includes(i)) return {
                enumerable: !1
            };
        }
    });
}
function Ha(e) {
    return e[ao] ? e[ao] : e;
}
function Ka(e) {
    if (typeof e == "function") return e(this);
    if (e.client?.__AccelerateEngine) {
        let t = e.client.__AccelerateEngine;
        this._originalClient._engine = new t(this._originalClient._accelerateEngineConfig);
    }
    let r = Object.create(this._originalClient, {
        _extensions: {
            value: this._extensions.append(e)
        },
        _appliedParent: {
            value: this,
            configurable: !0
        },
        $use: {
            value: void 0
        },
        $on: {
            value: void 0
        }
    });
    return vt(r);
}
function Ya({ result: e, modelName: r, select: t, omit: n, extensions: i }) {
    let o = i.getAllComputedFields(r);
    if (!o) return e;
    let s = [], a = [];
    for (let l of Object.values(o)){
        if (n) {
            if (n[l.name]) continue;
            let u = l.needs.filter((c)=>n[c]);
            u.length > 0 && a.push(Lr(u));
        } else if (t) {
            if (!t[l.name]) continue;
            let u = l.needs.filter((c)=>!t[c]);
            u.length > 0 && a.push(Lr(u));
        }
        qm(e, l.needs) && s.push(jm(l, he(e, s)));
    }
    return s.length > 0 || a.length > 0 ? he(e, [
        ...s,
        ...a
    ]) : e;
}
function qm(e, r) {
    return r.every((t)=>Mi(e, t));
}
function jm(e, r) {
    return ar(re(e.name, ()=>e.compute(r)));
}
function $n({ visitor: e, result: r, args: t, runtimeDataModel: n, modelName: i }) {
    if (Array.isArray(r)) {
        for(let s = 0; s < r.length; s++)r[s] = $n({
            result: r[s],
            args: t,
            modelName: i,
            runtimeDataModel: n,
            visitor: e
        });
        return r;
    }
    let o = e(r, i, t) ?? r;
    return t.include && za({
        includeOrSelect: t.include,
        result: o,
        parentModelName: i,
        runtimeDataModel: n,
        visitor: e
    }), t.select && za({
        includeOrSelect: t.select,
        result: o,
        parentModelName: i,
        runtimeDataModel: n,
        visitor: e
    }), o;
}
function za({ includeOrSelect: e, result: r, parentModelName: t, runtimeDataModel: n, visitor: i }) {
    for (let [o, s] of Object.entries(e)){
        if (!s || r[o] == null || Re(s)) continue;
        let l = n.models[t].fields.find((c)=>c.name === o);
        if (!l || l.kind !== "object" || !l.relationName) continue;
        let u = typeof s == "object" ? s : {};
        r[o] = $n({
            visitor: i,
            result: r[o],
            args: u,
            modelName: l.type,
            runtimeDataModel: n
        });
    }
}
function Za({ result: e, modelName: r, args: t, extensions: n, runtimeDataModel: i, globalOmit: o }) {
    return n.isEmpty() || e == null || typeof e != "object" || !i.models[r] ? e : $n({
        result: e,
        args: t ?? {},
        modelName: r,
        runtimeDataModel: i,
        visitor: (a, l, u)=>{
            let c = Se(l);
            return Ya({
                result: a,
                modelName: c,
                select: u.select,
                omit: u.select ? void 0 : {
                    ...o?.[c],
                    ...u.omit
                },
                extensions: n
            });
        }
    });
}
var Vm = [
    "$connect",
    "$disconnect",
    "$on",
    "$transaction",
    "$use",
    "$extends"
], Xa = Vm;
function el(e) {
    if (e instanceof oe) return Bm(e);
    if (Nn(e)) return Um(e);
    if (Array.isArray(e)) {
        let t = [
            e[0]
        ];
        for(let n = 1; n < e.length; n++)t[n] = Pt(e[n]);
        return t;
    }
    let r = {};
    for(let t in e)r[t] = Pt(e[t]);
    return r;
}
function Bm(e) {
    return new oe(e.strings, e.values);
}
function Um(e) {
    return new Et(e.sql, e.values);
}
function Pt(e) {
    if (typeof e != "object" || e == null || e instanceof Le || Dr(e)) return e;
    if (Rr(e)) return new ve(e.toFixed());
    if (Sr(e)) return new Date(+e);
    if (ArrayBuffer.isView(e)) return e.slice(0);
    if (Array.isArray(e)) {
        let r = e.length, t;
        for(t = Array(r); r--;)t[r] = Pt(e[r]);
        return t;
    }
    if (typeof e == "object") {
        let r = {};
        for(let t in e)t === "__proto__" ? Object.defineProperty(r, t, {
            value: Pt(e[t]),
            configurable: !0,
            enumerable: !0,
            writable: !0
        }) : r[t] = Pt(e[t]);
        return r;
    }
    _e(e, "Unknown value");
}
function tl(e, r, t, n = 0) {
    return e._createPrismaPromise((i)=>{
        let o = r.customDataProxyFetch;
        return "transaction" in r && i !== void 0 && (r.transaction?.kind === "batch" && r.transaction.lock.then(), r.transaction = i), n === t.length ? e._executeRequest(r) : t[n]({
            model: r.model,
            operation: r.model ? r.action : r.clientMethod,
            args: el(r.args ?? {}),
            __internalParams: r,
            query: (s, a = r)=>{
                let l = a.customDataProxyFetch;
                return a.customDataProxyFetch = sl(o, l), a.args = s, tl(e, a, t, n + 1);
            }
        });
    });
}
function nl(e, r) {
    let { jsModelName: t, action: n, clientMethod: i } = r, o = t ? n : i;
    if (e._extensions.isEmpty()) return e._executeRequest(r);
    let s = e._extensions.getAllQueryCallbacks(t ?? "$none", o);
    return tl(e, r, s);
}
function il(e) {
    return (r)=>{
        let t = {
            requests: r
        }, n = r[0].extensions.getAllBatchQueryCallbacks();
        return n.length ? ol(t, n, 0, e) : e(t);
    };
}
function ol(e, r, t, n) {
    if (t === r.length) return n(e);
    let i = e.customDataProxyFetch, o = e.requests[0].transaction;
    return r[t]({
        args: {
            queries: e.requests.map((s)=>({
                    model: s.modelName,
                    operation: s.action,
                    args: s.args
                })),
            transaction: o ? {
                isolationLevel: o.kind === "batch" ? o.isolationLevel : void 0
            } : void 0
        },
        __internalParams: e,
        query (s, a = e) {
            let l = a.customDataProxyFetch;
            return a.customDataProxyFetch = sl(i, l), ol(a, r, t + 1, n);
        }
    });
}
var rl = (e)=>e;
function sl(e = rl, r = rl) {
    return (t)=>e(r(t));
}
var al = N("prisma:client"), ll = {
    Vercel: "vercel",
    "Netlify CI": "netlify"
};
function ul({ postinstall: e, ciName: r, clientVersion: t }) {
    if (al("checkPlatformCaching:postinstall", e), al("checkPlatformCaching:ciName", r), e === !0 && r && r in ll) {
        let n = `Prisma has detected that this project was built on ${r}, which caches dependencies. This leads to an outdated Prisma Client because Prisma's auto-generation isn't triggered. To fix this, make sure to run the \`prisma generate\` command during the build process.

Learn how: https://pris.ly/d/${ll[r]}-build`;
        throw console.error(n), new T(n, t);
    }
}
function cl(e, r) {
    return e ? e.datasources ? e.datasources : e.datasourceUrl ? {
        [r[0]]: {
            url: e.datasourceUrl
        }
    } : {} : {};
}
var Qm = ()=>globalThis.process?.release?.name === "node", Gm = ()=>!!globalThis.Bun || !!globalThis.process?.versions?.bun, Wm = ()=>!!globalThis.Deno, Jm = ()=>typeof globalThis.Netlify == "object", Hm = ()=>typeof globalThis.EdgeRuntime == "object", Km = ()=>globalThis.navigator?.userAgent === "Cloudflare-Workers";
function Ym() {
    return [
        [
            Jm,
            "netlify"
        ],
        [
            Hm,
            "edge-light"
        ],
        [
            Km,
            "workerd"
        ],
        [
            Wm,
            "deno"
        ],
        [
            Gm,
            "bun"
        ],
        [
            Qm,
            "node"
        ]
    ].flatMap((t)=>t[0]() ? [
            t[1]
        ] : []).at(0) ?? "";
}
var zm = {
    node: "Node.js",
    workerd: "Cloudflare Workers",
    deno: "Deno and Deno Deploy",
    netlify: "Netlify Edge Functions",
    "edge-light": "Edge Runtime (Vercel Edge Functions, Vercel Edge Middleware, Next.js (Pages Router) Edge API Routes, Next.js (App Router) Edge Route Handlers or Next.js Middleware)"
};
function qn() {
    let e = Ym();
    return {
        id: e,
        prettyName: zm[e] || e,
        isEdge: [
            "workerd",
            "deno",
            "netlify",
            "edge-light"
        ].includes(e)
    };
}
var gl = k(__turbopack_context__.r("[externals]/node:fs [external] (node:fs, cjs)")), Tt = k(__turbopack_context__.r("[externals]/node:path [external] (node:path, cjs)"));
function jn(e) {
    let { runtimeBinaryTarget: r } = e;
    return `Add "${r}" to \`binaryTargets\` in the "schema.prisma" file and run \`prisma generate\` after saving it:

${Zm(e)}`;
}
function Zm(e) {
    let { generator: r, generatorBinaryTargets: t, runtimeBinaryTarget: n } = e, i = {
        fromEnvVar: null,
        value: n
    }, o = [
        ...t,
        i
    ];
    return Ai({
        ...r,
        binaryTargets: o
    });
}
function Xe(e) {
    let { runtimeBinaryTarget: r } = e;
    return `Prisma Client could not locate the Query Engine for runtime "${r}".`;
}
function er(e) {
    let { searchedLocations: r } = e;
    return `The following locations have been searched:
${[
        ...new Set(r)
    ].map((i)=>`  ${i}`).join(`
`)}`;
}
function pl(e) {
    let { runtimeBinaryTarget: r } = e;
    return `${Xe(e)}

This happened because \`binaryTargets\` have been pinned, but the actual deployment also required "${r}".
${jn(e)}

${er(e)}`;
}
function Vn(e) {
    return `We would appreciate if you could take the time to share some information with us.
Please help us by answering a few questions: https://pris.ly/${e}`;
}
function Bn(e) {
    let { errorStack: r } = e;
    return r?.match(/\/\.next|\/next@|\/next\//) ? `

We detected that you are using Next.js, learn how to fix this: https://pris.ly/d/engine-not-found-nextjs.` : "";
}
function dl(e) {
    let { queryEngineName: r } = e;
    return `${Xe(e)}${Bn(e)}

This is likely caused by a bundler that has not copied "${r}" next to the resulting bundle.
Ensure that "${r}" has been copied next to the bundle or in "${e.expectedLocation}".

${Vn("engine-not-found-bundler-investigation")}

${er(e)}`;
}
function ml(e) {
    let { runtimeBinaryTarget: r, generatorBinaryTargets: t } = e, n = t.find((i)=>i.native);
    return `${Xe(e)}

This happened because Prisma Client was generated for "${n?.value ?? "unknown"}", but the actual deployment required "${r}".
${jn(e)}

${er(e)}`;
}
function fl(e) {
    let { queryEngineName: r } = e;
    return `${Xe(e)}${Bn(e)}

This is likely caused by tooling that has not copied "${r}" to the deployment folder.
Ensure that you ran \`prisma generate\` and that "${r}" has been copied to "${e.expectedLocation}".

${Vn("engine-not-found-tooling-investigation")}

${er(e)}`;
}
var Xm = N("prisma:client:engines:resolveEnginePath"), ef = ()=>new RegExp("runtime[\\\\/]library\\.m?js$");
async function hl(e, r) {
    let t = {
        binary: process.env.PRISMA_QUERY_ENGINE_BINARY,
        library: process.env.PRISMA_QUERY_ENGINE_LIBRARY
    }[e] ?? r.prismaPath;
    if (t !== void 0) return t;
    let { enginePath: n, searchedLocations: i } = await rf(e, r);
    if (Xm("enginePath", n), n !== void 0 && e === "binary" && vi(n), n !== void 0) return r.prismaPath = n;
    let o = await ir(), s = r.generator?.binaryTargets ?? [], a = s.some((d)=>d.native), l = !s.some((d)=>d.value === o), u = __filename.match(ef()) === null, c = {
        searchedLocations: i,
        generatorBinaryTargets: s,
        generator: r.generator,
        runtimeBinaryTarget: o,
        queryEngineName: yl(e, o),
        expectedLocation: Tt.default.relative(process.cwd(), r.dirname),
        errorStack: new Error().stack
    }, p;
    throw a && l ? p = ml(c) : l ? p = pl(c) : u ? p = dl(c) : p = fl(c), new T(p, r.clientVersion);
}
async function rf(e, r) {
    let t = await ir(), n = [], i = [
        r.dirname,
        Tt.default.resolve(__dirname, ".."),
        r.generator?.output?.value ?? __dirname,
        Tt.default.resolve(__dirname, "../../../.prisma/client"),
        "/tmp/prisma-engines",
        r.cwd
    ];
    __filename.includes("resolveEnginePath") && i.push(fs());
    for (let o of i){
        let s = yl(e, t), a = Tt.default.join(o, s);
        if (n.push(o), gl.default.existsSync(a)) return {
            enginePath: a,
            searchedLocations: n
        };
    }
    return {
        enginePath: void 0,
        searchedLocations: n
    };
}
function yl(e, r) {
    return e === "library" ? Bt(r, "fs") : `query-engine-${r}${r === "windows" ? ".exe" : ""}`;
}
var lo = k(ki());
function bl(e) {
    return e ? e.replace(/".*"/g, '"X"').replace(/[\s:\[]([+-]?([0-9]*[.])?[0-9]+)/g, (r)=>`${r[0]}5`) : "";
}
function El(e) {
    return e.split(`
`).map((r)=>r.replace(/^\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d\.\d+([+-][0-2]\d:[0-5]\d|Z)\s*/, "").replace(/\+\d+\s*ms$/, "")).join(`
`);
}
var wl = k(Ns());
function xl({ title: e, user: r = "prisma", repo: t = "prisma", template: n = "bug_report.yml", body: i }) {
    return (0, wl.default)({
        user: r,
        repo: t,
        template: n,
        title: e,
        body: i
    });
}
function vl({ version: e, binaryTarget: r, title: t, description: n, engineVersion: i, database: o, query: s }) {
    let a = Qo(6e3 - (s?.length ?? 0)), l = El((0, lo.default)(a)), u = n ? `# Description
\`\`\`
${n}
\`\`\`` : "", c = (0, lo.default)(`Hi Prisma Team! My Prisma Client just crashed. This is the report:
## Versions

| Name            | Version            |
|-----------------|--------------------|
| Node            | ${process.version?.padEnd(19)}| 
| OS              | ${r?.padEnd(19)}|
| Prisma Client   | ${e?.padEnd(19)}|
| Query Engine    | ${i?.padEnd(19)}|
| Database        | ${o?.padEnd(19)}|

${u}

## Logs
\`\`\`
${l}
\`\`\`

## Client Snippet
\`\`\`ts
// PLEASE FILL YOUR CODE SNIPPET HERE
\`\`\`

## Schema
\`\`\`prisma
// PLEASE ADD YOUR SCHEMA HERE IF POSSIBLE
\`\`\`

## Prisma Engine Query
\`\`\`
${s ? bl(s) : ""}
\`\`\`
`), p = xl({
        title: t,
        body: c
    });
    return `${t}

This is a non-recoverable error which probably happens when the Prisma Query Engine has a panic.

${Y(p)}

If you want the Prisma team to look into it, please open the link above \u{1F64F}
To increase the chance of success, please post your schema and a snippet of
how you used Prisma Client in the issue. 
`;
}
function uo(e) {
    return e.name === "DriverAdapterError" && typeof e.cause == "object";
}
function Un(e) {
    return {
        ok: !0,
        value: e,
        map (r) {
            return Un(r(e));
        },
        flatMap (r) {
            return r(e);
        }
    };
}
function lr(e) {
    return {
        ok: !1,
        error: e,
        map () {
            return lr(e);
        },
        flatMap () {
            return lr(e);
        }
    };
}
var Pl = N("driver-adapter-utils"), co = class {
    registeredErrors = [];
    consumeError(r) {
        return this.registeredErrors[r];
    }
    registerNewError(r) {
        let t = 0;
        for(; this.registeredErrors[t] !== void 0;)t++;
        return this.registeredErrors[t] = {
            error: r
        }, t;
    }
};
var po = (e, r = new co)=>{
    let t = {
        adapterName: e.adapterName,
        errorRegistry: r,
        queryRaw: Me(r, e.queryRaw.bind(e)),
        executeRaw: Me(r, e.executeRaw.bind(e)),
        executeScript: Me(r, e.executeScript.bind(e)),
        dispose: Me(r, e.dispose.bind(e)),
        provider: e.provider,
        startTransaction: async (...n)=>(await Me(r, e.startTransaction.bind(e))(...n)).map((o)=>tf(r, o))
    };
    return e.getConnectionInfo && (t.getConnectionInfo = nf(r, e.getConnectionInfo.bind(e))), t;
}, tf = (e, r)=>({
        adapterName: r.adapterName,
        provider: r.provider,
        options: r.options,
        queryRaw: Me(e, r.queryRaw.bind(r)),
        executeRaw: Me(e, r.executeRaw.bind(r)),
        commit: Me(e, r.commit.bind(r)),
        rollback: Me(e, r.rollback.bind(r))
    });
function Me(e, r) {
    return async (...t)=>{
        try {
            return Un(await r(...t));
        } catch (n) {
            if (Pl("[error@wrapAsync]", n), uo(n)) return lr(n.cause);
            let i = e.registerNewError(n);
            return lr({
                kind: "GenericJs",
                id: i
            });
        }
    };
}
function nf(e, r) {
    return (...t)=>{
        try {
            return Un(r(...t));
        } catch (n) {
            if (Pl("[error@wrapSync]", n), uo(n)) return lr(n.cause);
            let i = e.registerNewError(n);
            return lr({
                kind: "GenericJs",
                id: i
            });
        }
    };
}
function jr({ inlineDatasources: e, overrideDatasources: r, env: t, clientVersion: n }) {
    let i, o = Object.keys(e)[0], s = e[o]?.url, a = r[o]?.url;
    if (o === void 0 ? i = void 0 : a ? i = a : s?.value ? i = s.value : s?.fromEnvVar && (i = t[s.fromEnvVar]), s?.fromEnvVar !== void 0 && i === void 0) throw new T(`error: Environment variable not found: ${s.fromEnvVar}.`, n);
    if (i === void 0) throw new T("error: Missing URL environment variable, value, or override.", n);
    return i;
}
var Qn = class extends Error {
    clientVersion;
    cause;
    constructor(r, t){
        super(r), this.clientVersion = t.clientVersion, this.cause = t.cause;
    }
    get [Symbol.toStringTag]() {
        return this.name;
    }
};
var se = class extends Qn {
    isRetryable;
    constructor(r, t){
        super(r, t), this.isRetryable = t.isRetryable ?? !0;
    }
};
function R(e, r) {
    return {
        ...e,
        isRetryable: r
    };
}
var Vr = class extends se {
    name = "ForcedRetryError";
    code = "P5001";
    constructor(r){
        super("This request must be retried", R(r, !0));
    }
};
x(Vr, "ForcedRetryError");
var ur = class extends se {
    name = "InvalidDatasourceError";
    code = "P6001";
    constructor(r, t){
        super(r, R(t, !1));
    }
};
x(ur, "InvalidDatasourceError");
var cr = class extends se {
    name = "NotImplementedYetError";
    code = "P5004";
    constructor(r, t){
        super(r, R(t, !1));
    }
};
x(cr, "NotImplementedYetError");
var $ = class extends se {
    response;
    constructor(r, t){
        super(r, t), this.response = t.response;
        let n = this.response.headers.get("prisma-request-id");
        if (n) {
            let i = `(The request id was: ${n})`;
            this.message = this.message + " " + i;
        }
    }
};
var pr = class extends $ {
    name = "SchemaMissingError";
    code = "P5005";
    constructor(r){
        super("Schema needs to be uploaded", R(r, !0));
    }
};
x(pr, "SchemaMissingError");
var mo = "This request could not be understood by the server", St = class extends $ {
    name = "BadRequestError";
    code = "P5000";
    constructor(r, t, n){
        super(t || mo, R(r, !1)), n && (this.code = n);
    }
};
x(St, "BadRequestError");
var Rt = class extends $ {
    name = "HealthcheckTimeoutError";
    code = "P5013";
    logs;
    constructor(r, t){
        super("Engine not started: healthcheck timeout", R(r, !0)), this.logs = t;
    }
};
x(Rt, "HealthcheckTimeoutError");
var Ct = class extends $ {
    name = "EngineStartupError";
    code = "P5014";
    logs;
    constructor(r, t, n){
        super(t, R(r, !0)), this.logs = n;
    }
};
x(Ct, "EngineStartupError");
var At = class extends $ {
    name = "EngineVersionNotSupportedError";
    code = "P5012";
    constructor(r){
        super("Engine version is not supported", R(r, !1));
    }
};
x(At, "EngineVersionNotSupportedError");
var fo = "Request timed out", It = class extends $ {
    name = "GatewayTimeoutError";
    code = "P5009";
    constructor(r, t = fo){
        super(t, R(r, !1));
    }
};
x(It, "GatewayTimeoutError");
var of = "Interactive transaction error", kt = class extends $ {
    name = "InteractiveTransactionError";
    code = "P5015";
    constructor(r, t = of){
        super(t, R(r, !1));
    }
};
x(kt, "InteractiveTransactionError");
var sf = "Request parameters are invalid", Ot = class extends $ {
    name = "InvalidRequestError";
    code = "P5011";
    constructor(r, t = sf){
        super(t, R(r, !1));
    }
};
x(Ot, "InvalidRequestError");
var go = "Requested resource does not exist", Dt = class extends $ {
    name = "NotFoundError";
    code = "P5003";
    constructor(r, t = go){
        super(t, R(r, !1));
    }
};
x(Dt, "NotFoundError");
var ho = "Unknown server error", Br = class extends $ {
    name = "ServerError";
    code = "P5006";
    logs;
    constructor(r, t, n){
        super(t || ho, R(r, !0)), this.logs = n;
    }
};
x(Br, "ServerError");
var yo = "Unauthorized, check your connection string", _t = class extends $ {
    name = "UnauthorizedError";
    code = "P5007";
    constructor(r, t = yo){
        super(t, R(r, !1));
    }
};
x(_t, "UnauthorizedError");
var bo = "Usage exceeded, retry again later", Nt = class extends $ {
    name = "UsageExceededError";
    code = "P5008";
    constructor(r, t = bo){
        super(t, R(r, !0));
    }
};
x(Nt, "UsageExceededError");
async function af(e) {
    let r;
    try {
        r = await e.text();
    } catch  {
        return {
            type: "EmptyError"
        };
    }
    try {
        let t = JSON.parse(r);
        if (typeof t == "string") switch(t){
            case "InternalDataProxyError":
                return {
                    type: "DataProxyError",
                    body: t
                };
            default:
                return {
                    type: "UnknownTextError",
                    body: t
                };
        }
        if (typeof t == "object" && t !== null) {
            if ("is_panic" in t && "message" in t && "error_code" in t) return {
                type: "QueryEngineError",
                body: t
            };
            if ("EngineNotStarted" in t || "InteractiveTransactionMisrouted" in t || "InvalidRequestError" in t) {
                let n = Object.values(t)[0].reason;
                return typeof n == "string" && ![
                    "SchemaMissing",
                    "EngineVersionNotSupported"
                ].includes(n) ? {
                    type: "UnknownJsonError",
                    body: t
                } : {
                    type: "DataProxyError",
                    body: t
                };
            }
        }
        return {
            type: "UnknownJsonError",
            body: t
        };
    } catch  {
        return r === "" ? {
            type: "EmptyError"
        } : {
            type: "UnknownTextError",
            body: r
        };
    }
}
async function Ft(e, r) {
    if (e.ok) return;
    let t = {
        clientVersion: r,
        response: e
    }, n = await af(e);
    if (n.type === "QueryEngineError") throw new z(n.body.message, {
        code: n.body.error_code,
        clientVersion: r
    });
    if (n.type === "DataProxyError") {
        if (n.body === "InternalDataProxyError") throw new Br(t, "Internal Data Proxy error");
        if ("EngineNotStarted" in n.body) {
            if (n.body.EngineNotStarted.reason === "SchemaMissing") return new pr(t);
            if (n.body.EngineNotStarted.reason === "EngineVersionNotSupported") throw new At(t);
            if ("EngineStartupError" in n.body.EngineNotStarted.reason) {
                let { msg: i, logs: o } = n.body.EngineNotStarted.reason.EngineStartupError;
                throw new Ct(t, i, o);
            }
            if ("KnownEngineStartupError" in n.body.EngineNotStarted.reason) {
                let { msg: i, error_code: o } = n.body.EngineNotStarted.reason.KnownEngineStartupError;
                throw new T(i, r, o);
            }
            if ("HealthcheckTimeout" in n.body.EngineNotStarted.reason) {
                let { logs: i } = n.body.EngineNotStarted.reason.HealthcheckTimeout;
                throw new Rt(t, i);
            }
        }
        if ("InteractiveTransactionMisrouted" in n.body) {
            let i = {
                IDParseError: "Could not parse interactive transaction ID",
                NoQueryEngineFoundError: "Could not find Query Engine for the specified host and transaction ID",
                TransactionStartError: "Could not start interactive transaction"
            };
            throw new kt(t, i[n.body.InteractiveTransactionMisrouted.reason]);
        }
        if ("InvalidRequestError" in n.body) throw new Ot(t, n.body.InvalidRequestError.reason);
    }
    if (e.status === 401 || e.status === 403) throw new _t(t, Ur(yo, n));
    if (e.status === 404) return new Dt(t, Ur(go, n));
    if (e.status === 429) throw new Nt(t, Ur(bo, n));
    if (e.status === 504) throw new It(t, Ur(fo, n));
    if (e.status >= 500) throw new Br(t, Ur(ho, n));
    if (e.status >= 400) throw new St(t, Ur(mo, n));
}
function Ur(e, r) {
    return r.type === "EmptyError" ? e : `${e}: ${JSON.stringify(r)}`;
}
function Tl(e) {
    let r = Math.pow(2, e) * 50, t = Math.ceil(Math.random() * r) - Math.ceil(r / 2), n = r + t;
    return new Promise((i)=>setTimeout(()=>i(n), n));
}
var $e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
function Sl(e) {
    let r = new TextEncoder().encode(e), t = "", n = r.byteLength, i = n % 3, o = n - i, s, a, l, u, c;
    for(let p = 0; p < o; p = p + 3)c = r[p] << 16 | r[p + 1] << 8 | r[p + 2], s = (c & 16515072) >> 18, a = (c & 258048) >> 12, l = (c & 4032) >> 6, u = c & 63, t += $e[s] + $e[a] + $e[l] + $e[u];
    return i == 1 ? (c = r[o], s = (c & 252) >> 2, a = (c & 3) << 4, t += $e[s] + $e[a] + "==") : i == 2 && (c = r[o] << 8 | r[o + 1], s = (c & 64512) >> 10, a = (c & 1008) >> 4, l = (c & 15) << 2, t += $e[s] + $e[a] + $e[l] + "="), t;
}
function Rl(e) {
    if (!!e.generator?.previewFeatures.some((t)=>t.toLowerCase().includes("metrics"))) throw new T("The `metrics` preview feature is not yet available with Accelerate.\nPlease remove `metrics` from the `previewFeatures` in your schema.\n\nMore information about Accelerate: https://pris.ly/d/accelerate", e.clientVersion);
}
function lf(e) {
    return e[0] * 1e3 + e[1] / 1e6;
}
function Eo(e) {
    return new Date(lf(e));
}
var Cl = {
    "@prisma/debug": "workspace:*",
    "@prisma/engines-version": "6.7.0-36.3cff47a7f5d65c3ea74883f1d736e41d68ce91ed",
    "@prisma/fetch-engine": "workspace:*",
    "@prisma/get-platform": "workspace:*"
};
var Lt = class extends se {
    name = "RequestError";
    code = "P5010";
    constructor(r, t){
        super(`Cannot fetch data from service:
${r}`, R(t, !0));
    }
};
x(Lt, "RequestError");
async function dr(e, r, t = (n)=>n) {
    let { clientVersion: n, ...i } = r, o = t(fetch);
    try {
        return await o(e, i);
    } catch (s) {
        let a = s.message ?? "Unknown error";
        throw new Lt(a, {
            clientVersion: n,
            cause: s
        });
    }
}
var cf = /^[1-9][0-9]*\.[0-9]+\.[0-9]+$/, Al = N("prisma:client:dataproxyEngine");
async function pf(e, r) {
    let t = Cl["@prisma/engines-version"], n = r.clientVersion ?? "unknown";
    if (process.env.PRISMA_CLIENT_DATA_PROXY_CLIENT_VERSION) return process.env.PRISMA_CLIENT_DATA_PROXY_CLIENT_VERSION;
    if (e.includes("accelerate") && n !== "0.0.0" && n !== "in-memory") return n;
    let [i, o] = n?.split("-") ?? [];
    if (o === void 0 && cf.test(i)) return i;
    if (o !== void 0 || n === "0.0.0" || n === "in-memory") {
        if (e.startsWith("localhost") || e.startsWith("127.0.0.1")) return "0.0.0";
        let [s] = t.split("-") ?? [], [a, l, u] = s.split("."), c = df(`<=${a}.${l}.${u}`), p = await dr(c, {
            clientVersion: n
        });
        if (!p.ok) throw new Error(`Failed to fetch stable Prisma version, unpkg.com status ${p.status} ${p.statusText}, response body: ${await p.text() || "<empty body>"}`);
        let d = await p.text();
        Al("length of body fetched from unpkg.com", d.length);
        let f;
        try {
            f = JSON.parse(d);
        } catch (g) {
            throw console.error("JSON.parse error: body fetched from unpkg.com: ", d), g;
        }
        return f.version;
    }
    throw new cr("Only `major.minor.patch` versions are supported by Accelerate.", {
        clientVersion: n
    });
}
async function Il(e, r) {
    let t = await pf(e, r);
    return Al("version", t), t;
}
function df(e) {
    return encodeURI(`https://unpkg.com/prisma@${e}/package.json`);
}
var kl = 3, Gn = N("prisma:client:dataproxyEngine"), wo = class {
    apiKey;
    tracingHelper;
    logLevel;
    logQueries;
    engineHash;
    constructor({ apiKey: r, tracingHelper: t, logLevel: n, logQueries: i, engineHash: o }){
        this.apiKey = r, this.tracingHelper = t, this.logLevel = n, this.logQueries = i, this.engineHash = o;
    }
    build({ traceparent: r, interactiveTransaction: t } = {}) {
        let n = {
            Authorization: `Bearer ${this.apiKey}`,
            "Prisma-Engine-Hash": this.engineHash
        };
        this.tracingHelper.isEnabled() && (n.traceparent = r ?? this.tracingHelper.getTraceParent()), t && (n["X-transaction-id"] = t.id);
        let i = this.buildCaptureSettings();
        return i.length > 0 && (n["X-capture-telemetry"] = i.join(", ")), n;
    }
    buildCaptureSettings() {
        let r = [];
        return this.tracingHelper.isEnabled() && r.push("tracing"), this.logLevel && r.push(this.logLevel), this.logQueries && r.push("query"), r;
    }
}, Mt = class {
    name = "DataProxyEngine";
    inlineSchema;
    inlineSchemaHash;
    inlineDatasources;
    config;
    logEmitter;
    env;
    clientVersion;
    engineHash;
    tracingHelper;
    remoteClientVersion;
    host;
    headerBuilder;
    startPromise;
    constructor(r){
        Rl(r), this.config = r, this.env = {
            ...r.env,
            ...typeof process < "u" ? process.env : {}
        }, this.inlineSchema = Sl(r.inlineSchema), this.inlineDatasources = r.inlineDatasources, this.inlineSchemaHash = r.inlineSchemaHash, this.clientVersion = r.clientVersion, this.engineHash = r.engineVersion, this.logEmitter = r.logEmitter, this.tracingHelper = r.tracingHelper;
    }
    apiKey() {
        return this.headerBuilder.apiKey;
    }
    version() {
        return this.engineHash;
    }
    async start() {
        this.startPromise !== void 0 && await this.startPromise, this.startPromise = (async ()=>{
            let [r, t] = this.extractHostAndApiKey();
            this.host = r, this.headerBuilder = new wo({
                apiKey: t,
                tracingHelper: this.tracingHelper,
                logLevel: this.config.logLevel,
                logQueries: this.config.logQueries,
                engineHash: this.engineHash
            }), this.remoteClientVersion = await Il(r, this.config), Gn("host", this.host);
        })(), await this.startPromise;
    }
    async stop() {}
    propagateResponseExtensions(r) {
        r?.logs?.length && r.logs.forEach((t)=>{
            switch(t.level){
                case "debug":
                case "trace":
                    Gn(t);
                    break;
                case "error":
                case "warn":
                case "info":
                    {
                        this.logEmitter.emit(t.level, {
                            timestamp: Eo(t.timestamp),
                            message: t.attributes.message ?? "",
                            target: t.target
                        });
                        break;
                    }
                case "query":
                    {
                        this.logEmitter.emit("query", {
                            query: t.attributes.query ?? "",
                            timestamp: Eo(t.timestamp),
                            duration: t.attributes.duration_ms ?? 0,
                            params: t.attributes.params ?? "",
                            target: t.target
                        });
                        break;
                    }
                default:
                    t.level;
            }
        }), r?.traces?.length && this.tracingHelper.dispatchEngineSpans(r.traces);
    }
    onBeforeExit() {
        throw new Error('"beforeExit" hook is not applicable to the remote query engine');
    }
    async url(r) {
        return await this.start(), `https://${this.host}/${this.remoteClientVersion}/${this.inlineSchemaHash}/${r}`;
    }
    async uploadSchema() {
        let r = {
            name: "schemaUpload",
            internal: !0
        };
        return this.tracingHelper.runInChildSpan(r, async ()=>{
            let t = await dr(await this.url("schema"), {
                method: "PUT",
                headers: this.headerBuilder.build(),
                body: this.inlineSchema,
                clientVersion: this.clientVersion
            });
            t.ok || Gn("schema response status", t.status);
            let n = await Ft(t, this.clientVersion);
            if (n) throw this.logEmitter.emit("warn", {
                message: `Error while uploading schema: ${n.message}`,
                timestamp: new Date,
                target: ""
            }), n;
            this.logEmitter.emit("info", {
                message: `Schema (re)uploaded (hash: ${this.inlineSchemaHash})`,
                timestamp: new Date,
                target: ""
            });
        });
    }
    request(r, { traceparent: t, interactiveTransaction: n, customDataProxyFetch: i }) {
        return this.requestInternal({
            body: r,
            traceparent: t,
            interactiveTransaction: n,
            customDataProxyFetch: i
        });
    }
    async requestBatch(r, { traceparent: t, transaction: n, customDataProxyFetch: i }) {
        let o = n?.kind === "itx" ? n.options : void 0, s = Mr(r, n);
        return (await this.requestInternal({
            body: s,
            customDataProxyFetch: i,
            interactiveTransaction: o,
            traceparent: t
        })).map((l)=>(l.extensions && this.propagateResponseExtensions(l.extensions), "errors" in l ? this.convertProtocolErrorsToClientError(l.errors) : l));
    }
    requestInternal({ body: r, traceparent: t, customDataProxyFetch: n, interactiveTransaction: i }) {
        return this.withRetry({
            actionGerund: "querying",
            callback: async ({ logHttpCall: o })=>{
                let s = i ? `${i.payload.endpoint}/graphql` : await this.url("graphql");
                o(s);
                let a = await dr(s, {
                    method: "POST",
                    headers: this.headerBuilder.build({
                        traceparent: t,
                        interactiveTransaction: i
                    }),
                    body: JSON.stringify(r),
                    clientVersion: this.clientVersion
                }, n);
                a.ok || Gn("graphql response status", a.status), await this.handleError(await Ft(a, this.clientVersion));
                let l = await a.json();
                if (l.extensions && this.propagateResponseExtensions(l.extensions), "errors" in l) throw this.convertProtocolErrorsToClientError(l.errors);
                return "batchResult" in l ? l.batchResult : l;
            }
        });
    }
    async transaction(r, t, n) {
        let i = {
            start: "starting",
            commit: "committing",
            rollback: "rolling back"
        };
        return this.withRetry({
            actionGerund: `${i[r]} transaction`,
            callback: async ({ logHttpCall: o })=>{
                if (r === "start") {
                    let s = JSON.stringify({
                        max_wait: n.maxWait,
                        timeout: n.timeout,
                        isolation_level: n.isolationLevel
                    }), a = await this.url("transaction/start");
                    o(a);
                    let l = await dr(a, {
                        method: "POST",
                        headers: this.headerBuilder.build({
                            traceparent: t.traceparent
                        }),
                        body: s,
                        clientVersion: this.clientVersion
                    });
                    await this.handleError(await Ft(l, this.clientVersion));
                    let u = await l.json(), { extensions: c } = u;
                    c && this.propagateResponseExtensions(c);
                    let p = u.id, d = u["data-proxy"].endpoint;
                    return {
                        id: p,
                        payload: {
                            endpoint: d
                        }
                    };
                } else {
                    let s = `${n.payload.endpoint}/${r}`;
                    o(s);
                    let a = await dr(s, {
                        method: "POST",
                        headers: this.headerBuilder.build({
                            traceparent: t.traceparent
                        }),
                        clientVersion: this.clientVersion
                    });
                    await this.handleError(await Ft(a, this.clientVersion));
                    let l = await a.json(), { extensions: u } = l;
                    u && this.propagateResponseExtensions(u);
                    return;
                }
            }
        });
    }
    extractHostAndApiKey() {
        let r = {
            clientVersion: this.clientVersion
        }, t = Object.keys(this.inlineDatasources)[0], n = jr({
            inlineDatasources: this.inlineDatasources,
            overrideDatasources: this.config.overrideDatasources,
            clientVersion: this.clientVersion,
            env: this.env
        }), i;
        try {
            i = new URL(n);
        } catch  {
            throw new ur(`Error validating datasource \`${t}\`: the URL must start with the protocol \`prisma://\``, r);
        }
        let { protocol: o, host: s, searchParams: a } = i;
        if (o !== "prisma:" && o !== en) throw new ur(`Error validating datasource \`${t}\`: the URL must start with the protocol \`prisma://\``, r);
        let l = a.get("api_key");
        if (l === null || l.length < 1) throw new ur(`Error validating datasource \`${t}\`: the URL must contain a valid API key`, r);
        return [
            s,
            l
        ];
    }
    metrics() {
        throw new cr("Metrics are not yet supported for Accelerate", {
            clientVersion: this.clientVersion
        });
    }
    async withRetry(r) {
        for(let t = 0;; t++){
            let n = (i)=>{
                this.logEmitter.emit("info", {
                    message: `Calling ${i} (n=${t})`,
                    timestamp: new Date,
                    target: ""
                });
            };
            try {
                return await r.callback({
                    logHttpCall: n
                });
            } catch (i) {
                if (!(i instanceof se) || !i.isRetryable) throw i;
                if (t >= kl) throw i instanceof Vr ? i.cause : i;
                this.logEmitter.emit("warn", {
                    message: `Attempt ${t + 1}/${kl} failed for ${r.actionGerund}: ${i.message ?? "(unknown)"}`,
                    timestamp: new Date,
                    target: ""
                });
                let o = await Tl(t);
                this.logEmitter.emit("warn", {
                    message: `Retrying after ${o}ms`,
                    timestamp: new Date,
                    target: ""
                });
            }
        }
    }
    async handleError(r) {
        if (r instanceof pr) throw await this.uploadSchema(), new Vr({
            clientVersion: this.clientVersion,
            cause: r
        });
        if (r) throw r;
    }
    convertProtocolErrorsToClientError(r) {
        return r.length === 1 ? $r(r[0], this.config.clientVersion, this.config.activeProvider) : new j(JSON.stringify(r), {
            clientVersion: this.config.clientVersion
        });
    }
    applyPendingMigrations() {
        throw new Error("Method not implemented.");
    }
};
function Ol(e) {
    if (e?.kind === "itx") return e.options.id;
}
var vo = k(__turbopack_context__.r("[externals]/node:os [external] (node:os, cjs)")), Dl = k(__turbopack_context__.r("[externals]/node:path [external] (node:path, cjs)"));
var xo = Symbol("PrismaLibraryEngineCache");
function mf() {
    let e = globalThis;
    return e[xo] === void 0 && (e[xo] = {}), e[xo];
}
function ff(e) {
    let r = mf();
    if (r[e] !== void 0) return r[e];
    let t = Dl.default.toNamespacedPath(e), n = {
        exports: {}
    }, i = 0;
    return process.platform !== "win32" && (i = vo.default.constants.dlopen.RTLD_LAZY | vo.default.constants.dlopen.RTLD_DEEPBIND), process.dlopen(n, t, i), r[e] = n.exports, n.exports;
}
var _l = {
    async loadLibrary (e) {
        let r = await pi(), t = await hl("library", e);
        try {
            return e.tracingHelper.runInChildSpan({
                name: "loadLibrary",
                internal: !0
            }, ()=>ff(t));
        } catch (n) {
            let i = Pi({
                e: n,
                platformInfo: r,
                id: t
            });
            throw new T(i, e.clientVersion);
        }
    }
};
var Po, Nl = {
    async loadLibrary (e) {
        let { clientVersion: r, adapter: t, engineWasm: n } = e;
        if (t === void 0) throw new T(`The \`adapter\` option for \`PrismaClient\` is required in this context (${qn().prettyName})`, r);
        if (n === void 0) throw new T("WASM engine was unexpectedly `undefined`", r);
        Po === void 0 && (Po = (async ()=>{
            let o = await n.getRuntime(), s = await n.getQueryEngineWasmModule();
            if (s == null) throw new T("The loaded wasm module was unexpectedly `undefined` or `null` once loaded", r);
            let a = {
                "./query_engine_bg.js": o
            }, l = new WebAssembly.Instance(s, a), u = l.exports.__wbindgen_start;
            return o.__wbg_set_wasm(l.exports), u(), o.QueryEngine;
        })());
        let i = await Po;
        return {
            debugPanic () {
                return Promise.reject("{}");
            },
            dmmf () {
                return Promise.resolve("{}");
            },
            version () {
                return {
                    commit: "unknown",
                    version: "unknown"
                };
            },
            QueryEngine: i
        };
    }
};
var gf = "P2036", Ce = N("prisma:client:libraryEngine");
function hf(e) {
    return e.item_type === "query" && "query" in e;
}
function yf(e) {
    return "level" in e ? e.level === "error" && e.message === "PANIC" : !1;
}
var Fl = [
    ...oi,
    "native"
], bf = 0xffffffffffffffffn, To = 1n;
function Ef() {
    let e = To++;
    return To > bf && (To = 1n), e;
}
var Qr = class {
    name = "LibraryEngine";
    engine;
    libraryInstantiationPromise;
    libraryStartingPromise;
    libraryStoppingPromise;
    libraryStarted;
    executingQueryPromise;
    config;
    QueryEngineConstructor;
    libraryLoader;
    library;
    logEmitter;
    libQueryEnginePath;
    binaryTarget;
    datasourceOverrides;
    datamodel;
    logQueries;
    logLevel;
    lastQuery;
    loggerRustPanic;
    tracingHelper;
    adapterPromise;
    versionInfo;
    constructor(r, t){
        this.libraryLoader = t ?? _l, r.engineWasm !== void 0 && (this.libraryLoader = t ?? Nl), this.config = r, this.libraryStarted = !1, this.logQueries = r.logQueries ?? !1, this.logLevel = r.logLevel ?? "error", this.logEmitter = r.logEmitter, this.datamodel = r.inlineSchema, this.tracingHelper = r.tracingHelper, r.enableDebugLogs && (this.logLevel = "debug");
        let n = Object.keys(r.overrideDatasources)[0], i = r.overrideDatasources[n]?.url;
        n !== void 0 && i !== void 0 && (this.datasourceOverrides = {
            [n]: i
        }), this.libraryInstantiationPromise = this.instantiateLibrary();
    }
    wrapEngine(r) {
        return {
            applyPendingMigrations: r.applyPendingMigrations?.bind(r),
            commitTransaction: this.withRequestId(r.commitTransaction.bind(r)),
            connect: this.withRequestId(r.connect.bind(r)),
            disconnect: this.withRequestId(r.disconnect.bind(r)),
            metrics: r.metrics?.bind(r),
            query: this.withRequestId(r.query.bind(r)),
            rollbackTransaction: this.withRequestId(r.rollbackTransaction.bind(r)),
            sdlSchema: r.sdlSchema?.bind(r),
            startTransaction: this.withRequestId(r.startTransaction.bind(r)),
            trace: r.trace.bind(r)
        };
    }
    withRequestId(r) {
        return async (...t)=>{
            let n = Ef().toString();
            try {
                return await r(...t, n);
            } finally{
                if (this.tracingHelper.isEnabled()) {
                    let i = await this.engine?.trace(n);
                    if (i) {
                        let o = JSON.parse(i);
                        this.tracingHelper.dispatchEngineSpans(o.spans);
                    }
                }
            }
        };
    }
    async applyPendingMigrations() {
        throw new Error("Cannot call this method from this type of engine instance");
    }
    async transaction(r, t, n) {
        await this.start();
        let i = await this.adapterPromise, o = JSON.stringify(t), s;
        if (r === "start") {
            let l = JSON.stringify({
                max_wait: n.maxWait,
                timeout: n.timeout,
                isolation_level: n.isolationLevel
            });
            s = await this.engine?.startTransaction(l, o);
        } else r === "commit" ? s = await this.engine?.commitTransaction(n.id, o) : r === "rollback" && (s = await this.engine?.rollbackTransaction(n.id, o));
        let a = this.parseEngineResponse(s);
        if (wf(a)) {
            let l = this.getExternalAdapterError(a, i?.errorRegistry);
            throw l ? l.error : new z(a.message, {
                code: a.error_code,
                clientVersion: this.config.clientVersion,
                meta: a.meta
            });
        } else if (typeof a.message == "string") throw new j(a.message, {
            clientVersion: this.config.clientVersion
        });
        return a;
    }
    async instantiateLibrary() {
        if (Ce("internalSetup"), this.libraryInstantiationPromise) return this.libraryInstantiationPromise;
        ii(), this.binaryTarget = await this.getCurrentBinaryTarget(), await this.tracingHelper.runInChildSpan("load_engine", ()=>this.loadEngine()), this.version();
    }
    async getCurrentBinaryTarget() {
        {
            if (this.binaryTarget) return this.binaryTarget;
            let r = await this.tracingHelper.runInChildSpan("detect_platform", ()=>ir());
            if (!Fl.includes(r)) throw new T(`Unknown ${ce("PRISMA_QUERY_ENGINE_LIBRARY")} ${ce(W(r))}. Possible binaryTargets: ${qe(Fl.join(", "))} or a path to the query engine library.
You may have to run ${qe("prisma generate")} for your changes to take effect.`, this.config.clientVersion);
            return r;
        }
    }
    parseEngineResponse(r) {
        if (!r) throw new j("Response from the Engine was empty", {
            clientVersion: this.config.clientVersion
        });
        try {
            return JSON.parse(r);
        } catch  {
            throw new j("Unable to JSON.parse response from engine", {
                clientVersion: this.config.clientVersion
            });
        }
    }
    async loadEngine() {
        if (!this.engine) {
            this.QueryEngineConstructor || (this.library = await this.libraryLoader.loadLibrary(this.config), this.QueryEngineConstructor = this.library.QueryEngine);
            try {
                let r = new WeakRef(this);
                this.adapterPromise || (this.adapterPromise = this.config.adapter?.connect()?.then(po));
                let t = await this.adapterPromise;
                t && Ce("Using driver adapter: %O", t), this.engine = this.wrapEngine(new this.QueryEngineConstructor({
                    datamodel: this.datamodel,
                    env: process.env,
                    logQueries: this.config.logQueries ?? !1,
                    ignoreEnvVarErrors: !0,
                    datasourceOverrides: this.datasourceOverrides ?? {},
                    logLevel: this.logLevel,
                    configDir: this.config.cwd,
                    engineProtocol: "json",
                    enableTracing: this.tracingHelper.isEnabled()
                }, (n)=>{
                    r.deref()?.logger(n);
                }, t));
            } catch (r) {
                let t = r, n = this.parseInitError(t.message);
                throw typeof n == "string" ? t : new T(n.message, this.config.clientVersion, n.error_code);
            }
        }
    }
    logger(r) {
        let t = this.parseEngineResponse(r);
        t && (t.level = t?.level.toLowerCase() ?? "unknown", hf(t) ? this.logEmitter.emit("query", {
            timestamp: new Date,
            query: t.query,
            params: t.params,
            duration: Number(t.duration_ms),
            target: t.module_path
        }) : yf(t) ? this.loggerRustPanic = new le(So(this, `${t.message}: ${t.reason} in ${t.file}:${t.line}:${t.column}`), this.config.clientVersion) : this.logEmitter.emit(t.level, {
            timestamp: new Date,
            message: t.message,
            target: t.module_path
        }));
    }
    parseInitError(r) {
        try {
            return JSON.parse(r);
        } catch  {}
        return r;
    }
    parseRequestError(r) {
        try {
            return JSON.parse(r);
        } catch  {}
        return r;
    }
    onBeforeExit() {
        throw new Error('"beforeExit" hook is not applicable to the library engine since Prisma 5.0.0, it is only relevant and implemented for the binary engine. Please add your event listener to the `process` object directly instead.');
    }
    async start() {
        if (await this.libraryInstantiationPromise, await this.libraryStoppingPromise, this.libraryStartingPromise) return Ce(`library already starting, this.libraryStarted: ${this.libraryStarted}`), this.libraryStartingPromise;
        if (this.libraryStarted) return;
        let r = async ()=>{
            Ce("library starting");
            try {
                let t = {
                    traceparent: this.tracingHelper.getTraceParent()
                };
                await this.engine?.connect(JSON.stringify(t)), this.libraryStarted = !0, Ce("library started");
            } catch (t) {
                let n = this.parseInitError(t.message);
                throw typeof n == "string" ? t : new T(n.message, this.config.clientVersion, n.error_code);
            } finally{
                this.libraryStartingPromise = void 0;
            }
        };
        return this.libraryStartingPromise = this.tracingHelper.runInChildSpan("connect", r), this.libraryStartingPromise;
    }
    async stop() {
        if (await this.libraryInstantiationPromise, await this.libraryStartingPromise, await this.executingQueryPromise, this.libraryStoppingPromise) return Ce("library is already stopping"), this.libraryStoppingPromise;
        if (!this.libraryStarted) return;
        let r = async ()=>{
            await new Promise((n)=>setTimeout(n, 5)), Ce("library stopping");
            let t = {
                traceparent: this.tracingHelper.getTraceParent()
            };
            await this.engine?.disconnect(JSON.stringify(t)), this.libraryStarted = !1, this.libraryStoppingPromise = void 0, await (await this.adapterPromise)?.dispose(), this.adapterPromise = void 0, Ce("library stopped");
        };
        return this.libraryStoppingPromise = this.tracingHelper.runInChildSpan("disconnect", r), this.libraryStoppingPromise;
    }
    version() {
        return this.versionInfo = this.library?.version(), this.versionInfo?.version ?? "unknown";
    }
    debugPanic(r) {
        return this.library?.debugPanic(r);
    }
    async request(r, { traceparent: t, interactiveTransaction: n }) {
        Ce(`sending request, this.libraryStarted: ${this.libraryStarted}`);
        let i = JSON.stringify({
            traceparent: t
        }), o = JSON.stringify(r);
        try {
            await this.start();
            let s = await this.adapterPromise;
            this.executingQueryPromise = this.engine?.query(o, i, n?.id), this.lastQuery = o;
            let a = this.parseEngineResponse(await this.executingQueryPromise);
            if (a.errors) throw a.errors.length === 1 ? this.buildQueryError(a.errors[0], s?.errorRegistry) : new j(JSON.stringify(a.errors), {
                clientVersion: this.config.clientVersion
            });
            if (this.loggerRustPanic) throw this.loggerRustPanic;
            return {
                data: a
            };
        } catch (s) {
            if (s instanceof T) throw s;
            if (s.code === "GenericFailure" && s.message?.startsWith("PANIC:")) throw new le(So(this, s.message), this.config.clientVersion);
            let a = this.parseRequestError(s.message);
            throw typeof a == "string" ? s : new j(`${a.message}
${a.backtrace}`, {
                clientVersion: this.config.clientVersion
            });
        }
    }
    async requestBatch(r, { transaction: t, traceparent: n }) {
        Ce("requestBatch");
        let i = Mr(r, t);
        await this.start();
        let o = await this.adapterPromise;
        this.lastQuery = JSON.stringify(i), this.executingQueryPromise = this.engine.query(this.lastQuery, JSON.stringify({
            traceparent: n
        }), Ol(t));
        let s = await this.executingQueryPromise, a = this.parseEngineResponse(s);
        if (a.errors) throw a.errors.length === 1 ? this.buildQueryError(a.errors[0], o?.errorRegistry) : new j(JSON.stringify(a.errors), {
            clientVersion: this.config.clientVersion
        });
        let { batchResult: l, errors: u } = a;
        if (Array.isArray(l)) return l.map((c)=>c.errors && c.errors.length > 0 ? this.loggerRustPanic ?? this.buildQueryError(c.errors[0], o?.errorRegistry) : {
                data: c
            });
        throw u && u.length === 1 ? new Error(u[0].error) : new Error(JSON.stringify(a));
    }
    buildQueryError(r, t) {
        if (r.user_facing_error.is_panic) return new le(So(this, r.user_facing_error.message), this.config.clientVersion);
        let n = this.getExternalAdapterError(r.user_facing_error, t);
        return n ? n.error : $r(r, this.config.clientVersion, this.config.activeProvider);
    }
    getExternalAdapterError(r, t) {
        if (r.error_code === gf && t) {
            let n = r.meta?.id;
            rn(typeof n == "number", "Malformed external JS error received from the engine");
            let i = t.consumeError(n);
            return rn(i, "External error with reported id was not registered"), i;
        }
    }
    async metrics(r) {
        await this.start();
        let t = await this.engine.metrics(JSON.stringify(r));
        return r.format === "prometheus" ? t : this.parseEngineResponse(t);
    }
};
function wf(e) {
    return typeof e == "object" && e !== null && e.error_code !== void 0;
}
function So(e, r) {
    return vl({
        binaryTarget: e.binaryTarget,
        title: r,
        version: e.config.clientVersion,
        engineVersion: e.versionInfo?.commit,
        database: e.config.activeProvider,
        query: e.lastQuery
    });
}
function Ll({ copyEngine: e = !0 }, r) {
    let t;
    try {
        t = jr({
            inlineDatasources: r.inlineDatasources,
            overrideDatasources: r.overrideDatasources,
            env: {
                ...r.env,
                ...process.env
            },
            clientVersion: r.clientVersion
        });
    } catch  {}
    let n = !!(t?.startsWith("prisma://") || Si(t));
    e && n && ot("recommend--no-engine", "In production, we recommend using `prisma generate --no-engine` (See: `prisma generate --help`)");
    let i = Er(r.generator), o = n || !e, s = !!r.adapter, a = i === "library", l = i === "binary", u = i === "client";
    if (o && s || s && !1) {
        let c;
        throw e ? t?.startsWith("prisma://") ? c = [
            "Prisma Client was configured to use the `adapter` option but the URL was a `prisma://` URL.",
            "Please either use the `prisma://` URL or remove the `adapter` from the Prisma Client constructor."
        ] : c = [
            "Prisma Client was configured to use both the `adapter` and Accelerate, please chose one."
        ] : c = [
            "Prisma Client was configured to use the `adapter` option but `prisma generate` was run with `--no-engine`.",
            "Please run `prisma generate` without `--no-engine` to be able to use Prisma Client with the adapter."
        ], new Z(c.join(`
`), {
            clientVersion: r.clientVersion
        });
    }
    return o ? new Mt(r) : a ? new Qr(r) : new Qr(r);
}
function Wn({ generator: e }) {
    return e?.previewFeatures ?? [];
}
var Ml = (e)=>({
        command: e
    });
var $l = (e)=>e.strings.reduce((r, t, n)=>`${r}@P${n}${t}`);
function Gr(e) {
    try {
        return ql(e, "fast");
    } catch  {
        return ql(e, "slow");
    }
}
function ql(e, r) {
    return JSON.stringify(e.map((t)=>Vl(t, r)));
}
function Vl(e, r) {
    if (Array.isArray(e)) return e.map((t)=>Vl(t, r));
    if (typeof e == "bigint") return {
        prisma__type: "bigint",
        prisma__value: e.toString()
    };
    if (Sr(e)) return {
        prisma__type: "date",
        prisma__value: e.toJSON()
    };
    if (ve.isDecimal(e)) return {
        prisma__type: "decimal",
        prisma__value: e.toJSON()
    };
    if (Buffer.isBuffer(e)) return {
        prisma__type: "bytes",
        prisma__value: e.toString("base64")
    };
    if (xf(e)) return {
        prisma__type: "bytes",
        prisma__value: Buffer.from(e).toString("base64")
    };
    if (ArrayBuffer.isView(e)) {
        let { buffer: t, byteOffset: n, byteLength: i } = e;
        return {
            prisma__type: "bytes",
            prisma__value: Buffer.from(t, n, i).toString("base64")
        };
    }
    return typeof e == "object" && r === "slow" ? Bl(e) : e;
}
function xf(e) {
    return e instanceof ArrayBuffer || e instanceof SharedArrayBuffer ? !0 : typeof e == "object" && e !== null ? e[Symbol.toStringTag] === "ArrayBuffer" || e[Symbol.toStringTag] === "SharedArrayBuffer" : !1;
}
function Bl(e) {
    if (typeof e != "object" || e === null) return e;
    if (typeof e.toJSON == "function") return e.toJSON();
    if (Array.isArray(e)) return e.map(jl);
    let r = {};
    for (let t of Object.keys(e))r[t] = jl(e[t]);
    return r;
}
function jl(e) {
    return typeof e == "bigint" ? e.toString() : Bl(e);
}
var vf = /^(\s*alter\s)/i, Ul = N("prisma:client");
function Ro(e, r, t, n) {
    if (!(e !== "postgresql" && e !== "cockroachdb") && t.length > 0 && vf.exec(r)) throw new Error(`Running ALTER using ${n} is not supported
Using the example below you can still execute your query with Prisma, but please note that it is vulnerable to SQL injection attacks and requires you to take care of input sanitization.

Example:
  await prisma.$executeRawUnsafe(\`ALTER USER prisma WITH PASSWORD '\${password}'\`)

More Information: https://pris.ly/d/execute-raw
`);
}
var Co = ({ clientMethod: e, activeProvider: r })=>(t)=>{
        let n = "", i;
        if (Nn(t)) n = t.sql, i = {
            values: Gr(t.values),
            __prismaRawParameters__: !0
        };
        else if (Array.isArray(t)) {
            let [o, ...s] = t;
            n = o, i = {
                values: Gr(s || []),
                __prismaRawParameters__: !0
            };
        } else switch(r){
            case "sqlite":
            case "mysql":
                {
                    n = t.sql, i = {
                        values: Gr(t.values),
                        __prismaRawParameters__: !0
                    };
                    break;
                }
            case "cockroachdb":
            case "postgresql":
            case "postgres":
                {
                    n = t.text, i = {
                        values: Gr(t.values),
                        __prismaRawParameters__: !0
                    };
                    break;
                }
            case "sqlserver":
                {
                    n = $l(t), i = {
                        values: Gr(t.values),
                        __prismaRawParameters__: !0
                    };
                    break;
                }
            default:
                throw new Error(`The ${r} provider does not support ${e}`);
        }
        return i?.values ? Ul(`prisma.${e}(${n}, ${i.values})`) : Ul(`prisma.${e}(${n})`), {
            query: n,
            parameters: i
        };
    }, Ql = {
    requestArgsToMiddlewareArgs (e) {
        return [
            e.strings,
            ...e.values
        ];
    },
    middlewareArgsToRequestArgs (e) {
        let [r, ...t] = e;
        return new oe(r, t);
    }
}, Gl = {
    requestArgsToMiddlewareArgs (e) {
        return [
            e
        ];
    },
    middlewareArgsToRequestArgs (e) {
        return e[0];
    }
};
function Ao(e) {
    return function(t, n) {
        let i, o = (s = e)=>{
            try {
                return s === void 0 || s?.kind === "itx" ? i ??= Wl(t(s)) : Wl(t(s));
            } catch (a) {
                return Promise.reject(a);
            }
        };
        return {
            get spec () {
                return n;
            },
            then (s, a) {
                return o().then(s, a);
            },
            catch (s) {
                return o().catch(s);
            },
            finally (s) {
                return o().finally(s);
            },
            requestTransaction (s) {
                let a = o(s);
                return a.requestTransaction ? a.requestTransaction(s) : a;
            },
            [Symbol.toStringTag]: "PrismaPromise"
        };
    };
}
function Wl(e) {
    return typeof e.then == "function" ? e : Promise.resolve(e);
}
var Pf = bi.split(".")[0], Tf = {
    isEnabled () {
        return !1;
    },
    getTraceParent () {
        return "00-10-10-00";
    },
    dispatchEngineSpans () {},
    getActiveContext () {},
    runInChildSpan (e, r) {
        return r();
    }
}, Io = class {
    isEnabled() {
        return this.getGlobalTracingHelper().isEnabled();
    }
    getTraceParent(r) {
        return this.getGlobalTracingHelper().getTraceParent(r);
    }
    dispatchEngineSpans(r) {
        return this.getGlobalTracingHelper().dispatchEngineSpans(r);
    }
    getActiveContext() {
        return this.getGlobalTracingHelper().getActiveContext();
    }
    runInChildSpan(r, t) {
        return this.getGlobalTracingHelper().runInChildSpan(r, t);
    }
    getGlobalTracingHelper() {
        let r = globalThis[`V${Pf}_PRISMA_INSTRUMENTATION`], t = globalThis.PRISMA_INSTRUMENTATION;
        return r?.helper ?? t?.helper ?? Tf;
    }
};
function Jl() {
    return new Io;
}
function Hl(e, r = ()=>{}) {
    let t, n = new Promise((i)=>t = i);
    return {
        then (i) {
            return --e === 0 && t(r()), i?.(n);
        }
    };
}
function Kl(e) {
    return typeof e == "string" ? e : e.reduce((r, t)=>{
        let n = typeof t == "string" ? t : t.level;
        return n === "query" ? r : r && (t === "info" || r === "info") ? "info" : n;
    }, void 0);
}
var Jn = class {
    _middlewares = [];
    use(r) {
        this._middlewares.push(r);
    }
    get(r) {
        return this._middlewares[r];
    }
    has(r) {
        return !!this._middlewares[r];
    }
    length() {
        return this._middlewares.length;
    }
};
var zl = k(ki());
function Hn(e) {
    return typeof e.batchRequestIdx == "number";
}
function Yl(e) {
    if (e.action !== "findUnique" && e.action !== "findUniqueOrThrow") return;
    let r = [];
    return e.modelName && r.push(e.modelName), e.query.arguments && r.push(ko(e.query.arguments)), r.push(ko(e.query.selection)), r.join("");
}
function ko(e) {
    return `(${Object.keys(e).sort().map((t)=>{
        let n = e[t];
        return typeof n == "object" && n !== null ? `(${t} ${ko(n)})` : t;
    }).join(" ")})`;
}
var Sf = {
    aggregate: !1,
    aggregateRaw: !1,
    createMany: !0,
    createManyAndReturn: !0,
    createOne: !0,
    deleteMany: !0,
    deleteOne: !0,
    executeRaw: !0,
    findFirst: !1,
    findFirstOrThrow: !1,
    findMany: !1,
    findRaw: !1,
    findUnique: !1,
    findUniqueOrThrow: !1,
    groupBy: !1,
    queryRaw: !1,
    runCommandRaw: !0,
    updateMany: !0,
    updateManyAndReturn: !0,
    updateOne: !0,
    upsertOne: !0
};
function Oo(e) {
    return Sf[e];
}
var Kn = class {
    constructor(r){
        this.options = r;
        this.batches = {};
    }
    batches;
    tickActive = !1;
    request(r) {
        let t = this.options.batchBy(r);
        return t ? (this.batches[t] || (this.batches[t] = [], this.tickActive || (this.tickActive = !0, process.nextTick(()=>{
            this.dispatchBatches(), this.tickActive = !1;
        }))), new Promise((n, i)=>{
            this.batches[t].push({
                request: r,
                resolve: n,
                reject: i
            });
        })) : this.options.singleLoader(r);
    }
    dispatchBatches() {
        for(let r in this.batches){
            let t = this.batches[r];
            delete this.batches[r], t.length === 1 ? this.options.singleLoader(t[0].request).then((n)=>{
                n instanceof Error ? t[0].reject(n) : t[0].resolve(n);
            }).catch((n)=>{
                t[0].reject(n);
            }) : (t.sort((n, i)=>this.options.batchOrder(n.request, i.request)), this.options.batchLoader(t.map((n)=>n.request)).then((n)=>{
                if (n instanceof Error) for(let i = 0; i < t.length; i++)t[i].reject(n);
                else for(let i = 0; i < t.length; i++){
                    let o = n[i];
                    o instanceof Error ? t[i].reject(o) : t[i].resolve(o);
                }
            }).catch((n)=>{
                for(let i = 0; i < t.length; i++)t[i].reject(n);
            }));
        }
    }
    get [Symbol.toStringTag]() {
        return "DataLoader";
    }
};
function mr(e, r) {
    if (r === null) return r;
    switch(e){
        case "bigint":
            return BigInt(r);
        case "bytes":
            {
                let { buffer: t, byteOffset: n, byteLength: i } = Buffer.from(r, "base64");
                return new Uint8Array(t, n, i);
            }
        case "decimal":
            return new ve(r);
        case "datetime":
        case "date":
            return new Date(r);
        case "time":
            return new Date(`1970-01-01T${r}Z`);
        case "bigint-array":
            return r.map((t)=>mr("bigint", t));
        case "bytes-array":
            return r.map((t)=>mr("bytes", t));
        case "decimal-array":
            return r.map((t)=>mr("decimal", t));
        case "datetime-array":
            return r.map((t)=>mr("datetime", t));
        case "date-array":
            return r.map((t)=>mr("date", t));
        case "time-array":
            return r.map((t)=>mr("time", t));
        default:
            return r;
    }
}
function Yn(e) {
    let r = [], t = Rf(e);
    for(let n = 0; n < e.rows.length; n++){
        let i = e.rows[n], o = {
            ...t
        };
        for(let s = 0; s < i.length; s++)o[e.columns[s]] = mr(e.types[s], i[s]);
        r.push(o);
    }
    return r;
}
function Rf(e) {
    let r = {};
    for(let t = 0; t < e.columns.length; t++)r[e.columns[t]] = null;
    return r;
}
var Cf = N("prisma:client:request_handler"), zn = class {
    client;
    dataloader;
    logEmitter;
    constructor(r, t){
        this.logEmitter = t, this.client = r, this.dataloader = new Kn({
            batchLoader: il(async ({ requests: n, customDataProxyFetch: i })=>{
                let { transaction: o, otelParentCtx: s } = n[0], a = n.map((p)=>p.protocolQuery), l = this.client._tracingHelper.getTraceParent(s), u = n.some((p)=>Oo(p.protocolQuery.action));
                return (await this.client._engine.requestBatch(a, {
                    traceparent: l,
                    transaction: Af(o),
                    containsWrite: u,
                    customDataProxyFetch: i
                })).map((p, d)=>{
                    if (p instanceof Error) return p;
                    try {
                        return this.mapQueryEngineResult(n[d], p);
                    } catch (f) {
                        return f;
                    }
                });
            }),
            singleLoader: async (n)=>{
                let i = n.transaction?.kind === "itx" ? Zl(n.transaction) : void 0, o = await this.client._engine.request(n.protocolQuery, {
                    traceparent: this.client._tracingHelper.getTraceParent(),
                    interactiveTransaction: i,
                    isWrite: Oo(n.protocolQuery.action),
                    customDataProxyFetch: n.customDataProxyFetch
                });
                return this.mapQueryEngineResult(n, o);
            },
            batchBy: (n)=>n.transaction?.id ? `transaction-${n.transaction.id}` : Yl(n.protocolQuery),
            batchOrder (n, i) {
                return n.transaction?.kind === "batch" && i.transaction?.kind === "batch" ? n.transaction.index - i.transaction.index : 0;
            }
        });
    }
    async request(r) {
        try {
            return await this.dataloader.request(r);
        } catch (t) {
            let { clientMethod: n, callsite: i, transaction: o, args: s, modelName: a } = r;
            this.handleAndLogRequestError({
                error: t,
                clientMethod: n,
                callsite: i,
                transaction: o,
                args: s,
                modelName: a,
                globalOmit: r.globalOmit
            });
        }
    }
    mapQueryEngineResult({ dataPath: r, unpacker: t }, n) {
        let i = n?.data, o = this.unpack(i, r, t);
        return process.env.PRISMA_CLIENT_GET_TIME ? {
            data: o
        } : o;
    }
    handleAndLogRequestError(r) {
        try {
            this.handleRequestError(r);
        } catch (t) {
            throw this.logEmitter && this.logEmitter.emit("error", {
                message: t.message,
                target: r.clientMethod,
                timestamp: new Date
            }), t;
        }
    }
    handleRequestError({ error: r, clientMethod: t, callsite: n, transaction: i, args: o, modelName: s, globalOmit: a }) {
        if (Cf(r), If(r, i)) throw r;
        if (r instanceof z && kf(r)) {
            let u = Xl(r.meta);
            An({
                args: o,
                errors: [
                    u
                ],
                callsite: n,
                errorFormat: this.client._errorFormat,
                originalMethod: t,
                clientVersion: this.client._clientVersion,
                globalOmit: a
            });
        }
        let l = r.message;
        if (n && (l = bn({
            callsite: n,
            originalMethod: t,
            isPanic: r.isPanic,
            showColors: this.client._errorFormat === "pretty",
            message: l
        })), l = this.sanitizeMessage(l), r.code) {
            let u = s ? {
                modelName: s,
                ...r.meta
            } : r.meta;
            throw new z(l, {
                code: r.code,
                clientVersion: this.client._clientVersion,
                meta: u,
                batchRequestIdx: r.batchRequestIdx
            });
        } else {
            if (r.isPanic) throw new le(l, this.client._clientVersion);
            if (r instanceof j) throw new j(l, {
                clientVersion: this.client._clientVersion,
                batchRequestIdx: r.batchRequestIdx
            });
            if (r instanceof T) throw new T(l, this.client._clientVersion);
            if (r instanceof le) throw new le(l, this.client._clientVersion);
        }
        throw r.clientVersion = this.client._clientVersion, r;
    }
    sanitizeMessage(r) {
        return this.client._errorFormat && this.client._errorFormat !== "pretty" ? (0, zl.default)(r) : r;
    }
    unpack(r, t, n) {
        if (!r || (r.data && (r = r.data), !r)) return r;
        let i = Object.keys(r)[0], o = Object.values(r)[0], s = t.filter((u)=>u !== "select" && u !== "include"), a = io(o, s), l = i === "queryRaw" ? Yn(a) : Tr(a);
        return n ? n(l) : l;
    }
    get [Symbol.toStringTag]() {
        return "RequestHandler";
    }
};
function Af(e) {
    if (e) {
        if (e.kind === "batch") return {
            kind: "batch",
            options: {
                isolationLevel: e.isolationLevel
            }
        };
        if (e.kind === "itx") return {
            kind: "itx",
            options: Zl(e)
        };
        _e(e, "Unknown transaction kind");
    }
}
function Zl(e) {
    return {
        id: e.id,
        payload: e.payload
    };
}
function If(e, r) {
    return Hn(e) && r?.kind === "batch" && e.batchRequestIdx !== r.index;
}
function kf(e) {
    return e.code === "P2009" || e.code === "P2012";
}
function Xl(e) {
    if (e.kind === "Union") return {
        kind: "Union",
        errors: e.errors.map(Xl)
    };
    if (Array.isArray(e.selectionPath)) {
        let [, ...r] = e.selectionPath;
        return {
            ...e,
            selectionPath: r
        };
    }
    return e;
}
var eu = "6.7.0";
var ru = eu;
var su = k(Gi());
var D = class extends Error {
    constructor(r){
        super(r + `
Read more at https://pris.ly/d/client-constructor`), this.name = "PrismaClientConstructorValidationError";
    }
    get [Symbol.toStringTag]() {
        return "PrismaClientConstructorValidationError";
    }
};
x(D, "PrismaClientConstructorValidationError");
var tu = [
    "datasources",
    "datasourceUrl",
    "errorFormat",
    "adapter",
    "log",
    "transactionOptions",
    "omit",
    "__internal"
], nu = [
    "pretty",
    "colorless",
    "minimal"
], iu = [
    "info",
    "query",
    "warn",
    "error"
], Df = {
    datasources: (e, { datasourceNames: r })=>{
        if (e) {
            if (typeof e != "object" || Array.isArray(e)) throw new D(`Invalid value ${JSON.stringify(e)} for "datasources" provided to PrismaClient constructor`);
            for (let [t, n] of Object.entries(e)){
                if (!r.includes(t)) {
                    let i = Wr(t, r) || ` Available datasources: ${r.join(", ")}`;
                    throw new D(`Unknown datasource ${t} provided to PrismaClient constructor.${i}`);
                }
                if (typeof n != "object" || Array.isArray(n)) throw new D(`Invalid value ${JSON.stringify(e)} for datasource "${t}" provided to PrismaClient constructor.
It should have this form: { url: "CONNECTION_STRING" }`);
                if (n && typeof n == "object") for (let [i, o] of Object.entries(n)){
                    if (i !== "url") throw new D(`Invalid value ${JSON.stringify(e)} for datasource "${t}" provided to PrismaClient constructor.
It should have this form: { url: "CONNECTION_STRING" }`);
                    if (typeof o != "string") throw new D(`Invalid value ${JSON.stringify(o)} for datasource "${t}" provided to PrismaClient constructor.
It should have this form: { url: "CONNECTION_STRING" }`);
                }
            }
        }
    },
    adapter: (e, r)=>{
        if (!e && Er(r.generator) === "client") throw new D('Using engine type "client" requires a driver adapter to be provided to PrismaClient constructor.');
        if (e === null) return;
        if (e === void 0) throw new D('"adapter" property must not be undefined, use null to conditionally disable driver adapters.');
        if (!Wn(r).includes("driverAdapters")) throw new D('"adapter" property can only be provided to PrismaClient constructor when "driverAdapters" preview feature is enabled.');
        if (Er(r.generator) === "binary") throw new D('Cannot use a driver adapter with the "binary" Query Engine. Please use the "library" Query Engine.');
    },
    datasourceUrl: (e)=>{
        if (typeof e < "u" && typeof e != "string") throw new D(`Invalid value ${JSON.stringify(e)} for "datasourceUrl" provided to PrismaClient constructor.
Expected string or undefined.`);
    },
    errorFormat: (e)=>{
        if (e) {
            if (typeof e != "string") throw new D(`Invalid value ${JSON.stringify(e)} for "errorFormat" provided to PrismaClient constructor.`);
            if (!nu.includes(e)) {
                let r = Wr(e, nu);
                throw new D(`Invalid errorFormat ${e} provided to PrismaClient constructor.${r}`);
            }
        }
    },
    log: (e)=>{
        if (!e) return;
        if (!Array.isArray(e)) throw new D(`Invalid value ${JSON.stringify(e)} for "log" provided to PrismaClient constructor.`);
        function r(t) {
            if (typeof t == "string" && !iu.includes(t)) {
                let n = Wr(t, iu);
                throw new D(`Invalid log level "${t}" provided to PrismaClient constructor.${n}`);
            }
        }
        for (let t of e){
            r(t);
            let n = {
                level: r,
                emit: (i)=>{
                    let o = [
                        "stdout",
                        "event"
                    ];
                    if (!o.includes(i)) {
                        let s = Wr(i, o);
                        throw new D(`Invalid value ${JSON.stringify(i)} for "emit" in logLevel provided to PrismaClient constructor.${s}`);
                    }
                }
            };
            if (t && typeof t == "object") for (let [i, o] of Object.entries(t))if (n[i]) n[i](o);
            else throw new D(`Invalid property ${i} for "log" provided to PrismaClient constructor`);
        }
    },
    transactionOptions: (e)=>{
        if (!e) return;
        let r = e.maxWait;
        if (r != null && r <= 0) throw new D(`Invalid value ${r} for maxWait in "transactionOptions" provided to PrismaClient constructor. maxWait needs to be greater than 0`);
        let t = e.timeout;
        if (t != null && t <= 0) throw new D(`Invalid value ${t} for timeout in "transactionOptions" provided to PrismaClient constructor. timeout needs to be greater than 0`);
    },
    omit: (e, r)=>{
        if (typeof e != "object") throw new D('"omit" option is expected to be an object.');
        if (e === null) throw new D('"omit" option can not be `null`');
        let t = [];
        for (let [n, i] of Object.entries(e)){
            let o = Nf(n, r.runtimeDataModel);
            if (!o) {
                t.push({
                    kind: "UnknownModel",
                    modelKey: n
                });
                continue;
            }
            for (let [s, a] of Object.entries(i)){
                let l = o.fields.find((u)=>u.name === s);
                if (!l) {
                    t.push({
                        kind: "UnknownField",
                        modelKey: n,
                        fieldName: s
                    });
                    continue;
                }
                if (l.relationName) {
                    t.push({
                        kind: "RelationInOmit",
                        modelKey: n,
                        fieldName: s
                    });
                    continue;
                }
                typeof a != "boolean" && t.push({
                    kind: "InvalidFieldValue",
                    modelKey: n,
                    fieldName: s
                });
            }
        }
        if (t.length > 0) throw new D(Ff(e, t));
    },
    __internal: (e)=>{
        if (!e) return;
        let r = [
            "debug",
            "engine",
            "configOverride"
        ];
        if (typeof e != "object") throw new D(`Invalid value ${JSON.stringify(e)} for "__internal" to PrismaClient constructor`);
        for (let [t] of Object.entries(e))if (!r.includes(t)) {
            let n = Wr(t, r);
            throw new D(`Invalid property ${JSON.stringify(t)} for "__internal" provided to PrismaClient constructor.${n}`);
        }
    }
};
function au(e, r) {
    for (let [t, n] of Object.entries(e)){
        if (!tu.includes(t)) {
            let i = Wr(t, tu);
            throw new D(`Unknown property ${t} provided to PrismaClient constructor.${i}`);
        }
        Df[t](n, r);
    }
    if (e.datasourceUrl && e.datasources) throw new D('Can not use "datasourceUrl" and "datasources" options at the same time. Pick one of them');
}
function Wr(e, r) {
    if (r.length === 0 || typeof e != "string") return "";
    let t = _f(e, r);
    return t ? ` Did you mean "${t}"?` : "";
}
function _f(e, r) {
    if (r.length === 0) return null;
    let t = r.map((i)=>({
            value: i,
            distance: (0, su.default)(e, i)
        }));
    t.sort((i, o)=>i.distance < o.distance ? -1 : 1);
    let n = t[0];
    return n.distance < 3 ? n.value : null;
}
function Nf(e, r) {
    return ou(r.models, e) ?? ou(r.types, e);
}
function ou(e, r) {
    let t = Object.keys(e).find((n)=>Ye(n) === r);
    if (t) return e[t];
}
function Ff(e, r) {
    let t = _r(e);
    for (let o of r)switch(o.kind){
        case "UnknownModel":
            t.arguments.getField(o.modelKey)?.markAsError(), t.addErrorMessage(()=>`Unknown model name: ${o.modelKey}.`);
            break;
        case "UnknownField":
            t.arguments.getDeepField([
                o.modelKey,
                o.fieldName
            ])?.markAsError(), t.addErrorMessage(()=>`Model "${o.modelKey}" does not have a field named "${o.fieldName}".`);
            break;
        case "RelationInOmit":
            t.arguments.getDeepField([
                o.modelKey,
                o.fieldName
            ])?.markAsError(), t.addErrorMessage(()=>'Relations are already excluded by default and can not be specified in "omit".');
            break;
        case "InvalidFieldValue":
            t.arguments.getDeepFieldValue([
                o.modelKey,
                o.fieldName
            ])?.markAsError(), t.addErrorMessage(()=>"Omit field option value must be a boolean.");
            break;
    }
    let { message: n, args: i } = Cn(t, "colorless");
    return `Error validating "omit" option:

${i}

${n}`;
}
function lu(e) {
    return e.length === 0 ? Promise.resolve([]) : new Promise((r, t)=>{
        let n = new Array(e.length), i = null, o = !1, s = 0, a = ()=>{
            o || (s++, s === e.length && (o = !0, i ? t(i) : r(n)));
        }, l = (u)=>{
            o || (o = !0, t(u));
        };
        for(let u = 0; u < e.length; u++)e[u].then((c)=>{
            n[u] = c, a();
        }, (c)=>{
            if (!Hn(c)) {
                l(c);
                return;
            }
            c.batchRequestIdx === u ? l(c) : (i || (i = c), a());
        });
    });
}
var rr = N("prisma:client");
typeof globalThis == "object" && (globalThis.NODE_CLIENT = !0);
var Lf = {
    requestArgsToMiddlewareArgs: (e)=>e,
    middlewareArgsToRequestArgs: (e)=>e
}, Mf = Symbol.for("prisma.client.transaction.id"), $f = {
    id: 0,
    nextId () {
        return ++this.id;
    }
};
function fu(e) {
    class r {
        _originalClient = this;
        _runtimeDataModel;
        _requestHandler;
        _connectionPromise;
        _disconnectionPromise;
        _engineConfig;
        _accelerateEngineConfig;
        _clientVersion;
        _errorFormat;
        _tracingHelper;
        _middlewares = new Jn;
        _previewFeatures;
        _activeProvider;
        _globalOmit;
        _extensions;
        _engine;
        _appliedParent;
        _createPrismaPromise = Ao();
        constructor(n){
            e = n?.__internal?.configOverride?.(e) ?? e, ul(e), n && au(n, e);
            let i = new du.EventEmitter().on("error", ()=>{});
            this._extensions = Nr.empty(), this._previewFeatures = Wn(e), this._clientVersion = e.clientVersion ?? ru, this._activeProvider = e.activeProvider, this._globalOmit = n?.omit, this._tracingHelper = Jl();
            let o = e.relativeEnvPaths && {
                rootEnvPath: e.relativeEnvPaths.rootEnvPath && Zn.default.resolve(e.dirname, e.relativeEnvPaths.rootEnvPath),
                schemaEnvPath: e.relativeEnvPaths.schemaEnvPath && Zn.default.resolve(e.dirname, e.relativeEnvPaths.schemaEnvPath)
            }, s;
            if (n?.adapter) {
                s = n.adapter;
                let l = e.activeProvider === "postgresql" ? "postgres" : e.activeProvider;
                if (s.provider !== l) throw new T(`The Driver Adapter \`${s.adapterName}\`, based on \`${s.provider}\`, is not compatible with the provider \`${l}\` specified in the Prisma schema.`, this._clientVersion);
                if (n.datasources || n.datasourceUrl !== void 0) throw new T("Custom datasource configuration is not compatible with Prisma Driver Adapters. Please define the database connection string directly in the Driver Adapter configuration.", this._clientVersion);
            }
            let a = !s && o && it(o, {
                conflictCheck: "none"
            }) || e.injectableEdgeEnv?.();
            try {
                let l = n ?? {}, u = l.__internal ?? {}, c = u.debug === !0;
                c && N.enable("prisma:client");
                let p = Zn.default.resolve(e.dirname, e.relativePath);
                mu.default.existsSync(p) || (p = e.dirname), rr("dirname", e.dirname), rr("relativePath", e.relativePath), rr("cwd", p);
                let d = u.engine || {};
                if (l.errorFormat ? this._errorFormat = l.errorFormat : ("TURBOPACK compile-time falsy", 0) ? ("TURBOPACK unreachable", undefined) : process.env.NO_COLOR ? this._errorFormat = "colorless" : this._errorFormat = "colorless", this._runtimeDataModel = e.runtimeDataModel, this._engineConfig = {
                    cwd: p,
                    dirname: e.dirname,
                    enableDebugLogs: c,
                    allowTriggerPanic: d.allowTriggerPanic,
                    prismaPath: d.binaryPath ?? void 0,
                    engineEndpoint: d.endpoint,
                    generator: e.generator,
                    showColors: this._errorFormat === "pretty",
                    logLevel: l.log && Kl(l.log),
                    logQueries: l.log && !!(typeof l.log == "string" ? l.log === "query" : l.log.find((f)=>typeof f == "string" ? f === "query" : f.level === "query")),
                    env: a?.parsed ?? {},
                    flags: [],
                    engineWasm: e.engineWasm,
                    compilerWasm: e.compilerWasm,
                    clientVersion: e.clientVersion,
                    engineVersion: e.engineVersion,
                    previewFeatures: this._previewFeatures,
                    activeProvider: e.activeProvider,
                    inlineSchema: e.inlineSchema,
                    overrideDatasources: cl(l, e.datasourceNames),
                    inlineDatasources: e.inlineDatasources,
                    inlineSchemaHash: e.inlineSchemaHash,
                    tracingHelper: this._tracingHelper,
                    transactionOptions: {
                        maxWait: l.transactionOptions?.maxWait ?? 2e3,
                        timeout: l.transactionOptions?.timeout ?? 5e3,
                        isolationLevel: l.transactionOptions?.isolationLevel
                    },
                    logEmitter: i,
                    isBundled: e.isBundled,
                    adapter: s
                }, this._accelerateEngineConfig = {
                    ...this._engineConfig,
                    accelerateUtils: {
                        resolveDatasourceUrl: jr,
                        getBatchRequestPayload: Mr,
                        prismaGraphQLToJSError: $r,
                        PrismaClientUnknownRequestError: j,
                        PrismaClientInitializationError: T,
                        PrismaClientKnownRequestError: z,
                        debug: N("prisma:client:accelerateEngine"),
                        engineVersion: cu.version,
                        clientVersion: e.clientVersion
                    }
                }, rr("clientVersion", e.clientVersion), this._engine = Ll(e, this._engineConfig), this._requestHandler = new zn(this, i), l.log) for (let f of l.log){
                    let g = typeof f == "string" ? f : f.emit === "stdout" ? f.level : null;
                    g && this.$on(g, (h)=>{
                        tt.log(`${tt.tags[g] ?? ""}`, h.message || h.query);
                    });
                }
            } catch (l) {
                throw l.clientVersion = this._clientVersion, l;
            }
            return this._appliedParent = vt(this);
        }
        get [Symbol.toStringTag]() {
            return "PrismaClient";
        }
        $use(n) {
            this._middlewares.use(n);
        }
        $on(n, i) {
            return n === "beforeExit" ? this._engine.onBeforeExit(i) : n && this._engineConfig.logEmitter.on(n, i), this;
        }
        $connect() {
            try {
                return this._engine.start();
            } catch (n) {
                throw n.clientVersion = this._clientVersion, n;
            }
        }
        async $disconnect() {
            try {
                await this._engine.stop();
            } catch (n) {
                throw n.clientVersion = this._clientVersion, n;
            } finally{
                Go();
            }
        }
        $executeRawInternal(n, i, o, s) {
            let a = this._activeProvider;
            return this._request({
                action: "executeRaw",
                args: o,
                transaction: n,
                clientMethod: i,
                argsMapper: Co({
                    clientMethod: i,
                    activeProvider: a
                }),
                callsite: Ze(this._errorFormat),
                dataPath: [],
                middlewareArgsMapper: s
            });
        }
        $executeRaw(n, ...i) {
            return this._createPrismaPromise((o)=>{
                if (n.raw !== void 0 || n.sql !== void 0) {
                    let [s, a] = uu(n, i);
                    return Ro(this._activeProvider, s.text, s.values, Array.isArray(n) ? "prisma.$executeRaw`<SQL>`" : "prisma.$executeRaw(sql`<SQL>`)"), this.$executeRawInternal(o, "$executeRaw", s, a);
                }
                throw new Z("`$executeRaw` is a tag function, please use it like the following:\n```\nconst result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`\n```\n\nOr read our docs at https://www.prisma.io/docs/concepts/components/prisma-client/raw-database-access#executeraw\n", {
                    clientVersion: this._clientVersion
                });
            });
        }
        $executeRawUnsafe(n, ...i) {
            return this._createPrismaPromise((o)=>(Ro(this._activeProvider, n, i, "prisma.$executeRawUnsafe(<SQL>, [...values])"), this.$executeRawInternal(o, "$executeRawUnsafe", [
                    n,
                    ...i
                ])));
        }
        $runCommandRaw(n) {
            if (e.activeProvider !== "mongodb") throw new Z(`The ${e.activeProvider} provider does not support $runCommandRaw. Use the mongodb provider.`, {
                clientVersion: this._clientVersion
            });
            return this._createPrismaPromise((i)=>this._request({
                    args: n,
                    clientMethod: "$runCommandRaw",
                    dataPath: [],
                    action: "runCommandRaw",
                    argsMapper: Ml,
                    callsite: Ze(this._errorFormat),
                    transaction: i
                }));
        }
        async $queryRawInternal(n, i, o, s) {
            let a = this._activeProvider;
            return this._request({
                action: "queryRaw",
                args: o,
                transaction: n,
                clientMethod: i,
                argsMapper: Co({
                    clientMethod: i,
                    activeProvider: a
                }),
                callsite: Ze(this._errorFormat),
                dataPath: [],
                middlewareArgsMapper: s
            });
        }
        $queryRaw(n, ...i) {
            return this._createPrismaPromise((o)=>{
                if (n.raw !== void 0 || n.sql !== void 0) return this.$queryRawInternal(o, "$queryRaw", ...uu(n, i));
                throw new Z("`$queryRaw` is a tag function, please use it like the following:\n```\nconst result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`\n```\n\nOr read our docs at https://www.prisma.io/docs/concepts/components/prisma-client/raw-database-access#queryraw\n", {
                    clientVersion: this._clientVersion
                });
            });
        }
        $queryRawTyped(n) {
            return this._createPrismaPromise((i)=>{
                if (!this._hasPreviewFlag("typedSql")) throw new Z("`typedSql` preview feature must be enabled in order to access $queryRawTyped API", {
                    clientVersion: this._clientVersion
                });
                return this.$queryRawInternal(i, "$queryRawTyped", n);
            });
        }
        $queryRawUnsafe(n, ...i) {
            return this._createPrismaPromise((o)=>this.$queryRawInternal(o, "$queryRawUnsafe", [
                    n,
                    ...i
                ]));
        }
        _transactionWithArray({ promises: n, options: i }) {
            let o = $f.nextId(), s = Hl(n.length), a = n.map((l, u)=>{
                if (l?.[Symbol.toStringTag] !== "PrismaPromise") throw new Error("All elements of the array need to be Prisma Client promises. Hint: Please make sure you are not awaiting the Prisma client calls you intended to pass in the $transaction function.");
                let c = i?.isolationLevel ?? this._engineConfig.transactionOptions.isolationLevel, p = {
                    kind: "batch",
                    id: o,
                    index: u,
                    isolationLevel: c,
                    lock: s
                };
                return l.requestTransaction?.(p) ?? l;
            });
            return lu(a);
        }
        async _transactionWithCallback({ callback: n, options: i }) {
            let o = {
                traceparent: this._tracingHelper.getTraceParent()
            }, s = {
                maxWait: i?.maxWait ?? this._engineConfig.transactionOptions.maxWait,
                timeout: i?.timeout ?? this._engineConfig.transactionOptions.timeout,
                isolationLevel: i?.isolationLevel ?? this._engineConfig.transactionOptions.isolationLevel
            }, a = await this._engine.transaction("start", o, s), l;
            try {
                let u = {
                    kind: "itx",
                    ...a
                };
                l = await n(this._createItxClient(u)), await this._engine.transaction("commit", o, a);
            } catch (u) {
                throw await this._engine.transaction("rollback", o, a).catch(()=>{}), u;
            }
            return l;
        }
        _createItxClient(n) {
            return he(vt(he(Ha(this), [
                re("_appliedParent", ()=>this._appliedParent._createItxClient(n)),
                re("_createPrismaPromise", ()=>Ao(n)),
                re(Mf, ()=>n.id)
            ])), [
                Lr(Xa)
            ]);
        }
        $transaction(n, i) {
            let o;
            typeof n == "function" ? this._engineConfig.adapter?.adapterName === "@prisma/adapter-d1" ? o = ()=>{
                throw new Error("Cloudflare D1 does not support interactive transactions. We recommend you to refactor your queries with that limitation in mind, and use batch transactions with `prisma.$transactions([])` where applicable.");
            } : o = ()=>this._transactionWithCallback({
                    callback: n,
                    options: i
                }) : o = ()=>this._transactionWithArray({
                    promises: n,
                    options: i
                });
            let s = {
                name: "transaction",
                attributes: {
                    method: "$transaction"
                }
            };
            return this._tracingHelper.runInChildSpan(s, o);
        }
        _request(n) {
            n.otelParentCtx = this._tracingHelper.getActiveContext();
            let i = n.middlewareArgsMapper ?? Lf, o = {
                args: i.requestArgsToMiddlewareArgs(n.args),
                dataPath: n.dataPath,
                runInTransaction: !!n.transaction,
                action: n.action,
                model: n.model
            }, s = {
                middleware: {
                    name: "middleware",
                    middleware: !0,
                    attributes: {
                        method: "$use"
                    },
                    active: !1
                },
                operation: {
                    name: "operation",
                    attributes: {
                        method: o.action,
                        model: o.model,
                        name: o.model ? `${o.model}.${o.action}` : o.action
                    }
                }
            }, a = -1, l = async (u)=>{
                let c = this._middlewares.get(++a);
                if (c) return this._tracingHelper.runInChildSpan(s.middleware, (I)=>c(u, (P)=>(I?.end(), l(P))));
                let { runInTransaction: p, args: d, ...f } = u, g = {
                    ...n,
                    ...f
                };
                d && (g.args = i.middlewareArgsToRequestArgs(d)), n.transaction !== void 0 && p === !1 && delete g.transaction;
                let h = await nl(this, g);
                return g.model ? Za({
                    result: h,
                    modelName: g.model,
                    args: g.args,
                    extensions: this._extensions,
                    runtimeDataModel: this._runtimeDataModel,
                    globalOmit: this._globalOmit
                }) : h;
            };
            return this._tracingHelper.runInChildSpan(s.operation, ()=>new pu.AsyncResource("prisma-client-request").runInAsyncScope(()=>l(o)));
        }
        async _executeRequest({ args: n, clientMethod: i, dataPath: o, callsite: s, action: a, model: l, argsMapper: u, transaction: c, unpacker: p, otelParentCtx: d, customDataProxyFetch: f }) {
            try {
                n = u ? u(n) : n;
                let g = {
                    name: "serialize"
                }, h = this._tracingHelper.runInChildSpan(g, ()=>Dn({
                        modelName: l,
                        runtimeDataModel: this._runtimeDataModel,
                        action: a,
                        args: n,
                        clientMethod: i,
                        callsite: s,
                        extensions: this._extensions,
                        errorFormat: this._errorFormat,
                        clientVersion: this._clientVersion,
                        previewFeatures: this._previewFeatures,
                        globalOmit: this._globalOmit
                    }));
                return N.enabled("prisma:client") && (rr("Prisma Client call:"), rr(`prisma.${i}(${Ma(n)})`), rr("Generated request:"), rr(JSON.stringify(h, null, 2) + `
`)), c?.kind === "batch" && await c.lock, this._requestHandler.request({
                    protocolQuery: h,
                    modelName: l,
                    action: a,
                    clientMethod: i,
                    dataPath: o,
                    callsite: s,
                    args: n,
                    extensions: this._extensions,
                    transaction: c,
                    unpacker: p,
                    otelParentCtx: d,
                    otelChildCtx: this._tracingHelper.getActiveContext(),
                    globalOmit: this._globalOmit,
                    customDataProxyFetch: f
                });
            } catch (g) {
                throw g.clientVersion = this._clientVersion, g;
            }
        }
        $metrics = new Fr(this);
        _hasPreviewFlag(n) {
            return !!this._engineConfig.previewFeatures?.includes(n);
        }
        $applyPendingMigrations() {
            return this._engine.applyPendingMigrations();
        }
        $extends = Ka;
    }
    return r;
}
function uu(e, r) {
    return qf(e) ? [
        new oe(e, r),
        Ql
    ] : [
        e,
        Gl
    ];
}
function qf(e) {
    return Array.isArray(e) && Array.isArray(e.raw);
}
var jf = new Set([
    "toJSON",
    "$$typeof",
    "asymmetricMatch",
    Symbol.iterator,
    Symbol.toStringTag,
    Symbol.isConcatSpreadable,
    Symbol.toPrimitive
]);
function gu(e) {
    return new Proxy(e, {
        get (r, t) {
            if (t in r) return r[t];
            if (!jf.has(t)) throw new TypeError(`Invalid enum value: ${String(t)}`);
        }
    });
}
function hu(e) {
    it(e, {
        conflictCheck: "warn"
    });
}
0 && (module.exports = {
    DMMF,
    Debug,
    Decimal,
    Extensions,
    MetricsClient,
    PrismaClientInitializationError,
    PrismaClientKnownRequestError,
    PrismaClientRustPanicError,
    PrismaClientUnknownRequestError,
    PrismaClientValidationError,
    Public,
    Sql,
    createParam,
    defineDmmfProperty,
    deserializeJsonResponse,
    deserializeRawResult,
    dmmfToRuntimeDataModel,
    empty,
    getPrismaClient,
    getRuntime,
    join,
    makeStrictEnum,
    makeTypedQueryFactory,
    objectEnumValues,
    raw,
    serializeJsonQuery,
    skip,
    sqltag,
    warnEnvConflicts,
    warnOnce
}); /*! Bundled license information:

decimal.js/decimal.mjs:
  (*!
   *  decimal.js v10.5.0
   *  An arbitrary-precision Decimal type for JavaScript.
   *  https://github.com/MikeMcl/decimal.js
   *  Copyright (c) 2025 Michael Mclaughlin <M8ch88l@gmail.com>
   *  MIT Licence
   *)
*/  //# sourceMappingURL=library.js.map
}}),
"[externals]/path [external] (path, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}}),
"[externals]/fs [external] (fs, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}}),
"[project]/app/generated/prisma/index.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
/* !!! This is code generated by Prisma. Do not edit directly. !!!
/* eslint-disable */ Object.defineProperty(exports, "__esModule", {
    value: true
});
const { PrismaClientKnownRequestError, PrismaClientUnknownRequestError, PrismaClientRustPanicError, PrismaClientInitializationError, PrismaClientValidationError, getPrismaClient, sqltag, empty, join, raw, skip, Decimal, Debug, objectEnumValues, makeStrictEnum, Extensions, warnOnce, defineDmmfProperty, Public, getRuntime, createParam } = __turbopack_context__.r("[project]/app/generated/prisma/runtime/library.js [app-ssr] (ecmascript)");
const Prisma = {};
exports.Prisma = Prisma;
exports.$Enums = {};
/**
 * Prisma Client JS version: 6.7.0
 * Query Engine version: 3cff47a7f5d65c3ea74883f1d736e41d68ce91ed
 */ Prisma.prismaVersion = {
    client: "6.7.0",
    engine: "3cff47a7f5d65c3ea74883f1d736e41d68ce91ed"
};
Prisma.PrismaClientKnownRequestError = PrismaClientKnownRequestError;
Prisma.PrismaClientUnknownRequestError = PrismaClientUnknownRequestError;
Prisma.PrismaClientRustPanicError = PrismaClientRustPanicError;
Prisma.PrismaClientInitializationError = PrismaClientInitializationError;
Prisma.PrismaClientValidationError = PrismaClientValidationError;
Prisma.Decimal = Decimal;
/**
 * Re-export of sql-template-tag
 */ Prisma.sql = sqltag;
Prisma.empty = empty;
Prisma.join = join;
Prisma.raw = raw;
Prisma.validator = Public.validator;
/**
* Extensions
*/ Prisma.getExtensionContext = Extensions.getExtensionContext;
Prisma.defineExtension = Extensions.defineExtension;
/**
 * Shorthand utilities for JSON filtering
 */ Prisma.DbNull = objectEnumValues.instances.DbNull;
Prisma.JsonNull = objectEnumValues.instances.JsonNull;
Prisma.AnyNull = objectEnumValues.instances.AnyNull;
Prisma.NullTypes = {
    DbNull: objectEnumValues.classes.DbNull,
    JsonNull: objectEnumValues.classes.JsonNull,
    AnyNull: objectEnumValues.classes.AnyNull
};
const path = __turbopack_context__.r("[externals]/path [external] (path, cjs)");
/**
 * Enums
 */ exports.Prisma.TransactionIsolationLevel = makeStrictEnum({
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
});
exports.Prisma.UserScalarFieldEnum = {
    id: 'id',
    email: 'email',
    phone: 'phone',
    passwordHash: 'passwordHash',
    role: 'role',
    isActive: 'isActive',
    lastLoginAt: 'lastLoginAt',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
};
exports.Prisma.CitizenProfileScalarFieldEnum = {
    id: 'id',
    userId: 'userId',
    fullName: 'fullName',
    phone: 'phone',
    address: 'address',
    aadhaarNumber: 'aadhaarNumber',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
};
exports.Prisma.OfficerProfileScalarFieldEnum = {
    id: 'id',
    userId: 'userId',
    fullName: 'fullName',
    designation: 'designation',
    department: 'department',
    officeLocation: 'officeLocation',
    isAvailable: 'isAvailable',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
};
exports.Prisma.ServiceCategoryScalarFieldEnum = {
    id: 'id',
    name: 'name',
    description: 'description',
    slaDays: 'slaDays',
    isActive: 'isActive',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
};
exports.Prisma.ApplicationScalarFieldEnum = {
    id: 'id',
    rrNumber: 'rrNumber',
    serviceCategoryId: 'serviceCategoryId',
    citizenId: 'citizenId',
    status: 'status',
    currentHolderId: 'currentHolderId',
    submittedAt: 'submittedAt',
    validatedAt: 'validatedAt',
    completedAt: 'completedAt',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
};
exports.Prisma.ApplicationWorkflowScalarFieldEnum = {
    id: 'id',
    applicationId: 'applicationId',
    fromStatus: 'fromStatus',
    toStatus: 'toStatus',
    changedById: 'changedById',
    comments: 'comments',
    createdAt: 'createdAt'
};
exports.Prisma.ApplicationValidationScalarFieldEnum = {
    id: 'id',
    applicationId: 'applicationId',
    validatedById: 'validatedById',
    rrNumber: 'rrNumber',
    isDocumentsComplete: 'isDocumentsComplete',
    isEligibilityVerified: 'isEligibilityVerified',
    validationNotes: 'validationNotes',
    createdAt: 'createdAt'
};
exports.Prisma.OfficerAssignmentScalarFieldEnum = {
    id: 'id',
    applicationId: 'applicationId',
    assignedById: 'assignedById',
    assignedToId: 'assignedToId',
    expectedCompletionDate: 'expectedCompletionDate',
    priority: 'priority',
    instructions: 'instructions',
    createdAt: 'createdAt'
};
exports.Prisma.DocumentScalarFieldEnum = {
    id: 'id',
    applicationId: 'applicationId',
    documentType: 'documentType',
    fileName: 'fileName',
    filePath: 'filePath',
    fileSize: 'fileSize',
    uploadedById: 'uploadedById',
    isVerified: 'isVerified',
    verifiedById: 'verifiedById',
    verificationNotes: 'verificationNotes',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
};
exports.Prisma.DocumentRequestScalarFieldEnum = {
    id: 'id',
    applicationId: 'applicationId',
    requestedById: 'requestedById',
    documentType: 'documentType',
    reason: 'reason',
    dueDate: 'dueDate',
    isCompleted: 'isCompleted',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
};
exports.Prisma.NotificationScalarFieldEnum = {
    id: 'id',
    userId: 'userId',
    notificationType: 'notificationType',
    applicationId: 'applicationId',
    title: 'title',
    message: 'message',
    isRead: 'isRead',
    readAt: 'readAt',
    createdAt: 'createdAt'
};
exports.Prisma.ApplicationAuditLogScalarFieldEnum = {
    id: 'id',
    applicationId: 'applicationId',
    action: 'action',
    performedById: 'performedById',
    oldValues: 'oldValues',
    newValues: 'newValues',
    ipAddress: 'ipAddress',
    createdAt: 'createdAt'
};
exports.Prisma.DailyReportScalarFieldEnum = {
    id: 'id',
    reportDate: 'reportDate',
    totalApplications: 'totalApplications',
    pendingValidation: 'pendingValidation',
    inProgress: 'inProgress',
    completed: 'completed',
    avgProcessingTime: 'avgProcessingTime',
    createdAt: 'createdAt'
};
exports.Prisma.SystemSettingScalarFieldEnum = {
    id: 'id',
    settingKey: 'settingKey',
    settingValue: 'settingValue',
    description: 'description',
    isPublic: 'isPublic',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
};
exports.Prisma.VerificationTokenScalarFieldEnum = {
    id: 'id',
    identifier: 'identifier',
    token: 'token',
    expires: 'expires',
    type: 'type'
};
exports.Prisma.SortOrder = {
    asc: 'asc',
    desc: 'desc'
};
exports.Prisma.NullableJsonNullValueInput = {
    DbNull: Prisma.DbNull,
    JsonNull: Prisma.JsonNull
};
exports.Prisma.QueryMode = {
    default: 'default',
    insensitive: 'insensitive'
};
exports.Prisma.NullsOrder = {
    first: 'first',
    last: 'last'
};
exports.Prisma.JsonNullValueFilter = {
    DbNull: Prisma.DbNull,
    JsonNull: Prisma.JsonNull,
    AnyNull: Prisma.AnyNull
};
exports.UserRole = exports.$Enums.UserRole = {
    CITIZEN: 'CITIZEN',
    FRONT_DESK: 'FRONT_DESK',
    DC: 'DC',
    ADC: 'ADC',
    RO: 'RO',
    ADMIN: 'ADMIN',
    SUPER_ADMIN: 'SUPER_ADMIN'
};
exports.ApplicationStatus = exports.$Enums.ApplicationStatus = {
    DRAFT: 'DRAFT',
    PENDING: 'PENDING',
    VALIDATED: 'VALIDATED',
    IN_PROGRESS: 'IN_PROGRESS',
    APPROVED: 'APPROVED',
    REJECTED: 'REJECTED',
    COMPLETED: 'COMPLETED'
};
exports.DocumentType = exports.$Enums.DocumentType = {
    ID_PROOF: 'ID_PROOF',
    ADDRESS_PROOF: 'ADDRESS_PROOF',
    APPLICATION_FORM: 'APPLICATION_FORM',
    SUPPORTING_DOCUMENT: 'SUPPORTING_DOCUMENT',
    PAYMENT_RECEIPT: 'PAYMENT_RECEIPT'
};
exports.NotificationType = exports.$Enums.NotificationType = {
    APPLICATION_SUBMITTED: 'APPLICATION_SUBMITTED',
    STATUS_CHANGED: 'STATUS_CHANGED',
    DOCUMENT_REQUESTED: 'DOCUMENT_REQUESTED',
    PAYMENT_REQUIRED: 'PAYMENT_REQUIRED'
};
exports.Prisma.ModelName = {
    User: 'User',
    CitizenProfile: 'CitizenProfile',
    OfficerProfile: 'OfficerProfile',
    ServiceCategory: 'ServiceCategory',
    Application: 'Application',
    ApplicationWorkflow: 'ApplicationWorkflow',
    ApplicationValidation: 'ApplicationValidation',
    OfficerAssignment: 'OfficerAssignment',
    Document: 'Document',
    DocumentRequest: 'DocumentRequest',
    Notification: 'Notification',
    ApplicationAuditLog: 'ApplicationAuditLog',
    DailyReport: 'DailyReport',
    SystemSetting: 'SystemSetting',
    VerificationToken: 'VerificationToken'
};
/**
 * Create the Client
 */ const config = {
    "generator": {
        "name": "client",
        "provider": {
            "fromEnvVar": null,
            "value": "prisma-client-js"
        },
        "output": {
            "value": "C:\\Users\\NIGHTWOLF\\Documents\\district-bi\\app\\generated\\prisma",
            "fromEnvVar": null
        },
        "config": {
            "engineType": "library"
        },
        "binaryTargets": [
            {
                "fromEnvVar": null,
                "value": "windows",
                "native": true
            }
        ],
        "previewFeatures": [],
        "sourceFilePath": "C:\\Users\\NIGHTWOLF\\Documents\\district-bi\\prisma\\schema.prisma",
        "isCustomOutput": true
    },
    "relativeEnvPaths": {
        "rootEnvPath": null,
        "schemaEnvPath": "../../../.env"
    },
    "relativePath": "../../../prisma",
    "clientVersion": "6.7.0",
    "engineVersion": "3cff47a7f5d65c3ea74883f1d736e41d68ce91ed",
    "datasourceNames": [
        "db"
    ],
    "activeProvider": "postgresql",
    "inlineDatasources": {
        "db": {
            "url": {
                "fromEnvVar": "DATABASE_URL",
                "value": "postgresql://postgres:121@localhost:5432/districtbidb"
            }
        }
    },
    "inlineSchema": "// This is your Prisma schema file,\n// learn more about it in the docs: https://pris.ly/d/prisma-schema\n\n// Looking for ways to speed up your queries, or scale easily with your serverless or edge functions?\n// Try Prisma Accelerate: https://pris.ly/cli/accelerate-init\n\ngenerator client {\n  provider = \"prisma-client-js\"\n  output   = \"../app/generated/prisma\"\n}\n\ndatasource db {\n  provider = \"postgresql\"\n  url      = env(\"DATABASE_URL\")\n}\n\nenum UserRole {\n  CITIZEN\n  FRONT_DESK // Validates applications and generates RR numbers\n  DC // District Collector\n  ADC // Additional District Collector\n  RO // Revenue Officer\n  ADMIN\n  SUPER_ADMIN\n}\n\nenum ApplicationStatus {\n  DRAFT // Citizen is still filling the form\n  PENDING // Waiting for front desk validation\n  VALIDATED // RR number assigned\n  IN_PROGRESS // With assigned officer\n  APPROVED // Final approval\n  REJECTED // Application rejected\n  COMPLETED // Process finished\n}\n\nenum DocumentType {\n  ID_PROOF\n  ADDRESS_PROOF\n  APPLICATION_FORM\n  SUPPORTING_DOCUMENT\n  PAYMENT_RECEIPT\n}\n\nenum NotificationType {\n  APPLICATION_SUBMITTED\n  STATUS_CHANGED\n  DOCUMENT_REQUESTED\n  PAYMENT_REQUIRED\n}\n\nmodel User {\n  id           String    @id @default(uuid())\n  email        String    @unique\n  phone        String?   @unique\n  passwordHash String?\n  role         UserRole  @default(CITIZEN)\n  isActive     Boolean   @default(true)\n  lastLoginAt  DateTime?\n  createdAt    DateTime  @default(now())\n  updatedAt    DateTime  @updatedAt\n\n  // Relations\n  citizenProfile      CitizenProfile?\n  officerProfile      OfficerProfile?\n  applications        Application[]           @relation(\"CitizenApplications\")\n  currentHolderFiles  Application[]           @relation(\"CurrentHolder\")\n  workflowChanges     ApplicationWorkflow[]   @relation(\"ChangedBy\")\n  validations         ApplicationValidation[] @relation(\"ValidatedBy\")\n  verifiedDocuments   Document[]              @relation(\"VerifiedBy\")\n  uploadedDocuments   Document[]              @relation(\"UploadedBy\")\n  assignmentsGiven    OfficerAssignment[]     @relation(\"AssignedBy\")\n  assignmentsReceived OfficerAssignment[]     @relation(\"AssignedTo\")\n  documentRequests    DocumentRequest[]       @relation(\"RequestedBy\")\n  notifications       Notification[]\n  auditLogs           ApplicationAuditLog[]   @relation(\"PerformedBy\")\n\n  @@map(\"users\")\n}\n\nmodel CitizenProfile {\n  id            String   @id @default(uuid())\n  userId        String   @unique\n  fullName      String\n  phone         String\n  address       String\n  aadhaarNumber String?\n  createdAt     DateTime @default(now())\n  updatedAt     DateTime @updatedAt\n\n  // Relations\n  user User @relation(fields: [userId], references: [id], onDelete: Cascade)\n\n  @@map(\"citizen_profiles\")\n}\n\nmodel OfficerProfile {\n  id             String   @id @default(uuid())\n  userId         String   @unique\n  fullName       String\n  designation    String\n  department     String\n  officeLocation String?\n  isAvailable    Boolean  @default(true)\n  createdAt      DateTime @default(now())\n  updatedAt      DateTime @updatedAt\n\n  // Relations\n  user User @relation(fields: [userId], references: [id], onDelete: Cascade)\n\n  @@map(\"officer_profiles\")\n}\n\nmodel ServiceCategory {\n  id          String   @id @default(uuid())\n  name        String   @unique\n  description String?\n  slaDays     Int // Service Level Agreement in days\n  isActive    Boolean  @default(true)\n  createdAt   DateTime @default(now())\n  updatedAt   DateTime @updatedAt\n\n  // Relations\n  applications Application[]\n\n  @@map(\"service_categories\")\n}\n\nmodel Application {\n  id                String            @id @default(uuid())\n  rrNumber          String?           @unique // Generated by front desk\n  serviceCategoryId String\n  citizenId         String\n  status            ApplicationStatus @default(DRAFT)\n  currentHolderId   String?\n  submittedAt       DateTime?\n  validatedAt       DateTime?\n  completedAt       DateTime?\n  createdAt         DateTime          @default(now())\n  updatedAt         DateTime          @updatedAt\n\n  // Relations\n  serviceCategory    ServiceCategory        @relation(fields: [serviceCategoryId], references: [id])\n  citizen            User                   @relation(\"CitizenApplications\", fields: [citizenId], references: [id])\n  currentHolder      User?                  @relation(\"CurrentHolder\", fields: [currentHolderId], references: [id])\n  workflow           ApplicationWorkflow[]\n  validation         ApplicationValidation?\n  officerAssignments OfficerAssignment[]\n  documents          Document[]\n  documentRequests   DocumentRequest[]\n  notifications      Notification[]\n  auditLogs          ApplicationAuditLog[]\n\n  @@map(\"applications\")\n}\n\nmodel ApplicationWorkflow {\n  id            String             @id @default(uuid())\n  applicationId String\n  fromStatus    ApplicationStatus?\n  toStatus      ApplicationStatus\n  changedById   String\n  comments      String?\n  createdAt     DateTime           @default(now())\n\n  // Relations\n  application Application @relation(fields: [applicationId], references: [id])\n  changedBy   User        @relation(\"ChangedBy\", fields: [changedById], references: [id])\n\n  @@map(\"application_workflow\")\n}\n\nmodel ApplicationValidation {\n  id                    String   @id @default(uuid())\n  applicationId         String   @unique\n  validatedById         String\n  rrNumber              String\n  isDocumentsComplete   Boolean  @default(false)\n  isEligibilityVerified Boolean  @default(false)\n  validationNotes       String?\n  createdAt             DateTime @default(now())\n\n  // Relations\n  application Application @relation(fields: [applicationId], references: [id])\n  validatedBy User        @relation(\"ValidatedBy\", fields: [validatedById], references: [id])\n\n  @@map(\"application_validations\")\n}\n\nmodel OfficerAssignment {\n  id                     String    @id @default(uuid())\n  applicationId          String\n  assignedById           String\n  assignedToId           String\n  expectedCompletionDate DateTime?\n  priority               Int       @default(2) // 1=High, 2=Medium, 3=Low\n  instructions           String?\n  createdAt              DateTime  @default(now())\n\n  // Relations\n  application Application @relation(fields: [applicationId], references: [id])\n  assignedBy  User        @relation(\"AssignedBy\", fields: [assignedById], references: [id])\n  assignedTo  User        @relation(\"AssignedTo\", fields: [assignedToId], references: [id])\n\n  @@map(\"officer_assignments\")\n}\n\nmodel Document {\n  id                String       @id @default(uuid())\n  applicationId     String\n  documentType      DocumentType\n  fileName          String\n  filePath          String\n  fileSize          Int // In bytes\n  uploadedById      String\n  isVerified        Boolean      @default(false)\n  verifiedById      String?\n  verificationNotes String?\n  createdAt         DateTime     @default(now())\n  updatedAt         DateTime     @updatedAt\n\n  // Relations\n  application Application @relation(fields: [applicationId], references: [id])\n  uploadedBy  User        @relation(\"UploadedBy\", fields: [uploadedById], references: [id])\n  verifiedBy  User?       @relation(\"VerifiedBy\", fields: [verifiedById], references: [id])\n\n  @@map(\"documents\")\n}\n\nmodel DocumentRequest {\n  id            String       @id @default(uuid())\n  applicationId String\n  requestedById String\n  documentType  DocumentType\n  reason        String?\n  dueDate       DateTime?\n  isCompleted   Boolean      @default(false)\n  createdAt     DateTime     @default(now())\n  updatedAt     DateTime     @updatedAt\n\n  // Relations\n  application Application @relation(fields: [applicationId], references: [id])\n  requestedBy User        @relation(\"RequestedBy\", fields: [requestedById], references: [id])\n\n  @@map(\"document_requests\")\n}\n\nmodel Notification {\n  id               String           @id @default(uuid())\n  userId           String\n  notificationType NotificationType\n  applicationId    String?\n  title            String\n  message          String\n  isRead           Boolean          @default(false)\n  readAt           DateTime?\n  createdAt        DateTime         @default(now())\n\n  // Relations\n  user        User         @relation(fields: [userId], references: [id])\n  application Application? @relation(fields: [applicationId], references: [id])\n\n  @@map(\"notifications\")\n}\n\nmodel ApplicationAuditLog {\n  id            String   @id @default(uuid())\n  applicationId String\n  action        String\n  performedById String\n  oldValues     Json?\n  newValues     Json?\n  ipAddress     String?\n  createdAt     DateTime @default(now())\n\n  // Relations\n  application Application @relation(fields: [applicationId], references: [id])\n  performedBy User        @relation(\"PerformedBy\", fields: [performedById], references: [id])\n\n  @@map(\"application_audit_logs\")\n}\n\nmodel DailyReport {\n  id                String   @id @default(uuid())\n  reportDate        DateTime @db.Date\n  totalApplications Int      @default(0)\n  pendingValidation Int      @default(0)\n  inProgress        Int      @default(0)\n  completed         Int      @default(0)\n  avgProcessingTime Int? // Stored in minutes\n  createdAt         DateTime @default(now())\n\n  @@map(\"daily_reports\")\n}\n\nmodel SystemSetting {\n  id           String   @id @default(uuid())\n  settingKey   String   @unique\n  settingValue String\n  description  String?\n  isPublic     Boolean  @default(false)\n  createdAt    DateTime @default(now())\n  updatedAt    DateTime @updatedAt\n\n  @@map(\"system_settings\")\n}\n\n// For handling password reset and email verification\nmodel VerificationToken {\n  id         String   @id @default(uuid())\n  identifier String\n  token      String   @unique\n  expires    DateTime\n  type       String // \"EMAIL_VERIFICATION\" or \"PASSWORD_RESET\" or \"PHONE_VERIFICATION\"\n\n  @@unique([identifier, token])\n  @@map(\"verification_tokens\")\n}\n",
    "inlineSchemaHash": "c13b0fa8d0e6122df64d36d40143e83c7ff6d09de394084b5fbf0aac2a269b80",
    "copyEngine": true
};
const fs = __turbopack_context__.r("[externals]/fs [external] (fs, cjs)");
config.dirname = __dirname;
if (!fs.existsSync(path.join(__dirname, 'schema.prisma'))) {
    const alternativePaths = [
        "app/generated/prisma",
        "generated/prisma"
    ];
    const alternativePath = alternativePaths.find((altPath)=>{
        return fs.existsSync(path.join(process.cwd(), altPath, 'schema.prisma'));
    }) ?? alternativePaths[0];
    config.dirname = path.join(process.cwd(), alternativePath);
    config.isBundled = true;
}
config.runtimeDataModel = JSON.parse("{\"models\":{\"User\":{\"dbName\":\"users\",\"schema\":null,\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"nativeType\":null,\"default\":{\"name\":\"uuid\",\"args\":[4]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"email\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":true,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"phone\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":true,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"passwordHash\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"role\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"UserRole\",\"nativeType\":null,\"default\":\"CITIZEN\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"isActive\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"Boolean\",\"nativeType\":null,\"default\":true,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"lastLoginAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DateTime\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"nativeType\":null,\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"updatedAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DateTime\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":true},{\"name\":\"citizenProfile\",\"kind\":\"object\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"CitizenProfile\",\"nativeType\":null,\"relationName\":\"CitizenProfileToUser\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"officerProfile\",\"kind\":\"object\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"OfficerProfile\",\"nativeType\":null,\"relationName\":\"OfficerProfileToUser\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"applications\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Application\",\"nativeType\":null,\"relationName\":\"CitizenApplications\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"currentHolderFiles\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Application\",\"nativeType\":null,\"relationName\":\"CurrentHolder\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"workflowChanges\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"ApplicationWorkflow\",\"nativeType\":null,\"relationName\":\"ChangedBy\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"validations\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"ApplicationValidation\",\"nativeType\":null,\"relationName\":\"ValidatedBy\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"verifiedDocuments\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Document\",\"nativeType\":null,\"relationName\":\"VerifiedBy\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"uploadedDocuments\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Document\",\"nativeType\":null,\"relationName\":\"UploadedBy\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"assignmentsGiven\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"OfficerAssignment\",\"nativeType\":null,\"relationName\":\"AssignedBy\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"assignmentsReceived\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"OfficerAssignment\",\"nativeType\":null,\"relationName\":\"AssignedTo\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"documentRequests\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DocumentRequest\",\"nativeType\":null,\"relationName\":\"RequestedBy\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"notifications\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Notification\",\"nativeType\":null,\"relationName\":\"NotificationToUser\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"auditLogs\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"ApplicationAuditLog\",\"nativeType\":null,\"relationName\":\"PerformedBy\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"CitizenProfile\":{\"dbName\":\"citizen_profiles\",\"schema\":null,\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"nativeType\":null,\"default\":{\"name\":\"uuid\",\"args\":[4]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"userId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":true,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"fullName\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"phone\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"address\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"aadhaarNumber\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"nativeType\":null,\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"updatedAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DateTime\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":true},{\"name\":\"user\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"User\",\"nativeType\":null,\"relationName\":\"CitizenProfileToUser\",\"relationFromFields\":[\"userId\"],\"relationToFields\":[\"id\"],\"relationOnDelete\":\"Cascade\",\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"OfficerProfile\":{\"dbName\":\"officer_profiles\",\"schema\":null,\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"nativeType\":null,\"default\":{\"name\":\"uuid\",\"args\":[4]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"userId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":true,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"fullName\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"designation\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"department\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"officeLocation\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"isAvailable\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"Boolean\",\"nativeType\":null,\"default\":true,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"nativeType\":null,\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"updatedAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DateTime\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":true},{\"name\":\"user\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"User\",\"nativeType\":null,\"relationName\":\"OfficerProfileToUser\",\"relationFromFields\":[\"userId\"],\"relationToFields\":[\"id\"],\"relationOnDelete\":\"Cascade\",\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"ServiceCategory\":{\"dbName\":\"service_categories\",\"schema\":null,\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"nativeType\":null,\"default\":{\"name\":\"uuid\",\"args\":[4]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"name\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":true,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"description\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"slaDays\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Int\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"isActive\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"Boolean\",\"nativeType\":null,\"default\":true,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"nativeType\":null,\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"updatedAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DateTime\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":true},{\"name\":\"applications\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Application\",\"nativeType\":null,\"relationName\":\"ApplicationToServiceCategory\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"Application\":{\"dbName\":\"applications\",\"schema\":null,\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"nativeType\":null,\"default\":{\"name\":\"uuid\",\"args\":[4]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"rrNumber\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":true,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"serviceCategoryId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"citizenId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"status\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"ApplicationStatus\",\"nativeType\":null,\"default\":\"DRAFT\",\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"currentHolderId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"submittedAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DateTime\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"validatedAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DateTime\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"completedAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DateTime\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"nativeType\":null,\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"updatedAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DateTime\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":true},{\"name\":\"serviceCategory\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"ServiceCategory\",\"nativeType\":null,\"relationName\":\"ApplicationToServiceCategory\",\"relationFromFields\":[\"serviceCategoryId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"citizen\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"User\",\"nativeType\":null,\"relationName\":\"CitizenApplications\",\"relationFromFields\":[\"citizenId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"currentHolder\",\"kind\":\"object\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"User\",\"nativeType\":null,\"relationName\":\"CurrentHolder\",\"relationFromFields\":[\"currentHolderId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"workflow\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"ApplicationWorkflow\",\"nativeType\":null,\"relationName\":\"ApplicationToApplicationWorkflow\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"validation\",\"kind\":\"object\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"ApplicationValidation\",\"nativeType\":null,\"relationName\":\"ApplicationToApplicationValidation\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"officerAssignments\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"OfficerAssignment\",\"nativeType\":null,\"relationName\":\"ApplicationToOfficerAssignment\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"documents\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Document\",\"nativeType\":null,\"relationName\":\"ApplicationToDocument\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"documentRequests\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DocumentRequest\",\"nativeType\":null,\"relationName\":\"ApplicationToDocumentRequest\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"notifications\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Notification\",\"nativeType\":null,\"relationName\":\"ApplicationToNotification\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"auditLogs\",\"kind\":\"object\",\"isList\":true,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"ApplicationAuditLog\",\"nativeType\":null,\"relationName\":\"ApplicationToApplicationAuditLog\",\"relationFromFields\":[],\"relationToFields\":[],\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"ApplicationWorkflow\":{\"dbName\":\"application_workflow\",\"schema\":null,\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"nativeType\":null,\"default\":{\"name\":\"uuid\",\"args\":[4]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"applicationId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"fromStatus\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"ApplicationStatus\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"toStatus\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"ApplicationStatus\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"changedById\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"comments\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"nativeType\":null,\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"application\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Application\",\"nativeType\":null,\"relationName\":\"ApplicationToApplicationWorkflow\",\"relationFromFields\":[\"applicationId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"changedBy\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"User\",\"nativeType\":null,\"relationName\":\"ChangedBy\",\"relationFromFields\":[\"changedById\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"ApplicationValidation\":{\"dbName\":\"application_validations\",\"schema\":null,\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"nativeType\":null,\"default\":{\"name\":\"uuid\",\"args\":[4]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"applicationId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":true,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"validatedById\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"rrNumber\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"isDocumentsComplete\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"Boolean\",\"nativeType\":null,\"default\":false,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"isEligibilityVerified\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"Boolean\",\"nativeType\":null,\"default\":false,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"validationNotes\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"nativeType\":null,\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"application\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Application\",\"nativeType\":null,\"relationName\":\"ApplicationToApplicationValidation\",\"relationFromFields\":[\"applicationId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"validatedBy\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"User\",\"nativeType\":null,\"relationName\":\"ValidatedBy\",\"relationFromFields\":[\"validatedById\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"OfficerAssignment\":{\"dbName\":\"officer_assignments\",\"schema\":null,\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"nativeType\":null,\"default\":{\"name\":\"uuid\",\"args\":[4]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"applicationId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"assignedById\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"assignedToId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"expectedCompletionDate\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DateTime\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"priority\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"Int\",\"nativeType\":null,\"default\":2,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"instructions\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"nativeType\":null,\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"application\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Application\",\"nativeType\":null,\"relationName\":\"ApplicationToOfficerAssignment\",\"relationFromFields\":[\"applicationId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"assignedBy\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"User\",\"nativeType\":null,\"relationName\":\"AssignedBy\",\"relationFromFields\":[\"assignedById\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"assignedTo\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"User\",\"nativeType\":null,\"relationName\":\"AssignedTo\",\"relationFromFields\":[\"assignedToId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"Document\":{\"dbName\":\"documents\",\"schema\":null,\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"nativeType\":null,\"default\":{\"name\":\"uuid\",\"args\":[4]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"applicationId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"documentType\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DocumentType\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"fileName\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"filePath\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"fileSize\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Int\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"uploadedById\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"isVerified\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"Boolean\",\"nativeType\":null,\"default\":false,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"verifiedById\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"verificationNotes\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"nativeType\":null,\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"updatedAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DateTime\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":true},{\"name\":\"application\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Application\",\"nativeType\":null,\"relationName\":\"ApplicationToDocument\",\"relationFromFields\":[\"applicationId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"uploadedBy\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"User\",\"nativeType\":null,\"relationName\":\"UploadedBy\",\"relationFromFields\":[\"uploadedById\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"verifiedBy\",\"kind\":\"object\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"User\",\"nativeType\":null,\"relationName\":\"VerifiedBy\",\"relationFromFields\":[\"verifiedById\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"DocumentRequest\":{\"dbName\":\"document_requests\",\"schema\":null,\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"nativeType\":null,\"default\":{\"name\":\"uuid\",\"args\":[4]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"applicationId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"requestedById\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"documentType\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DocumentType\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"reason\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"dueDate\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DateTime\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"isCompleted\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"Boolean\",\"nativeType\":null,\"default\":false,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"nativeType\":null,\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"updatedAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DateTime\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":true},{\"name\":\"application\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Application\",\"nativeType\":null,\"relationName\":\"ApplicationToDocumentRequest\",\"relationFromFields\":[\"applicationId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"requestedBy\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"User\",\"nativeType\":null,\"relationName\":\"RequestedBy\",\"relationFromFields\":[\"requestedById\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"Notification\":{\"dbName\":\"notifications\",\"schema\":null,\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"nativeType\":null,\"default\":{\"name\":\"uuid\",\"args\":[4]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"userId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"notificationType\",\"kind\":\"enum\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"NotificationType\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"applicationId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"title\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"message\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"isRead\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"Boolean\",\"nativeType\":null,\"default\":false,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"readAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DateTime\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"nativeType\":null,\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"user\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"User\",\"nativeType\":null,\"relationName\":\"NotificationToUser\",\"relationFromFields\":[\"userId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"application\",\"kind\":\"object\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Application\",\"nativeType\":null,\"relationName\":\"ApplicationToNotification\",\"relationFromFields\":[\"applicationId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"ApplicationAuditLog\":{\"dbName\":\"application_audit_logs\",\"schema\":null,\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"nativeType\":null,\"default\":{\"name\":\"uuid\",\"args\":[4]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"applicationId\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"action\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"performedById\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":true,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"oldValues\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Json\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"newValues\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Json\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"ipAddress\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"nativeType\":null,\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"application\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Application\",\"nativeType\":null,\"relationName\":\"ApplicationToApplicationAuditLog\",\"relationFromFields\":[\"applicationId\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"performedBy\",\"kind\":\"object\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"User\",\"nativeType\":null,\"relationName\":\"PerformedBy\",\"relationFromFields\":[\"performedById\"],\"relationToFields\":[\"id\"],\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"DailyReport\":{\"dbName\":\"daily_reports\",\"schema\":null,\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"nativeType\":null,\"default\":{\"name\":\"uuid\",\"args\":[4]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"reportDate\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DateTime\",\"nativeType\":[\"Date\",[]],\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"totalApplications\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"Int\",\"nativeType\":null,\"default\":0,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"pendingValidation\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"Int\",\"nativeType\":null,\"default\":0,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"inProgress\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"Int\",\"nativeType\":null,\"default\":0,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"completed\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"Int\",\"nativeType\":null,\"default\":0,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"avgProcessingTime\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"Int\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"nativeType\":null,\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"SystemSetting\":{\"dbName\":\"system_settings\",\"schema\":null,\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"nativeType\":null,\"default\":{\"name\":\"uuid\",\"args\":[4]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"settingKey\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":true,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"settingValue\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"description\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":false,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"isPublic\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"Boolean\",\"nativeType\":null,\"default\":false,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"createdAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"DateTime\",\"nativeType\":null,\"default\":{\"name\":\"now\",\"args\":[]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"updatedAt\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DateTime\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":true}],\"primaryKey\":null,\"uniqueFields\":[],\"uniqueIndexes\":[],\"isGenerated\":false},\"VerificationToken\":{\"dbName\":\"verification_tokens\",\"schema\":null,\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":true,\"isReadOnly\":false,\"hasDefaultValue\":true,\"type\":\"String\",\"nativeType\":null,\"default\":{\"name\":\"uuid\",\"args\":[4]},\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"identifier\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"token\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":true,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"expires\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"DateTime\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false},{\"name\":\"type\",\"kind\":\"scalar\",\"isList\":false,\"isRequired\":true,\"isUnique\":false,\"isId\":false,\"isReadOnly\":false,\"hasDefaultValue\":false,\"type\":\"String\",\"nativeType\":null,\"isGenerated\":false,\"isUpdatedAt\":false}],\"primaryKey\":null,\"uniqueFields\":[[\"identifier\",\"token\"]],\"uniqueIndexes\":[{\"name\":null,\"fields\":[\"identifier\",\"token\"]}],\"isGenerated\":false}},\"enums\":{\"UserRole\":{\"values\":[{\"name\":\"CITIZEN\",\"dbName\":null},{\"name\":\"FRONT_DESK\",\"dbName\":null},{\"name\":\"DC\",\"dbName\":null},{\"name\":\"ADC\",\"dbName\":null},{\"name\":\"RO\",\"dbName\":null},{\"name\":\"ADMIN\",\"dbName\":null},{\"name\":\"SUPER_ADMIN\",\"dbName\":null}],\"dbName\":null},\"ApplicationStatus\":{\"values\":[{\"name\":\"DRAFT\",\"dbName\":null},{\"name\":\"PENDING\",\"dbName\":null},{\"name\":\"VALIDATED\",\"dbName\":null},{\"name\":\"IN_PROGRESS\",\"dbName\":null},{\"name\":\"APPROVED\",\"dbName\":null},{\"name\":\"REJECTED\",\"dbName\":null},{\"name\":\"COMPLETED\",\"dbName\":null}],\"dbName\":null},\"DocumentType\":{\"values\":[{\"name\":\"ID_PROOF\",\"dbName\":null},{\"name\":\"ADDRESS_PROOF\",\"dbName\":null},{\"name\":\"APPLICATION_FORM\",\"dbName\":null},{\"name\":\"SUPPORTING_DOCUMENT\",\"dbName\":null},{\"name\":\"PAYMENT_RECEIPT\",\"dbName\":null}],\"dbName\":null},\"NotificationType\":{\"values\":[{\"name\":\"APPLICATION_SUBMITTED\",\"dbName\":null},{\"name\":\"STATUS_CHANGED\",\"dbName\":null},{\"name\":\"DOCUMENT_REQUESTED\",\"dbName\":null},{\"name\":\"PAYMENT_REQUIRED\",\"dbName\":null}],\"dbName\":null}},\"types\":{}}");
defineDmmfProperty(exports.Prisma, config.runtimeDataModel);
config.engineWasm = undefined;
config.compilerWasm = undefined;
const { warnEnvConflicts } = __turbopack_context__.r("[project]/app/generated/prisma/runtime/library.js [app-ssr] (ecmascript)");
warnEnvConflicts({
    rootEnvPath: config.relativeEnvPaths.rootEnvPath && path.resolve(config.dirname, config.relativeEnvPaths.rootEnvPath),
    schemaEnvPath: config.relativeEnvPaths.schemaEnvPath && path.resolve(config.dirname, config.relativeEnvPaths.schemaEnvPath)
});
const PrismaClient = getPrismaClient(config);
exports.PrismaClient = PrismaClient;
Object.assign(exports, Prisma);
// file annotations for bundling tools to include these files
path.join(__dirname, "query_engine-windows.dll.node");
path.join(process.cwd(), "app/generated/prisma/query_engine-windows.dll.node");
// file annotations for bundling tools to include these files
path.join(__dirname, "schema.prisma");
path.join(process.cwd(), "app/generated/prisma/schema.prisma");
}}),
"[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>MobileSidebar)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/react/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$house$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Home$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/house.js [app-ssr] (ecmascript) <export default as Home>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/file-text.js [app-ssr] (ecmascript) <export default as FileText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/bell.js [app-ssr] (ecmascript) <export default as Bell>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/users.js [app-ssr] (ecmascript) <export default as Users>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/settings.js [app-ssr] (ecmascript) <export default as Settings>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$log$2d$out$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__LogOut$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/log-out.js [app-ssr] (ecmascript) <export default as LogOut>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/user.js [app-ssr] (ecmascript) <export default as User>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clipboard$2d$list$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ClipboardList$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/clipboard-list.js [app-ssr] (ecmascript) <export default as ClipboardList>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$help$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__HelpCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-help.js [app-ssr] (ecmascript) <export default as HelpCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$sheet$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/sheet.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$separator$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/separator.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/badge.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/generated/prisma/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
function MobileSidebar() {
    const { data: session } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSession"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    const citizenLinks = [
        {
            name: "Dashboard",
            href: "/dashboard",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$house$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Home$3e$__["Home"]
        },
        {
            name: "Applications",
            href: "/dashboard/applications",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__["FileText"]
        },
        {
            name: "Notifications",
            href: "/notifications",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__["Bell"],
            badge: 3
        },
        {
            name: "Help & Support",
            href: "/help",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$help$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__HelpCircle$3e$__["HelpCircle"]
        }
    ];
    const officerLinks = [
        {
            name: "Dashboard",
            href: "/dashboard",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$house$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Home$3e$__["Home"]
        },
        {
            name: "Applications",
            href: "/applications",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__["FileText"]
        },
        {
            name: "Assigned Cases",
            href: "/officer/assignments",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clipboard$2d$list$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ClipboardList$3e$__["ClipboardList"]
        },
        {
            name: "Notifications",
            href: "/notifications",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__["Bell"],
            badge: 3
        },
        {
            name: "Help & Support",
            href: "/help",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$help$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__HelpCircle$3e$__["HelpCircle"]
        }
    ];
    const adminLinks = [
        {
            name: "Dashboard",
            href: "/dashboard",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$house$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Home$3e$__["Home"]
        },
        {
            name: "Applications",
            href: "/applications",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__["FileText"]
        },
        {
            name: "User Management",
            href: "/admin/users",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"]
        },
        {
            name: "System Settings",
            href: "/admin/settings",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings$3e$__["Settings"]
        },
        {
            name: "Notifications",
            href: "/notifications",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__["Bell"],
            badge: 3
        },
        {
            name: "Help & Support",
            href: "/help",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$help$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__HelpCircle$3e$__["HelpCircle"]
        }
    ];
    const getLinks = ()=>{
        switch(session?.user?.role){
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].CITIZEN:
                return citizenLinks;
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].FRONT_DESK:
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].DC:
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].ADC:
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].RO:
                return officerLinks;
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].ADMIN:
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].SUPER_ADMIN:
                return adminLinks;
            default:
                return citizenLinks;
        }
    };
    const getRoleColor = ()=>{
        switch(session?.user?.role){
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].CITIZEN:
                return "bg-blue-600";
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].FRONT_DESK:
                return "bg-green-600";
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].DC:
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].ADC:
                return "bg-purple-600";
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].RO:
                return "bg-amber-600";
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].ADMIN:
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].SUPER_ADMIN:
                return "bg-red-600";
            default:
                return "bg-blue-600";
        }
    };
    const getRoleName = ()=>{
        if (!session?.user?.role) return "User";
        return session.user.role.replace("_", " ");
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$sheet$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SheetContent"], {
        side: "left",
        className: "w-72 p-0 max-w-full",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "h-full flex flex-col",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$sheet$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SheetHeader"], {
                    className: "p-6 border-b",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `h-10 w-10 ${getRoleColor()} rounded-md flex items-center justify-center text-white font-bold mr-3`,
                                children: "GP"
                            }, void 0, false, {
                                fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                                lineNumber: 111,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$sheet$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SheetTitle"], {
                                        className: "text-lg",
                                        children: "District Portal"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                                        lineNumber: 117,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$sheet$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SheetDescription"], {
                                        className: "text-sm",
                                        children: [
                                            getRoleName(),
                                            " Dashboard"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                                        lineNumber: 118,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                                lineNumber: 116,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                        lineNumber: 110,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                    lineNumber: 109,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-1 overflow-auto py-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "px-3 py-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mb-2 px-4 py-1.5 text-xs font-medium text-gray-500 uppercase",
                                    children: "Main Navigation"
                                }, void 0, false, {
                                    fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                                    lineNumber: 127,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-1",
                                    children: getLinks().map((link)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$sheet$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SheetClose"], {
                                            asChild: true,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                                variant: pathname === link.href ? "secondary" : "ghost",
                                                className: `w-full justify-start ${pathname === link.href ? "bg-blue-50 text-blue-700 hover:bg-blue-100" : ""}`,
                                                asChild: true,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                    href: link.href,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(link.icon, {
                                                            className: "h-4 w-4 mr-3"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                                                            lineNumber: 143,
                                                            columnNumber: 23
                                                        }, this),
                                                        link.name,
                                                        link.badge && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Badge"], {
                                                            variant: "destructive",
                                                            className: "ml-auto",
                                                            children: link.badge
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                                                            lineNumber: 146,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                                                    lineNumber: 142,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                                                lineNumber: 133,
                                                columnNumber: 19
                                            }, this)
                                        }, link.name, false, {
                                            fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                                            lineNumber: 132,
                                            columnNumber: 17
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                                    lineNumber: 130,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                            lineNumber: 126,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$separator$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Separator"], {
                            className: "my-2"
                        }, void 0, false, {
                            fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                            lineNumber: 157,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "px-3 py-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mb-2 px-4 py-1.5 text-xs font-medium text-gray-500 uppercase",
                                    children: "Account"
                                }, void 0, false, {
                                    fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                                    lineNumber: 160,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$sheet$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SheetClose"], {
                                            asChild: true,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                                variant: "ghost",
                                                className: "w-full justify-start",
                                                asChild: true,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                    href: "/profile",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__["User"], {
                                                            className: "h-4 w-4 mr-3"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                                                            lineNumber: 171,
                                                            columnNumber: 21
                                                        }, this),
                                                        "Profile"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                                                    lineNumber: 170,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                                                lineNumber: 165,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                                            lineNumber: 164,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$sheet$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SheetClose"], {
                                            asChild: true,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                                variant: "ghost",
                                                className: "w-full justify-start",
                                                asChild: true,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                    href: "/settings",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings$3e$__["Settings"], {
                                                            className: "h-4 w-4 mr-3"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                                                            lineNumber: 183,
                                                            columnNumber: 21
                                                        }, this),
                                                        "Settings"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                                                    lineNumber: 182,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                                                lineNumber: 177,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                                            lineNumber: 176,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                                    lineNumber: 163,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                            lineNumber: 159,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                    lineNumber: 125,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-4 border-t",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                        variant: "outline",
                        className: "w-full justify-start text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700",
                        onClick: ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["signOut"])({
                                callbackUrl: "/login?expired=true"
                            }),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$log$2d$out$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__LogOut$3e$__["LogOut"], {
                                className: "h-4 w-4 mr-3"
                            }, void 0, false, {
                                fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                                lineNumber: 198,
                                columnNumber: 13
                            }, this),
                            "Sign Out"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                        lineNumber: 193,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
                    lineNumber: 192,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
            lineNumber: 108,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx",
        lineNumber: 107,
        columnNumber: 5
    }, this);
}
}}),
"[project]/components/ui/avatar.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Avatar": (()=>Avatar),
    "AvatarFallback": (()=>AvatarFallback),
    "AvatarImage": (()=>AvatarImage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$avatar$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-avatar/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
function Avatar({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$avatar$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"], {
        "data-slot": "avatar",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("relative flex size-8 shrink-0 overflow-hidden rounded-full", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/avatar.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
function AvatarImage({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$avatar$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Image"], {
        "data-slot": "avatar-image",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("aspect-square size-full", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/avatar.tsx",
        lineNumber: 29,
        columnNumber: 5
    }, this);
}
function AvatarFallback({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$avatar$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fallback"], {
        "data-slot": "avatar-fallback",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("bg-muted flex size-full items-center justify-center rounded-full", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/avatar.tsx",
        lineNumber: 42,
        columnNumber: 5
    }, this);
}
;
}}),
"[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>DesktopSidebar)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/react/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$house$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Home$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/house.js [app-ssr] (ecmascript) <export default as Home>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/file-text.js [app-ssr] (ecmascript) <export default as FileText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/bell.js [app-ssr] (ecmascript) <export default as Bell>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/users.js [app-ssr] (ecmascript) <export default as Users>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/settings.js [app-ssr] (ecmascript) <export default as Settings>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clipboard$2d$list$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ClipboardList$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/clipboard-list.js [app-ssr] (ecmascript) <export default as ClipboardList>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$help$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__HelpCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-help.js [app-ssr] (ecmascript) <export default as HelpCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/generated/prisma/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/badge.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$separator$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/separator.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/avatar.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
function DesktopSidebar({ userRole }) {
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    const { data: session } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSession"])();
    const citizenLinks = [
        {
            name: "Dashboard",
            href: "/dashboard",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$house$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Home$3e$__["Home"]
        },
        {
            name: "Applications",
            href: "/dashboard/applications",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__["FileText"]
        },
        {
            name: "Notifications",
            href: "/notifications",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__["Bell"],
            badge: 3
        },
        {
            name: "Help & Support",
            href: "/help",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$help$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__HelpCircle$3e$__["HelpCircle"]
        }
    ];
    const officerLinks = [
        {
            name: "Dashboard",
            href: "/dashboard",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$house$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Home$3e$__["Home"]
        },
        {
            name: "Applications",
            href: "/applications",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__["FileText"]
        },
        {
            name: "Assigned Cases",
            href: "/officer/assignments",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clipboard$2d$list$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ClipboardList$3e$__["ClipboardList"]
        },
        {
            name: "Notifications",
            href: "/notifications",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__["Bell"],
            badge: 3
        },
        {
            name: "Help & Support",
            href: "/help",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$help$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__HelpCircle$3e$__["HelpCircle"]
        }
    ];
    const adminLinks = [
        {
            name: "Dashboard",
            href: "/admin",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$house$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Home$3e$__["Home"]
        },
        {
            name: "Applications",
            href: "/dashboard/applications",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__["FileText"]
        },
        {
            name: "User Management",
            href: "/admin/user-management",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"]
        },
        {
            name: "System Settings",
            href: "/admin/settings",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings$3e$__["Settings"]
        },
        {
            name: "Notifications",
            href: "/notifications",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__["Bell"],
            badge: 3
        },
        {
            name: "Help & Support",
            href: "/help",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$help$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__HelpCircle$3e$__["HelpCircle"]
        }
    ];
    const getLinks = ()=>{
        switch(userRole){
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].CITIZEN:
                return citizenLinks;
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].FRONT_DESK:
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].DC:
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].ADC:
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].RO:
                return officerLinks;
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].ADMIN:
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].SUPER_ADMIN:
                return adminLinks;
            default:
                return citizenLinks;
        }
    };
    const getRoleBadge = ()=>{
        switch(userRole){
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].CITIZEN:
                return {
                    text: "Citizen",
                    color: "bg-blue-100 text-blue-800"
                };
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].FRONT_DESK:
                return {
                    text: "Front Desk",
                    color: "bg-green-100 text-green-800"
                };
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].DC:
                return {
                    text: "DC",
                    color: "bg-purple-100 text-purple-800"
                };
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].ADC:
                return {
                    text: "ADC",
                    color: "bg-indigo-100 text-indigo-800"
                };
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].RO:
                return {
                    text: "RO",
                    color: "bg-amber-100 text-amber-800"
                };
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].ADMIN:
                return {
                    text: "Admin",
                    color: "bg-red-100 text-red-800"
                };
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].SUPER_ADMIN:
                return {
                    text: "Super Admin",
                    color: "bg-gray-800 text-white"
                };
            default:
                return {
                    text: "User",
                    color: "bg-gray-100 text-gray-800"
                };
        }
    };
    const getInitials = (name)=>{
        if (!name) return "U";
        return name.split(" ").map((n)=>n[0]).join("").toUpperCase().substring(0, 2);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "hidden lg:fixed lg:inset-y-0 lg:left-0 lg:z-20 lg:block lg:w-72 lg:bg-white lg:border-r lg:border-gray-200",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex h-16 shrink-0 items-center px-6 border-b border-gray-200",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "h-8 w-8 bg-blue-700 rounded-md flex items-center justify-center text-white font-bold",
                        children: "GP"
                    }, void 0, false, {
                        fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                        lineNumber: 111,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "ml-2 font-semibold text-lg",
                        children: "District Portal"
                    }, void 0, false, {
                        fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                        lineNumber: 114,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                lineNumber: 110,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "px-6 py-4 border-b border-gray-100",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center space-x-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Avatar"], {
                            className: "h-10 w-10",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AvatarFallback"], {
                                className: getRoleBadge().color,
                                children: getInitials(session?.user?.fullName)
                            }, void 0, false, {
                                fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                                lineNumber: 120,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                            lineNumber: 119,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm font-medium",
                                    children: session?.user?.fullName || "User"
                                }, void 0, false, {
                                    fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                                    lineNumber: 125,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("text-xs px-2 py-0.5 rounded-full", getRoleBadge().color),
                                    children: getRoleBadge().text
                                }, void 0, false, {
                                    fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                                    lineNumber: 128,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                            lineNumber: 124,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                    lineNumber: 118,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                lineNumber: 117,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "px-3 py-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-2 px-3 py-1.5 text-xs font-medium text-gray-500 uppercase",
                        children: "Main Navigation"
                    }, void 0, false, {
                        fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                        lineNumber: 141,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                            className: "space-y-1",
                            children: getLinks().map((link)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        href: link.href,
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium", pathname === link.href ? "bg-blue-50 text-blue-700" : "text-gray-700 hover:bg-gray-50 hover:text-gray-900"),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(link.icon, {
                                                className: "h-4 w-4 flex-shrink-0"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                                                lineNumber: 157,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "flex-1",
                                                children: link.name
                                            }, void 0, false, {
                                                fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                                                lineNumber: 158,
                                                columnNumber: 19
                                            }, this),
                                            link.badge && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Badge"], {
                                                variant: "destructive",
                                                className: "ml-auto",
                                                children: link.badge
                                            }, void 0, false, {
                                                fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                                                lineNumber: 160,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                                        lineNumber: 148,
                                        columnNumber: 17
                                    }, this)
                                }, link.name, false, {
                                    fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                                    lineNumber: 147,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                            lineNumber: 145,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                        lineNumber: 144,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$separator$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Separator"], {
                        className: "my-4"
                    }, void 0, false, {
                        fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                        lineNumber: 170,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-2 px-3 py-1.5 text-xs font-medium text-gray-500 uppercase",
                        children: "Account"
                    }, void 0, false, {
                        fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                        lineNumber: 172,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                            className: "space-y-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        href: "/profile",
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium", pathname === "/profile" ? "bg-blue-50 text-blue-700" : "text-gray-700 hover:bg-gray-50 hover:text-gray-900"),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"], {
                                                className: "h-4 w-4"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                                                lineNumber: 187,
                                                columnNumber: 17
                                            }, this),
                                            "Profile"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                                        lineNumber: 178,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                                    lineNumber: 177,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        href: "/settings",
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium", pathname === "/settings" ? "bg-blue-50 text-blue-700" : "text-gray-700 hover:bg-gray-50 hover:text-gray-900"),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings$3e$__["Settings"], {
                                                className: "h-4 w-4"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                                                lineNumber: 201,
                                                columnNumber: 17
                                            }, this),
                                            "Settings"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                                        lineNumber: 192,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                                    lineNumber: 191,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                            lineNumber: 176,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                        lineNumber: 175,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
                lineNumber: 140,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(dashboard)/components/dashboard/DesktopSidebar.tsx",
        lineNumber: 109,
        columnNumber: 5
    }, this);
}
}}),
"[project]/components/ui/input.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Input": (()=>Input)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-ssr] (ecmascript)");
;
;
function Input({ className, type, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        type: type,
        "data-slot": "input",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("file:text-foreground placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground dark:bg-input/30 border-input flex h-9 w-full min-w-0 rounded-md border bg-transparent px-3 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", "focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]", "aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/input.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
;
}}),
"[project]/app/(dashboard)/components/ui/SearchBar.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>SearchBar)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/input.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/search.js [app-ssr] (ecmascript) <export default as Search>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-ssr] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
function SearchBar() {
    const [query, setQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const handleClear = ()=>{
        setQuery("");
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                className: "h-4 w-4 absolute left-3 top-2.5 text-gray-400"
            }, void 0, false, {
                fileName: "[project]/app/(dashboard)/components/ui/SearchBar.tsx",
                lineNumber: 17,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Input"], {
                placeholder: "Search applications or case numbers...",
                className: "pl-9 pr-8 h-9 bg-slate-50 focus:bg-white border-slate-200 focus:ring-2 ring-blue-100",
                value: query,
                onChange: (e)=>setQuery(e.target.value)
            }, void 0, false, {
                fileName: "[project]/app/(dashboard)/components/ui/SearchBar.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, this),
            query && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                variant: "ghost",
                size: "icon",
                className: "h-5 w-5 absolute right-2 top-2 p-0 text-gray-400 hover:text-gray-600",
                onClick: handleClear,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                    className: "h-3 w-3"
                }, void 0, false, {
                    fileName: "[project]/app/(dashboard)/components/ui/SearchBar.tsx",
                    lineNumber: 31,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/(dashboard)/components/ui/SearchBar.tsx",
                lineNumber: 25,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(dashboard)/components/ui/SearchBar.tsx",
        lineNumber: 16,
        columnNumber: 5
    }, this);
}
}}),
"[project]/components/ui/dropdown-menu.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "DropdownMenu": (()=>DropdownMenu),
    "DropdownMenuCheckboxItem": (()=>DropdownMenuCheckboxItem),
    "DropdownMenuContent": (()=>DropdownMenuContent),
    "DropdownMenuGroup": (()=>DropdownMenuGroup),
    "DropdownMenuItem": (()=>DropdownMenuItem),
    "DropdownMenuLabel": (()=>DropdownMenuLabel),
    "DropdownMenuPortal": (()=>DropdownMenuPortal),
    "DropdownMenuRadioGroup": (()=>DropdownMenuRadioGroup),
    "DropdownMenuRadioItem": (()=>DropdownMenuRadioItem),
    "DropdownMenuSeparator": (()=>DropdownMenuSeparator),
    "DropdownMenuShortcut": (()=>DropdownMenuShortcut),
    "DropdownMenuSub": (()=>DropdownMenuSub),
    "DropdownMenuSubContent": (()=>DropdownMenuSubContent),
    "DropdownMenuSubTrigger": (()=>DropdownMenuSubTrigger),
    "DropdownMenuTrigger": (()=>DropdownMenuTrigger)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-dropdown-menu/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/check.js [app-ssr] (ecmascript) <export default as CheckIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRightIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-ssr] (ecmascript) <export default as ChevronRightIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle.js [app-ssr] (ecmascript) <export default as CircleIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
function DropdownMenu({ ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"], {
        "data-slot": "dropdown-menu",
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/dropdown-menu.tsx",
        lineNumber: 12,
        columnNumber: 10
    }, this);
}
function DropdownMenuPortal({ ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Portal"], {
        "data-slot": "dropdown-menu-portal",
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/dropdown-menu.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
}
function DropdownMenuTrigger({ ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Trigger"], {
        "data-slot": "dropdown-menu-trigger",
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/dropdown-menu.tsx",
        lineNumber: 27,
        columnNumber: 5
    }, this);
}
function DropdownMenuContent({ className, sideOffset = 4, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Portal"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Content"], {
            "data-slot": "dropdown-menu-content",
            sideOffset: sideOffset,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("bg-popover text-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 max-h-(--radix-dropdown-menu-content-available-height) min-w-[8rem] origin-(--radix-dropdown-menu-content-transform-origin) overflow-x-hidden overflow-y-auto rounded-md border p-1 shadow-md", className),
            ...props
        }, void 0, false, {
            fileName: "[project]/components/ui/dropdown-menu.tsx",
            lineNumber: 41,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/ui/dropdown-menu.tsx",
        lineNumber: 40,
        columnNumber: 5
    }, this);
}
function DropdownMenuGroup({ ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Group"], {
        "data-slot": "dropdown-menu-group",
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/dropdown-menu.tsx",
        lineNumber: 58,
        columnNumber: 5
    }, this);
}
function DropdownMenuItem({ className, inset, variant = "default", ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Item"], {
        "data-slot": "dropdown-menu-item",
        "data-inset": inset,
        "data-variant": variant,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("focus:bg-accent focus:text-accent-foreground data-[variant=destructive]:text-destructive data-[variant=destructive]:focus:bg-destructive/10 dark:data-[variant=destructive]:focus:bg-destructive/20 data-[variant=destructive]:focus:text-destructive data-[variant=destructive]:*:[svg]:!text-destructive [&_svg:not([class*='text-'])]:text-muted-foreground relative flex cursor-default items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 data-[inset]:pl-8 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/dropdown-menu.tsx",
        lineNumber: 72,
        columnNumber: 5
    }, this);
}
function DropdownMenuCheckboxItem({ className, children, checked, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CheckboxItem"], {
        "data-slot": "dropdown-menu-checkbox-item",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("focus:bg-accent focus:text-accent-foreground relative flex cursor-default items-center gap-2 rounded-sm py-1.5 pr-2 pl-8 text-sm outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", className),
        checked: checked,
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "pointer-events-none absolute left-2 flex size-3.5 items-center justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ItemIndicator"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckIcon$3e$__["CheckIcon"], {
                        className: "size-4"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/dropdown-menu.tsx",
                        lineNumber: 103,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/ui/dropdown-menu.tsx",
                    lineNumber: 102,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/ui/dropdown-menu.tsx",
                lineNumber: 101,
                columnNumber: 7
            }, this),
            children
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/dropdown-menu.tsx",
        lineNumber: 92,
        columnNumber: 5
    }, this);
}
function DropdownMenuRadioGroup({ ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RadioGroup"], {
        "data-slot": "dropdown-menu-radio-group",
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/dropdown-menu.tsx",
        lineNumber: 115,
        columnNumber: 5
    }, this);
}
function DropdownMenuRadioItem({ className, children, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RadioItem"], {
        "data-slot": "dropdown-menu-radio-item",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("focus:bg-accent focus:text-accent-foreground relative flex cursor-default items-center gap-2 rounded-sm py-1.5 pr-2 pl-8 text-sm outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", className),
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "pointer-events-none absolute left-2 flex size-3.5 items-center justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ItemIndicator"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleIcon$3e$__["CircleIcon"], {
                        className: "size-2 fill-current"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/dropdown-menu.tsx",
                        lineNumber: 138,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/ui/dropdown-menu.tsx",
                    lineNumber: 137,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/ui/dropdown-menu.tsx",
                lineNumber: 136,
                columnNumber: 7
            }, this),
            children
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/dropdown-menu.tsx",
        lineNumber: 128,
        columnNumber: 5
    }, this);
}
function DropdownMenuLabel({ className, inset, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
        "data-slot": "dropdown-menu-label",
        "data-inset": inset,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("px-2 py-1.5 text-sm font-medium data-[inset]:pl-8", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/dropdown-menu.tsx",
        lineNumber: 154,
        columnNumber: 5
    }, this);
}
function DropdownMenuSeparator({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Separator"], {
        "data-slot": "dropdown-menu-separator",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("bg-border -mx-1 my-1 h-px", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/dropdown-menu.tsx",
        lineNumber: 171,
        columnNumber: 5
    }, this);
}
function DropdownMenuShortcut({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        "data-slot": "dropdown-menu-shortcut",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("text-muted-foreground ml-auto text-xs tracking-widest", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/dropdown-menu.tsx",
        lineNumber: 184,
        columnNumber: 5
    }, this);
}
function DropdownMenuSub({ ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Sub"], {
        "data-slot": "dropdown-menu-sub",
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/dropdown-menu.tsx",
        lineNumber: 198,
        columnNumber: 10
    }, this);
}
function DropdownMenuSubTrigger({ className, inset, children, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SubTrigger"], {
        "data-slot": "dropdown-menu-sub-trigger",
        "data-inset": inset,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground flex cursor-default items-center rounded-sm px-2 py-1.5 text-sm outline-hidden select-none data-[inset]:pl-8", className),
        ...props,
        children: [
            children,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRightIcon$3e$__["ChevronRightIcon"], {
                className: "ml-auto size-4"
            }, void 0, false, {
                fileName: "[project]/components/ui/dropdown-menu.tsx",
                lineNumber: 220,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/dropdown-menu.tsx",
        lineNumber: 210,
        columnNumber: 5
    }, this);
}
function DropdownMenuSubContent({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SubContent"], {
        "data-slot": "dropdown-menu-sub-content",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("bg-popover text-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 min-w-[8rem] origin-(--radix-dropdown-menu-content-transform-origin) overflow-hidden rounded-md border p-1 shadow-lg", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/dropdown-menu.tsx",
        lineNumber: 230,
        columnNumber: 5
    }, this);
}
;
}}),
"[project]/app/(dashboard)/components/ui/UserNav.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>UserNav)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/react/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/dropdown-menu.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/avatar.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-ssr] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$log$2d$out$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__LogOut$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/log-out.js [app-ssr] (ecmascript) <export default as LogOut>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/user.js [app-ssr] (ecmascript) <export default as User>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/settings.js [app-ssr] (ecmascript) <export default as Settings>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$help$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__HelpCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-help.js [app-ssr] (ecmascript) <export default as HelpCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Shield$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/shield.js [app-ssr] (ecmascript) <export default as Shield>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/generated/prisma/index.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
function UserNav() {
    const { data: session } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSession"])();
    console.log("UserNav session", session);
    const getInitials = (name)=>{
        if (!name) return "U";
        return name.split(" ").map((n)=>n[0]).join("").toUpperCase().substring(0, 2);
    };
    const getRoleColor = (role)=>{
        switch(role){
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].ADMIN:
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].SUPER_ADMIN:
                return "bg-red-100 text-red-800";
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].DC:
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].ADC:
                return "bg-purple-100 text-purple-800";
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].RO:
                return "bg-amber-100 text-amber-800";
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].FRONT_DESK:
                return "bg-green-100 text-green-800";
            default:
                return "bg-blue-100 text-blue-800";
        }
    };
    const getRoleName = (role)=>{
        if (!role) return "User";
        return role.replace("_", " ");
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DropdownMenu"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DropdownMenuTrigger"], {
                asChild: true,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                    variant: "ghost",
                    className: "flex items-center gap-2 px-2 hover:bg-slate-100",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Avatar"], {
                            className: "h-8 w-8",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AvatarFallback"], {
                                className: getRoleColor(session?.user?.role),
                                children: getInitials(session?.user?.fullName)
                            }, void 0, false, {
                                fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                                lineNumber: 70,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                            lineNumber: 69,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "hidden md:flex flex-col items-start",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-sm font-medium leading-tight",
                                    children: session?.user?.fullName?.split(" ")[0] || "User"
                                }, void 0, false, {
                                    fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                                    lineNumber: 75,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-xs text-gray-500 leading-tight",
                                    children: getRoleName(session?.user?.role)
                                }, void 0, false, {
                                    fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                                    lineNumber: 78,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                            lineNumber: 74,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                            className: "h-4 w-4 ml-1 hidden md:block"
                        }, void 0, false, {
                            fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                            lineNumber: 82,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                    lineNumber: 65,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                lineNumber: 64,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DropdownMenuContent"], {
                align: "end",
                className: "w-56",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DropdownMenuLabel"], {
                        className: "font-normal",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col space-y-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm font-medium",
                                    children: session?.user?.fullName || "User"
                                }, void 0, false, {
                                    fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                                    lineNumber: 88,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs text-gray-500",
                                            children: session?.user?.email
                                        }, void 0, false, {
                                            fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                                            lineNumber: 92,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: `ml-2 px-1.5 py-0.5 rounded-sm text-xs ${getRoleColor(session?.user?.role)}`,
                                            children: getRoleName(session?.user?.role)
                                        }, void 0, false, {
                                            fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                                            lineNumber: 93,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                                    lineNumber: 91,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                            lineNumber: 87,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                        lineNumber: 86,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DropdownMenuSeparator"], {}, void 0, false, {
                        fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                        lineNumber: 103,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                        asChild: true,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            href: "/profile",
                            className: "flex items-center cursor-pointer",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__["User"], {
                                    className: "mr-2 h-4 w-4"
                                }, void 0, false, {
                                    fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                                    lineNumber: 106,
                                    columnNumber: 13
                                }, this),
                                "Profile"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                            lineNumber: 105,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                        lineNumber: 104,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                        asChild: true,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            href: "/settings",
                            className: "flex items-center cursor-pointer",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings$3e$__["Settings"], {
                                    className: "mr-2 h-4 w-4"
                                }, void 0, false, {
                                    fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                                    lineNumber: 112,
                                    columnNumber: 13
                                }, this),
                                "Settings"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                            lineNumber: 111,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                        lineNumber: 110,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                        asChild: true,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            href: "/help",
                            className: "flex items-center cursor-pointer",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$help$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__HelpCircle$3e$__["HelpCircle"], {
                                    className: "mr-2 h-4 w-4"
                                }, void 0, false, {
                                    fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                                    lineNumber: 118,
                                    columnNumber: 13
                                }, this),
                                "Help & Support"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                            lineNumber: 117,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                        lineNumber: 116,
                        columnNumber: 9
                    }, this),
                    (session?.user?.role === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].ADMIN || session?.user?.role === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$generated$2f$prisma$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UserRole"].SUPER_ADMIN) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                        asChild: true,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            href: "/admin",
                            className: "flex items-center cursor-pointer",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Shield$3e$__["Shield"], {
                                    className: "mr-2 h-4 w-4"
                                }, void 0, false, {
                                    fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                                    lineNumber: 126,
                                    columnNumber: 15
                                }, this),
                                "Admin Panel"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                            lineNumber: 125,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                        lineNumber: 124,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DropdownMenuSeparator"], {}, void 0, false, {
                        fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                        lineNumber: 131,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                        onClick: ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["signOut"])({
                                callbackUrl: "/login?expired=true"
                            }),
                        className: "text-red-600 cursor-pointer focus:text-red-600 focus:bg-red-50",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$log$2d$out$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__LogOut$3e$__["LogOut"], {
                                className: "mr-2 h-4 w-4"
                            }, void 0, false, {
                                fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                                lineNumber: 136,
                                columnNumber: 11
                            }, this),
                            "Sign out"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                        lineNumber: 132,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
                lineNumber: 85,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(dashboard)/components/ui/UserNav.tsx",
        lineNumber: 63,
        columnNumber: 5
    }, this);
}
}}),
"[project]/app/(dashboard)/components/ui/notification.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Notifications)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/dropdown-menu.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/bell.js [app-ssr] (ecmascript) <export default as Bell>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/badge.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
function Notifications() {
    const [notifications, setNotifications] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([
        {
            id: "1",
            title: "Your application has been received",
            description: "Application #APP-2025-0023",
            unread: true,
            time: "10 minutes ago"
        },
        {
            id: "2",
            title: "Document verification required",
            description: "Additional documents needed for processing",
            unread: true,
            time: "2 hours ago"
        },
        {
            id: "3",
            title: "Scheduled system maintenance",
            description: "System will be unavailable from 2AM-4AM tomorrow",
            unread: false,
            time: "Yesterday"
        }
    ]);
    const unreadCount = notifications.filter((n)=>n.unread).length;
    const markAsRead = (id)=>{
        setNotifications(notifications.map((n)=>n.id === id ? {
                ...n,
                unread: false
            } : n));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DropdownMenu"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DropdownMenuTrigger"], {
                asChild: true,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                    variant: "ghost",
                    size: "icon",
                    className: "relative",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__["Bell"], {
                            className: "h-5 w-5"
                        }, void 0, false, {
                            fileName: "[project]/app/(dashboard)/components/ui/notification.tsx",
                            lineNumber: 53,
                            columnNumber: 11
                        }, this),
                        unreadCount > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Badge"], {
                            variant: "destructive",
                            className: "h-5 w-5 p-0 flex items-center justify-center absolute -top-1 -right-1 text-xs",
                            children: unreadCount
                        }, void 0, false, {
                            fileName: "[project]/app/(dashboard)/components/ui/notification.tsx",
                            lineNumber: 55,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(dashboard)/components/ui/notification.tsx",
                    lineNumber: 52,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/(dashboard)/components/ui/notification.tsx",
                lineNumber: 51,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DropdownMenuContent"], {
                align: "end",
                className: "w-80",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DropdownMenuLabel"], {
                        className: "flex items-center justify-between",
                        children: [
                            "Notifications",
                            unreadCount > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Badge"], {
                                variant: "outline",
                                className: "ml-2 bg-blue-50 text-blue-700 border-blue-200",
                                children: [
                                    unreadCount,
                                    " new"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(dashboard)/components/ui/notification.tsx",
                                lineNumber: 68,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(dashboard)/components/ui/notification.tsx",
                        lineNumber: 65,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DropdownMenuSeparator"], {}, void 0, false, {
                        fileName: "[project]/app/(dashboard)/components/ui/notification.tsx",
                        lineNumber: 76,
                        columnNumber: 9
                    }, this),
                    notifications.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            notifications.map((notification)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                                    className: "p-3 cursor-pointer focus:bg-blue-50",
                                    onClick: ()=>markAsRead(notification.id),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-start w-full",
                                        children: [
                                            notification.unread && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "h-2 w-2 bg-blue-700 rounded-full mt-1.5 mr-2 flex-shrink-0"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(dashboard)/components/ui/notification.tsx",
                                                lineNumber: 87,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: `flex-1 ${!notification.unread && "pl-4"}`,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: `text-sm ${notification.unread ? "font-medium" : ""}`,
                                                        children: notification.title
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(dashboard)/components/ui/notification.tsx",
                                                        lineNumber: 90,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs text-gray-600 mt-1",
                                                        children: notification.description
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(dashboard)/components/ui/notification.tsx",
                                                        lineNumber: 97,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs text-gray-500 mt-1",
                                                        children: notification.time
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(dashboard)/components/ui/notification.tsx",
                                                        lineNumber: 100,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(dashboard)/components/ui/notification.tsx",
                                                lineNumber: 89,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(dashboard)/components/ui/notification.tsx",
                                        lineNumber: 85,
                                        columnNumber: 17
                                    }, this)
                                }, notification.id, false, {
                                    fileName: "[project]/app/(dashboard)/components/ui/notification.tsx",
                                    lineNumber: 80,
                                    columnNumber: 15
                                }, this)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DropdownMenuSeparator"], {}, void 0, false, {
                                fileName: "[project]/app/(dashboard)/components/ui/notification.tsx",
                                lineNumber: 107,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                                className: "p-2 cursor-pointer text-center text-blue-700 font-medium hover:text-blue-800 hover:bg-blue-50",
                                children: "View all notifications"
                            }, void 0, false, {
                                fileName: "[project]/app/(dashboard)/components/ui/notification.tsx",
                                lineNumber: 108,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "p-8 text-center text-gray-500 text-sm",
                        children: "No new notifications"
                    }, void 0, false, {
                        fileName: "[project]/app/(dashboard)/components/ui/notification.tsx",
                        lineNumber: 113,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(dashboard)/components/ui/notification.tsx",
                lineNumber: 64,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(dashboard)/components/ui/notification.tsx",
        lineNumber: 50,
        columnNumber: 5
    }, this);
}
}}),
"[project]/app/(dashboard)/components/dashboard/DashboardHeader.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>DashboardHeader)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/react/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$sheet$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/sheet.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/menu.js [app-ssr] (ecmascript) <export default as Menu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$dashboard$292f$components$2f$dashboard$2f$MobileSidebar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(dashboard)/components/dashboard/MobileSidebar.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$dashboard$292f$components$2f$ui$2f$SearchBar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(dashboard)/components/ui/SearchBar.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$dashboard$292f$components$2f$ui$2f$UserNav$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(dashboard)/components/ui/UserNav.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$dashboard$292f$components$2f$ui$2f$notification$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(dashboard)/components/ui/notification.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
function DashboardHeader() {
    const { data: session } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSession"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        className: "bg-white border-b  sticky top-0 z-30 ",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto px-4 flex items-center justify-between h-[63px]",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$sheet$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Sheet"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$sheet$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SheetTrigger"], {
                                asChild: true,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                    variant: "ghost",
                                    size: "icon",
                                    className: "lg:hidden",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
                                        className: "h-5 w-5 text-gray-700"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(dashboard)/components/dashboard/DashboardHeader.tsx",
                                        lineNumber: 22,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/(dashboard)/components/dashboard/DashboardHeader.tsx",
                                    lineNumber: 21,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/(dashboard)/components/dashboard/DashboardHeader.tsx",
                                lineNumber: 20,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$dashboard$292f$components$2f$dashboard$2f$MobileSidebar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/app/(dashboard)/components/dashboard/DashboardHeader.tsx",
                                lineNumber: 25,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(dashboard)/components/dashboard/DashboardHeader.tsx",
                        lineNumber: 19,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/(dashboard)/components/dashboard/DashboardHeader.tsx",
                    lineNumber: 18,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center space-x-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "hidden md:block max-w-md w-full",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$dashboard$292f$components$2f$ui$2f$SearchBar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/app/(dashboard)/components/dashboard/DashboardHeader.tsx",
                                lineNumber: 31,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(dashboard)/components/dashboard/DashboardHeader.tsx",
                            lineNumber: 30,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$dashboard$292f$components$2f$ui$2f$notification$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/app/(dashboard)/components/dashboard/DashboardHeader.tsx",
                            lineNumber: 34,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$dashboard$292f$components$2f$ui$2f$UserNav$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/app/(dashboard)/components/dashboard/DashboardHeader.tsx",
                            lineNumber: 35,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(dashboard)/components/dashboard/DashboardHeader.tsx",
                    lineNumber: 29,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/(dashboard)/components/dashboard/DashboardHeader.tsx",
            lineNumber: 17,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/(dashboard)/components/dashboard/DashboardHeader.tsx",
        lineNumber: 16,
        columnNumber: 5
    }, this);
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__86c82373._.js.map