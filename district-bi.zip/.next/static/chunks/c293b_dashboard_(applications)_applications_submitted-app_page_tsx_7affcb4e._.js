(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_b1e4c1e9._.js",
  "static/chunks/_4883c090._.js"
],
    source: "dynamic"
});
