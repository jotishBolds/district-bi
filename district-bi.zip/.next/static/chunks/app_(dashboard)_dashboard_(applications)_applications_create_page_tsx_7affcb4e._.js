(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_20c8fe84._.js",
  "static/chunks/node_modules_e0b2f09d._.js"
],
    source: "dynamic"
});
